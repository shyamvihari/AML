"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { getClientToken, getCurrentUser } from "@/lib/session";
import { IndividualKycFields } from "../../../../IndividualKycFields";
import { CorporateKycFields } from "../../../../CorporateKycFields";
import { CustomerDocumentsPanel } from "../../../../CustomerDocumentsPanel";
import { PortalSidebar } from "../../../PortalSidebar";
import type { IndividualKycFieldsInput, CorporateKycFieldsInput } from "@/lib/customerSchemas";

type CustomerInviteRecord = {
  id: string;
  token: string;
  purpose: "DATA_ENTRY" | "REVIEW_SIGNATURE";
  intendedSignerUserId: string | null;
};

type CustomerRecord = {
  id: string;
  customerType: string | null;
  name: string | null;
  companyName: string | null;
  email: string;
  phone: string | null;
  nationality: string | null;
  dateOfBirth: string | null;
  passportOrEmiratesId: string | null;
  idExpiryDate: string | null;
  residentialAddress: string | null;
  occupation: string | null;
  tradeLicenseNumber: string | null;
  licenseAuthority: string | null;
  incorporationDate: string | null;
  registeredAddress: string | null;
  businessActivity: string | null;
  authorizedSignatoryName: string | null;
  documents: { id: string; type: string; fileName: string }[];
};

function toDateInput(value: string | null): string {
  return value ? value.slice(0, 10) : "";
}

export default function ManualKycEntryPage() {
  const params = useParams<{ customerId: string }>();
  const customerId = params.customerId;
  const [customer, setCustomer] = useState<CustomerRecord | null>(null);
  const [fields, setFields] = useState<Partial<IndividualKycFieldsInput & CorporateKycFieldsInput>>({});
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);
  const [reviewSignInvite, setReviewSignInvite] = useState<CustomerInviteRecord | null>(null);
  const [whatsapp, setWhatsapp] = useState<{ attempted: boolean; ok?: boolean; error?: string }>({ attempted: false });

  function authHeaders(json?: boolean): HeadersInit {
    const token = getClientToken();
    return { ...(json ? { "Content-Type": "application/json" } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  }

  async function load() {
    const res = await fetch(`/api/portal/customers/${customerId}`, { headers: authHeaders() });
    if (!res.ok) {
      setError("Could not load this customer.");
      return;
    }
    const body = await res.json();
    const c: CustomerRecord = body.customer;
    setCustomer(c);
    setFields({
      name: c.name ?? "",
      dateOfBirth: toDateInput(c.dateOfBirth),
      nationality: c.nationality ?? "",
      passportOrEmiratesId: c.passportOrEmiratesId ?? "",
      idExpiryDate: toDateInput(c.idExpiryDate),
      residentialAddress: c.residentialAddress ?? "",
      occupation: c.occupation ?? "",
      companyName: c.companyName ?? "",
      tradeLicenseNumber: c.tradeLicenseNumber ?? "",
      licenseAuthority: c.licenseAuthority ?? "",
      incorporationDate: toDateInput(c.incorporationDate),
      registeredAddress: c.registeredAddress ?? "",
      businessActivity: c.businessActivity ?? "",
      authorizedSignatoryName: c.authorizedSignatoryName ?? "",
      phone: c.phone ?? "",
      email: c.email ?? "",
    });
  }

  async function loadPendingReviewInvite() {
    const res = await fetch(`/api/portal/customers/${customerId}/invite`, { headers: authHeaders() });
    if (!res.ok) return;
    const body = await res.json();
    const invite: CustomerInviteRecord | null = body.invite ?? null;
    const currentUser = getCurrentUser();
    if (
      invite &&
      invite.purpose === "REVIEW_SIGNATURE" &&
      currentUser &&
      invite.intendedSignerUserId === currentUser.id
    ) {
      setReviewSignInvite(invite);
    } else {
      setReviewSignInvite(null);
    }
  }

  useEffect(() => {
    load();
    loadPendingReviewInvite();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  async function save() {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/portal/customers/${customerId}`, {
      method: "PATCH",
      headers: authHeaders(true),
      body: JSON.stringify(fields),
    });
    const body = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not save these details.");
      return;
    }
    setNotice("Saved.");
    await load();
  }

  async function submitForReview() {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/portal/customers/${customerId}/invite`, {
      method: "POST",
      headers: authHeaders(true),
      body: JSON.stringify({
        purpose: "REVIEW_SIGNATURE",
        customerName: customer?.name ?? customer?.companyName ?? "Customer",
        customerPhone: customer?.phone ?? undefined,
        customerEmail: customer?.email,
      }),
    });
    const body = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not generate a review link.");
      return;
    }
    setInviteUrl(body.inviteUrl);
    setWhatsapp(body.whatsapp ?? { attempted: false });
  }

  async function uploadDocument(file: File, type: string) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("type", type);
    await fetch(`/api/portal/customers/${customerId}/documents`, { method: "POST", headers: authHeaders(), body: formData });
    await load();
  }

  async function deleteDocument(id: string) {
    await fetch(`/api/portal/customers/${customerId}/documents/${id}`, { method: "DELETE", headers: authHeaders() });
    await load();
  }

  if (error && !customer) {
    return (
      <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
        <PortalSidebar />
        <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
      </div>
    );
  }
  if (!customer) {
    return (
      <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
        <PortalSidebar />
        <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
      </div>
    );
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <h1 className="text-2xl font-semibold text-charcoal">
          {customer.customerType === "CORPORATE" ? "Corporate" : "Individual"} KYC details
        </h1>

        {notice && <p className="mt-2 text-sm text-green-700 dark:text-green-400">{notice}</p>}
        {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}

        {reviewSignInvite && (
          <Link
            href={`/invite/${reviewSignInvite.token}`}
            className="mt-4 flex w-fit items-center gap-2 rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            A customer submitted their details — review and sign
          </Link>
        )}

        <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          {customer.customerType === "CORPORATE" ? (
            <CorporateKycFields value={fields} onChange={(next) => setFields((f) => ({ ...f, ...next }))} disabled={busy} />
          ) : (
            <IndividualKycFields value={fields} onChange={(next) => setFields((f) => ({ ...f, ...next }))} disabled={busy} />
          )}
          <button
            type="button"
            onClick={save}
            disabled={busy}
            className="mt-4 w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-50"
          >
            Save
          </button>
        </section>

        <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <h2 className="mb-2 font-medium text-charcoal">Documents</h2>
          <CustomerDocumentsPanel
            documents={customer.documents}
            onUpload={uploadDocument}
            onDelete={deleteDocument}
            downloadHrefFor={(id) => `/api/portal/customers/${customerId}/documents/${id}/download`}
          />
        </section>

        {!inviteUrl ? (
          <button
            type="button"
            onClick={submitForReview}
            disabled={busy}
            className="mt-6 w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            Details done — generate a review link for the customer
          </button>
        ) : (
          <div className="mt-6 flex flex-col gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-4">
            {whatsapp.attempted && whatsapp.ok && (
              <p className="text-sm text-green-700 dark:text-green-400">Sent to {customer.phone} via WhatsApp.</p>
            )}
            {whatsapp.attempted && !whatsapp.ok && (
              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                Automatic sending didn&apos;t go through ({whatsapp.error}) — copy the link below instead.
              </p>
            )}
            <p className="text-sm text-neutral-600 dark:text-neutral-300">
              Copy this link and send it to the customer on WhatsApp so they can review and sign:
            </p>
            <input readOnly value={inviteUrl} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm" />
          </div>
        )}
      </div>
    </div>
  );
}
