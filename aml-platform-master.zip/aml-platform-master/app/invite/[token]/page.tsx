"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { IndividualKycFields } from "../../IndividualKycFields";
import { CorporateKycFields } from "../../CorporateKycFields";
import { CustomerDetailsSummary } from "../../CustomerDetailsSummary";
import { CustomerDocumentsPanel } from "../../CustomerDocumentsPanel";
import { SignaturePad } from "../../SignaturePad";
import type { IndividualKycFieldsInput, CorporateKycFieldsInput } from "@/lib/customerSchemas";

type CustomerRecord = {
  id: string;
  customerType: string | null;
  name: string | null;
  companyName: string | null;
  email: string;
  phone: string | null;
  nationality: string | null;
  dateOfBirth: string | null;
  passportOrEmiratesId: string | null;
  idExpiryDate: string | null;
  residentialAddress: string | null;
  occupation: string | null;
  tradeLicenseNumber: string | null;
  licenseAuthority: string | null;
  incorporationDate: string | null;
  registeredAddress: string | null;
  businessActivity: string | null;
  authorizedSignatoryName: string | null;
  documents: { id: string; type: string; fileName: string }[];
};

function toDateInput(value: string | null): string {
  return value ? value.slice(0, 10) : "";
}

export default function InvitePage() {
  const params = useParams<{ token: string }>();
  const token = params.token;
  const [purpose, setPurpose] = useState<"DATA_ENTRY" | "REVIEW_SIGNATURE" | null>(null);
  const [customer, setCustomer] = useState<CustomerRecord | null>(null);
  const [fields, setFields] = useState<Partial<IndividualKycFieldsInput & CorporateKycFieldsInput>>({});
  const [invalid, setInvalid] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function load() {
    const res = await fetch(`/api/invite/${token}`);
    if (!res.ok) {
      setInvalid(true);
      return;
    }
    const body = await res.json();
    const c: CustomerRecord = body.customer;
    setPurpose(body.purpose);
    setCustomer(c);
    setFields({
      name: c.name ?? "",
      dateOfBirth: toDateInput(c.dateOfBirth),
      nationality: c.nationality ?? "",
      passportOrEmiratesId: c.passportOrEmiratesId ?? "",
      idExpiryDate: toDateInput(c.idExpiryDate),
      residentialAddress: c.residentialAddress ?? "",
      occupation: c.occupation ?? "",
      companyName: c.companyName ?? "",
      tradeLicenseNumber: c.tradeLicenseNumber ?? "",
      licenseAuthority: c.licenseAuthority ?? "",
      incorporationDate: toDateInput(c.incorporationDate),
      registeredAddress: c.registeredAddress ?? "",
      businessActivity: c.businessActivity ?? "",
      authorizedSignatoryName: c.authorizedSignatoryName ?? "",
      phone: c.phone ?? "",
      email: c.email ?? "",
    });
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  async function saveFields() {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/invite/${token}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(fields),
    });
    const body = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not save these details.");
      return;
    }
    setNotice("Saved.");
    await load();
  }

  async function uploadDocument(file: File, type: string) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("type", type);
    await fetch(`/api/invite/${token}/documents`, { method: "POST", body: formData });
    await load();
  }

  async function deleteDocument(id: string) {
    await fetch(`/api/invite/${token}/documents/${id}`, { method: "DELETE" });
    await load();
  }

  async function submitDataEntry() {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/invite/${token}/submit`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    setBusy(false);
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(typeof body.error === "string" ? body.error : "Could not submit.");
      return;
    }
    setDone(true);
  }

  async function submitSignature() {
    if (!signatureDataUrl) {
      setError("Please draw your signature first.");
      return;
    }
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/invite/${token}/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ signatureDataUrl }),
    });
    setBusy(false);
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(typeof body.error === "string" ? body.error : "Could not submit.");
      return;
    }
    setDone(true);
  }

  if (invalid) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center">
        <p className="text-sm text-neutral-600 dark:text-neutral-300">This link is no longer valid.</p>
      </div>
    );
  }
  if (!customer || !purpose) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center">
        <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
      </div>
    );
  }
  if (done) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center">
        <p className="text-sm text-green-700 dark:text-green-400">
          {purpose === "DATA_ENTRY" ? "Submitted. Thank you." : "Signed and confirmed. Thank you."}
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">
        {purpose === "DATA_ENTRY" ? "Your KYC details" : "Review and confirm"}
      </h1>

      {notice && <p className="mt-2 text-sm text-green-700 dark:text-green-400">{notice}</p>}
      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}

      {purpose === "DATA_ENTRY" ? (
        <>
          <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
            {customer.customerType === "CORPORATE" ? (
              <CorporateKycFields value={fields} onChange={(next) => setFields((f) => ({ ...f, ...next }))} disabled={busy} />
            ) : (
              <IndividualKycFields value={fields} onChange={(next) => setFields((f) => ({ ...f, ...next }))} disabled={busy} />
            )}
            <button
              type="button"
              onClick={saveFields}
              disabled={busy}
              className="mt-4 w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-50"
            >
              Save
            </button>
          </section>

          <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
            <h2 className="mb-2 font-medium text-charcoal">Documents</h2>
            <CustomerDocumentsPanel
              documents={customer.documents}
              onUpload={uploadDocument}
              onDelete={deleteDocument}
              downloadHrefFor={(id) => `/api/invite/${token}/documents/${id}/download`}
            />
          </section>

          <button
            type="button"
            onClick={submitDataEntry}
            disabled={busy || customer.documents.length === 0}
            className="mt-6 w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            Submit
          </button>
        </>
      ) : (
        <>
          <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
            <h2 className="mb-2 font-medium text-charcoal">Details on file</h2>
            <CustomerDetailsSummary customer={customer} />
          </section>

          <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
            <h2 className="mb-2 font-medium text-charcoal">Documents</h2>
            <CustomerDocumentsPanel
              documents={customer.documents}
              onUpload={async () => {}}
              downloadHrefFor={(id) => `/api/invite/${token}/documents/${id}/download`}
              readOnly
            />
          </section>

          <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
            <h2 className="mb-2 font-medium text-charcoal">Your signature</h2>
            <SignaturePad onChange={setSignatureDataUrl} />
          </section>

          <button
            type="button"
            onClick={submitSignature}
            disabled={busy || !signatureDataUrl}
            className="mt-6 w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            Confirm and sign
          </button>
        </>
      )}
    </div>
  );
}
