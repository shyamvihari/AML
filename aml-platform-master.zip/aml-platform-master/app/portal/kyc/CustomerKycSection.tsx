"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getClientToken } from "@/lib/session";
import { CUSTOMER_TYPES, CUSTOMER_TYPE_LABELS } from "@/lib/customerSchemas";

type CustomerOption = { id: string; name: string | null; companyName: string | null; email: string; status: string };

export function CustomerKycSection() {
  const router = useRouter();
  const [customers, setCustomers] = useState<CustomerOption[] | null>(null);
  const [adding, setAdding] = useState(false);
  const [customerType, setCustomerType] = useState<(typeof CUSTOMER_TYPES)[number]>("INDIVIDUAL");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [whatsapp, setWhatsapp] = useState<{ attempted: boolean; ok?: boolean; error?: string }>({ attempted: false });

  useEffect(() => {
    const token = getClientToken();
    fetch("/api/portal/customers", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => setCustomers(body?.customers ?? []));
  }, []);

  async function createCustomer(): Promise<string | null> {
    setBusy(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch("/api/portal/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ customerType, name, phone: phone || undefined, email }),
    });
    const body = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not add this customer.");
      return null;
    }
    return body.customer.id as string;
  }

  async function startManual() {
    const id = await createCustomer();
    if (id) router.push(`/portal/kyc/customer/${id}`);
  }

  async function startInvite() {
    const id = await createCustomer();
    if (!id) return;
    setBusy(true);
    const token = getClientToken();
    const res = await fetch(`/api/portal/customers/${id}/invite`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ purpose: "DATA_ENTRY", customerName: name, customerPhone: phone || undefined, customerEmail: email }),
    });
    const body = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not generate a link.");
      return;
    }
    setInviteUrl(body.inviteUrl);
    setWhatsapp(body.whatsapp ?? { attempted: false });
  }

  async function copyLink() {
    if (!inviteUrl) return;
    await navigator.clipboard.writeText(inviteUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  return (
    <section className="mt-10 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
      <h2 className="text-lg font-medium text-charcoal">Your customers&apos; KYC</h2>

      {!adding && (
        <>
          <ul className="mt-3 flex flex-col gap-2 text-sm">
            {customers?.length === 0 && <li className="text-neutral-500 dark:text-neutral-400">No customers yet.</li>}
            {customers?.map((c) => (
              <li key={c.id}>
                <Link
                  href={`/portal/kyc/customer/${c.id}`}
                  className="flex items-center justify-between rounded-md border border-neutral-200 dark:border-neutral-700 px-3 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                >
                  <span>{c.name ?? c.companyName ?? c.email}</span>
                  <span className="text-xs uppercase text-neutral-500 dark:text-neutral-400">{c.status}</span>
                </Link>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => setAdding(true)}
            className="mt-3 w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Add new
          </button>
        </>
      )}

      {adding && !inviteUrl && (
        <div className="mt-3 flex flex-col gap-3">
          <div className="flex rounded-md border border-neutral-300 dark:border-neutral-600 p-1 text-sm w-fit">
            {CUSTOMER_TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setCustomerType(t)}
                className={`rounded px-3 py-1.5 ${customerType === t ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
              >
                {CUSTOMER_TYPE_LABELS[t]}
              </button>
            ))}
          </div>
          <label className={labelClass}>
            Customer name
            <input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Customer phone
            <input value={phone} onChange={(e) => setPhone(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Customer email
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
          </label>
          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={startManual}
              disabled={busy || !name || !email}
              className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
            >
              Enter details manually
            </button>
            <button
              type="button"
              onClick={startInvite}
              disabled={busy || !name || !email}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-50"
            >
              Send a link to the customer
            </button>
            <button type="button" onClick={() => setAdding(false)} className="text-sm text-neutral-500 dark:text-neutral-400 hover:underline">
              Cancel
            </button>
          </div>
        </div>
      )}

      {inviteUrl && (
        <div className="mt-3 flex flex-col gap-2">
          {whatsapp.attempted && whatsapp.ok && (
            <p className="text-sm text-green-700 dark:text-green-400">Sent to {phone} via WhatsApp.</p>
          )}
          {whatsapp.attempted && !whatsapp.ok && (
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              Automatic sending didn&apos;t go through ({whatsapp.error}) — copy the link below instead.
            </p>
          )}
          <p className="text-sm text-neutral-600 dark:text-neutral-300">
            Copy this link and send it to the customer on WhatsApp (or however you reach them):
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <input readOnly value={inviteUrl} className="min-w-0 flex-1 rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm" />
            <button
              type="button"
              onClick={copyLink}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              {copied ? "Copied!" : "Copy link"}
            </button>
          </div>
          <button
            type="button"
            onClick={() => {
              setAdding(false);
              setInviteUrl(null);
              setWhatsapp({ attempted: false });
              setName("");
              setPhone("");
              setEmail("");
            }}
            className="w-fit text-sm text-brand-start hover:underline"
          >
            Done
          </button>
        </div>
      )}
    </section>
  );
}
