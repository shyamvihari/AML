import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Insights | Compass & Coin",
  description:
    "Regulatory insight summaries on CBUAE, FATF, DFSA, and MOEC developments relevant to UAE real estate AML/CFT compliance.",
};

const INSIGHTS = [
  {
    tag: "MOEC",
    title: "Cabinet Resolution 134 of 2025 and who counts as a DNFBP",
    summary:
      "Cabinet Resolution 134 of 2025 sets out which real estate activities fall within the UAE's Designated Non-Financial Business or Profession (DNFBP) regime. For brokerages, developers, and agents, the practical question isn't whether AML/CFT rules exist — it's whether a given transaction type or role brings a firm within scope, and what that triggers in terms of registration, policies, and reporting.",
  },
  {
    tag: "CBUAE",
    title: "What CBUAE AML/CFT guidance means for real estate transactions",
    summary:
      "The Central Bank of the UAE issues AML/CFT guidance that shapes supervisory expectations even where a real estate firm isn't itself CBUAE-regulated, because it informs how the sector's designated supervisory authority interprets risk. Firms handling high-value property transactions should treat this guidance as a baseline for their own CDD and transaction-monitoring design, not just a banking-sector concern.",
  },
  {
    tag: "FATF",
    title: "Why beneficial ownership transparency matters for off-plan sales",
    summary:
      "FATF's recommendations on beneficial ownership push jurisdictions to make it harder to hide the natural person behind a corporate buyer. In off-plan and high-value real estate, layered ownership structures are common and legitimate — but they're also where UBO identification work needs the most rigor. Getting beneficial ownership right at the point of sale is cheaper than unwinding a problem after the fact.",
  },
  {
    tag: "MOEC",
    title: "goAML reporting: what it requires and who owns the filing",
    summary:
      "goAML is the UAE Financial Intelligence Unit's system for AML/CFT regulatory reporting, including Suspicious Activity Reports and Suspicious Transaction Reports. Registering on goAML and understanding its reporting triggers is a distinct compliance obligation from having an AML policy in place — a firm can have a well-written manual and still be non-compliant if it hasn't registered or doesn't know when a filing is required.",
  },
  {
    tag: "DFSA",
    title: "Where DFSA-regulated structures intersect with mainland real estate rules",
    summary:
      "Firms operating across both DIFC-regulated structures and mainland UAE real estate activity sometimes assume one regulatory regime covers the other. It generally doesn't. Understanding where DFSA rules apply versus where Cabinet Resolution 134 and CBUAE guidance apply is a scoping exercise worth doing early, particularly for groups with entities in more than one jurisdiction.",
  },
  {
    tag: "CBUAE",
    title: "Enhanced Due Diligence triggers real estate firms commonly miss",
    summary:
      "Enhanced Due Diligence isn't only about Politically Exposed Persons. Higher-risk indicators in real estate can include cash-heavy payment structures, unusual urgency, third-party payments, or buyers connected to higher-risk jurisdictions. Building a clear internal definition of what triggers EDD — rather than relying on case-by-case judgment — is one of the more common gaps we see during scoping conversations.",
  },
];

export default function InsightsPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <SectionHeading
          eyebrow="Insights"
          title="Regulatory developments we're tracking"
          subtitle="Short summaries of the regulatory themes shaping AML/CFT obligations for UAE real estate — CBUAE, FATF, DFSA, and MOEC. These are topic overviews, not legal advice; talk to us about how a specific development applies to your business."
        />

        <div className="grid gap-6 md:grid-cols-2">
          {INSIGHTS.map((item) => (
            <article
              key={item.title}
              className="flex flex-col rounded-lg border border-neutral-200 dark:border-neutral-700 p-6"
            >
              <span className="inline-flex w-fit items-center rounded-full bg-offwhite px-3 py-1 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                Topic: {item.tag}
              </span>
              <h3 className="mt-3 text-lg font-semibold text-charcoal">{item.title}</h3>
              <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{item.summary}</p>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}
