"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { getClientToken } from "@/lib/session";

type Stats = {
  clientCount: number;
  customerCount: number;
  planBreakdown: { REGULAR: number; PRO: number; MAX: number };
  screeningsTotal: number;
};
type ClientRow = {
  id: string;
  name: string;
  email: string;
  companyName: string | null;
  plan: "REGULAR" | "PRO" | "MAX";
  customerCount: number;
  createdAt: string;
};

export function PlatformOverview() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [clients, setClients] = useState<ClientRow[] | null>(null);

  useEffect(() => {
    const token = getClientToken();
    const headers: HeadersInit = token ? { Authorization: `Bearer ${token}` } : {};
    fetch("/api/staff/stats", { headers })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => body && setStats(body));
    fetch("/api/staff/clients", { headers })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => body && setClients(body.clients));
  }, []);

  return (
    <div className="flex flex-col gap-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Clients</p>
          <p className="mt-1 text-2xl font-semibold text-charcoal">{stats ? stats.clientCount : "..."}</p>
        </div>
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Customers</p>
          <p className="mt-1 text-2xl font-semibold text-charcoal">{stats ? stats.customerCount : "..."}</p>
        </div>
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Regular plan</p>
          <p className="mt-1 text-2xl font-semibold text-charcoal">{stats ? stats.planBreakdown.REGULAR : "..."}</p>
        </div>
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Pro + Max plans</p>
          <p className="mt-1 text-2xl font-semibold text-charcoal">
            {stats ? stats.planBreakdown.PRO + stats.planBreakdown.MAX : "..."}
          </p>
        </div>
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
          <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Screenings Performed</p>
          <p className="mt-1 text-2xl font-semibold text-charcoal">{stats ? stats.screeningsTotal : "..."}</p>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-charcoal">Clients</h2>
          <Link
            href="/staff/clients/new"
            className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Add client
          </Link>
        </div>
        {!clients ? (
          <p className="mt-4 text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
        ) : (
          <table className="mt-4 w-full text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
                <th className="py-2">Name</th>
                <th className="py-2">Email</th>
                <th className="py-2">Company</th>
                <th className="py-2">Plan</th>
                <th className="py-2">Customers</th>
                <th className="py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
              {clients.map((c) => (
                <tr key={c.id}>
                  <td className="py-2">{c.name}</td>
                  <td className="py-2">{c.email}</td>
                  <td className="py-2">{c.companyName || "—"}</td>
                  <td className="py-2 uppercase">{c.plan}</td>
                  <td className="py-2">{c.customerCount}</td>
                  <td className="py-2 text-right">
                    <Link href={`/staff/clients/${c.id}/edit`} className="text-brand-start hover:underline">
                      Edit
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
