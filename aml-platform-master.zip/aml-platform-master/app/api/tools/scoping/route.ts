import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { computeScopingResult } from "@/lib/scopingLogic";
import { leadInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";

const requestSchema = z.object({
  activityType: z.enum([
    "SALE_PURCHASE_FACILITATION",
    "VALUATION",
    "MARKETING_ONLY",
    "LEASING",
    "PROPERTY_MANAGEMENT",
  ]),
  facilitatesConclusion: z.boolean(),
  lead: leadInputSchema.omit({ source: true, payload: true }),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { activityType, facilitatesConclusion, lead } = parsed.data;
  const result = computeScopingResult({ activityType, facilitatesConclusion });

  await prisma.lead.create({
    data: {
      ...lead,
      source: "SCOPING_TOOL",
      payload: { activityType, facilitatesConclusion, result } as unknown as Prisma.InputJsonValue,
    },
  });

  return NextResponse.json(result);
}
