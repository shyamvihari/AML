"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";
import { ENTITY_TYPE_LABELS, KYC_DOCUMENT_TYPE_LABELS, RELATED_COMPANY_SCOPE_LABELS } from "@/lib/kycSchemas";
import { SCREENING_RISK_RATING_LABELS, SCREENING_ALERT_STATUS_LABELS } from "@/lib/screeningSchemas";

type Profile = {
  id: string;
  status: string;
  companyName: string | null;
  entityType: string | null;
  entityTypeOther: string | null;
  coreBusinessActivity: string | null;
  licenseNumber: string | null;
  licenseIssueDate: string | null;
  licenseExpiryDate: string | null;
  licenseIssuingAuthority: string | null;
  dateOfIncorporation: string | null;
  countryOfRegistration: string | null;
  poBox: string | null;
  telephone: string | null;
  emirate: string | null;
  trn: string | null;
  orn: string | null;
  registeredEmail: string | null;
  contactPersonName: string | null;
  contactPersonEmail: string | null;
  estimatedAnnualTurnover: string | null;
  relatedCompanyScope: string | null;
  authorizedSignatoryName: string | null;
  sanctionScreeningStatus: string | null;
  mlroApproval: string | null;
  mlroRemarks: string | null;
  owners: { name: string; designation: string | null; nationality: string | null; percentShare: number | null }[];
  documents: { id: string; type: string; fileName: string }[];
  user: { name: string; email: string };
};

const REVIEW_STATUSES = ["UNDER_REVIEW", "APPROVED", "REJECTED", "NEEDS_UPDATE"];

export default function StaffKycDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [screeningRecords, setScreeningRecords] = useState<
    { id: string; subjectName: string; riskRating: string; alertStatus: string | null; scannedAt: string | null }[]
  >([]);
  const [sanctionScreeningStatus, setSanctionScreeningStatus] = useState("");
  const [mlroApproval, setMlroApproval] = useState("");
  const [mlroRemarks, setMlroRemarks] = useState("");
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  async function load() {
    const token = getClientToken();
    const res = await fetch(`/api/staff/kyc/${id}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    if (!res.ok) return;
    const body = await res.json();
    setProfile(body.profile);
    setSanctionScreeningStatus(body.profile.sanctionScreeningStatus ?? "");
    setMlroApproval(body.profile.mlroApproval ?? "");
    setMlroRemarks(body.profile.mlroRemarks ?? "");
    const screeningRes = await fetch(`/api/staff/kyc/${id}/screening`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    if (screeningRes.ok) {
      const screeningBody = await screeningRes.json();
      setScreeningRecords(screeningBody.records ?? []);
    }
  }

  useEffect(() => {
    if (user?.role === "STAFF" || user?.role === "SUPER_ADMIN") load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, id]);

  async function review(status: (typeof REVIEW_STATUSES)[number]) {
    const token = getClientToken();
    await fetch(`/api/staff/kyc/${id}/review`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ status, sanctionScreeningStatus, mlroApproval, mlroRemarks }),
    });
    setNotice(`Status set to ${status}.`);
    await load();
  }

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }
  if (!profile) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">{profile.companyName || "(no company name yet)"}</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400">
        {profile.user.name} — {profile.user.email} — status: <strong className="uppercase">{profile.status}</strong>
      </p>

      {notice && <p className="mt-2 text-sm text-green-700 dark:text-green-400">{notice}</p>}

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Submitted details</h2>
        <dl className="grid grid-cols-2 gap-2">
          <div><dt className="text-neutral-500 dark:text-neutral-400">Entity type</dt><dd>{profile.entityType ? ENTITY_TYPE_LABELS[profile.entityType as keyof typeof ENTITY_TYPE_LABELS] : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Entity type "Others" specify</dt><dd>{profile.entityTypeOther ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Core business activity</dt><dd>{profile.coreBusinessActivity ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">License number</dt><dd>{profile.licenseNumber ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">License issue date</dt><dd>{profile.licenseIssueDate ? new Date(profile.licenseIssueDate).toLocaleDateString() : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">License expiry date</dt><dd>{profile.licenseExpiryDate ? new Date(profile.licenseExpiryDate).toLocaleDateString() : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">License issuing authority</dt><dd>{profile.licenseIssuingAuthority ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Date of incorporation</dt><dd>{profile.dateOfIncorporation ? new Date(profile.dateOfIncorporation).toLocaleDateString() : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Country of registration</dt><dd>{profile.countryOfRegistration ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">P.O. Box</dt><dd>{profile.poBox ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Telephone</dt><dd>{profile.telephone ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Emirate</dt><dd>{profile.emirate ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">TRN</dt><dd>{profile.trn ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">ORN</dt><dd>{profile.orn ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Registered email</dt><dd>{profile.registeredEmail ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Contact person</dt><dd>{profile.contactPersonName ?? "—"} ({profile.contactPersonEmail ?? "—"})</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Estimated annual turnover</dt><dd>{profile.estimatedAnnualTurnover ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Related company scope</dt><dd>{profile.relatedCompanyScope ? RELATED_COMPANY_SCOPE_LABELS[profile.relatedCompanyScope as keyof typeof RELATED_COMPANY_SCOPE_LABELS] : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Authorized signatory</dt><dd>{profile.authorizedSignatoryName ?? "—"}</dd></div>
        </dl>
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Owners / directors / shareholders</h2>
        {profile.owners.length ? (
          <ul className="flex flex-col gap-1">
            {profile.owners.map((o, i) => (
              <li key={i}>{o.name} — {o.designation ?? "—"} — {o.nationality ?? "—"} — {o.percentShare ?? "—"}%</li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None listed.</p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Documents</h2>
        {profile.documents.length ? (
          <ul className="flex flex-col gap-1">
            {profile.documents.map((d) => (
              <li key={d.id}>
                <a href={`/api/kyc/documents/${d.id}/download`} className="text-brand-start hover:underline">
                  {d.fileName} ({KYC_DOCUMENT_TYPE_LABELS[d.type as keyof typeof KYC_DOCUMENT_TYPE_LABELS] ?? d.type})
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None uploaded.</p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Screening</h2>
        {screeningRecords.length ? (
          <ul className="flex flex-col gap-2">
            {screeningRecords.map((r) => (
              <li key={r.id}>
                <Link href={`/staff/kyc/${id}/screening/${r.id}`} className="text-brand-start hover:underline">
                  {r.subjectName}
                </Link>
                {" — "}risk: {SCREENING_RISK_RATING_LABELS[r.riskRating as keyof typeof SCREENING_RISK_RATING_LABELS] ?? r.riskRating}
                {r.alertStatus ? ` — alert: ${SCREENING_ALERT_STATUS_LABELS[r.alertStatus as keyof typeof SCREENING_ALERT_STATUS_LABELS] ?? r.alertStatus}` : ""}
                {r.scannedAt ? ` — scanned ${new Date(r.scannedAt).toLocaleDateString()}` : ""}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">No screening records yet.</p>
        )}
        <Link
          href={`/staff/kyc/${id}/screening/new`}
          className="mt-3 inline-block rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite"
        >
          Add screening record
        </Link>
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
        <h2 className="mb-2 text-sm font-medium text-charcoal">Compliance department</h2>
        <div className="flex flex-col gap-2">
          <label className="flex flex-col gap-1 text-sm">
            Sanction screening status
            <input value={sanctionScreeningStatus} onChange={(e) => setSanctionScreeningStatus(e.target.value)} className={inputClass} />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            MLRO approval
            <input value={mlroApproval} onChange={(e) => setMlroApproval(e.target.value)} className={inputClass} />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            MLRO remarks
            <textarea value={mlroRemarks} onChange={(e) => setMlroRemarks(e.target.value)} rows={3} className={inputClass} />
          </label>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {REVIEW_STATUSES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => review(s)}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite"
            >
              Set {s}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
