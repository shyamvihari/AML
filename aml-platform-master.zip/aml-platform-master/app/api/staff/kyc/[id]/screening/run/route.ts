import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import { matchSubject, suggestRiskRating, OpenSanctionsError } from "@/lib/openSanctions";

const runScreeningSchema = z.object({
  subjectName: z.string().min(1, "Subject name is required"),
  dateOfBirth: z.string().optional(),
});

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const profile = await prisma.kycProfile.findUnique({ where: { id } });
  if (!profile) return NextResponse.json({ error: "KYC profile not found" }, { status: 404 });

  const body = await request.json().catch(() => null);
  const parsed = runScreeningSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  try {
    const matches = await matchSubject({ name: parsed.data.subjectName, birthDate: parsed.data.dateOfBirth });
    return NextResponse.json({
      matches,
      suggestedRiskRating: suggestRiskRating(matches),
      sanctionMatchCount: matches.length,
    });
  } catch (err) {
    if (err instanceof OpenSanctionsError) {
      return NextResponse.json(
        { error: "Could not reach the sanctions screening service. Please try again or enter matches manually." },
        { status: 502 },
      );
    }
    throw err;
  }
}
