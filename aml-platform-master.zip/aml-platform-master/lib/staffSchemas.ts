import { z } from "zod";

export const staffCreateClientInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  companyName: z.string().optional(),
});
export type StaffCreateClientInput = z.infer<typeof staffCreateClientInputSchema>;

export const staffCreateAdminInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  role: z.enum(["STAFF", "SUPER_ADMIN"]),
});
export type StaffCreateAdminInput = z.infer<typeof staffCreateAdminInputSchema>;
