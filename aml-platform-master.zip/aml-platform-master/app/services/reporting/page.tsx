import Link from "next/link";
import { SectionHeading } from "../../SectionHeading";

export const metadata = {
  title: "Reporting & Monitoring | Compass & Coin",
  description:
    "Red-flag transaction monitoring, guided SAR/STR drafting, goAML filing-workflow tracking, and a compliance calendar for UAE real estate DNFBPs.",
};

const RED_FLAG_TYPOLOGIES = [
  {
    label: "Structuring",
    description: "Payments broken into amounts designed to stay under reporting or scrutiny thresholds.",
  },
  {
    label: "Third-party payments",
    description: "Funds for a transaction arriving from a party unconnected to the buyer or the deal.",
  },
  {
    label: "Rapid resale",
    description: "A property bought and resold shortly after, with little apparent commercial rationale.",
  },
  {
    label: "Shell-company buyers",
    description: "Purchasing entities with opaque ownership, no discernible business activity, or newly formed for the transaction.",
  },
];

const COMPLIANCE_CALENDAR_ITEMS = [
  "Policy manual renewal and annual review",
  "AML training refreshers for staff",
  "Independent audit cycles",
  "Regulator correspondence and response deadlines",
];

export default function ReportingPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <SectionHeading
          eyebrow="Pillar D"
          title="Reporting & Monitoring"
          subtitle="Catching the transaction patterns that matter, drafting the report, and keeping your recurring compliance obligations on schedule."
        />

        <div className="flex flex-col gap-10 text-neutral-700 dark:text-neutral-300">
          <section>
            <h3 className="text-xl font-semibold text-charcoal">Transaction-level red-flag monitoring</h3>
            <p className="mt-3">
              Deals are monitored against typologies drawn from FATF and CBUAE guidance
              on money laundering through real estate. These are patterns that, on their
              own, don't prove wrongdoing — but that warrant a closer look and, often, a
              documented reason for proceeding:
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {RED_FLAG_TYPOLOGIES.map((item) => (
                <div key={item.label} className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-4">
                  <p className="text-sm font-semibold text-charcoal">{item.label}</p>
                  <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{item.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Guided SAR/STR drafting</h3>
            <p className="mt-3">
              When a red flag warrants escalation, a Suspicious Activity Report (SAR) or
              Suspicious Transaction Report (STR) needs to capture the specific facts a
              regulator will assess — not a generic narrative. Our drafting workspace
              walks the MLRO through a guided template covering the parties involved, the
              transaction detail, the specific indicators observed, and the supporting
              documentation, so the report is complete and defensible before it's
              submitted.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">goAML filing-workflow tracking</h3>
            <p className="mt-3">
              Once a SAR/STR is drafted, we track it through the filing workflow —
              drafting, internal review, sign-off, and submission status — so nothing
              sits half-finished. To be clear about what this service does and does not
              do: the actual submission of a report on the UAE's goAML portal is, and
              remains, an action taken by your firm's own designated MLRO on the
              regulator's system. Compass & Coin tracks and supports the filing workflow
              leading up to that point; we do not submit reports to the regulator on a
              client's behalf.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Compliance calendar</h3>
            <p className="mt-3">
              Beyond individual filings, an AML program carries recurring obligations
              that are easy to lose track of once the initial registration is done. We
              maintain a compliance calendar covering the deadline types below —
              illustrative of what's tracked, not a live schedule for any particular
              client:
            </p>
            <ul className="mt-4 flex flex-col gap-2">
              {COMPLIANCE_CALENDAR_ITEMS.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-start" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-6">
            <h3 className="text-lg font-semibold text-charcoal">Get your reporting workflow in order</h3>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
              We'll review how your firm currently handles red flags, SAR/STR drafting,
              and filing deadlines, and recommend what to tighten up.
            </p>
            <Link
              href="/contact?intent=scoping-call"
              className="mt-4 inline-block rounded-md bg-brand-gradient px-5 py-3 text-sm font-medium text-white hover:opacity-90"
            >
              Book a Free AML Scoping Call
            </Link>
          </section>
        </div>
      </div>
    </main>
  );
}
