import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";

const reviewSchema = z.object({
  sanctionScreeningStatus: z.string().optional(),
  mlroApproval: z.string().optional(),
  mlroRemarks: z.string().optional(),
  status: z.enum(["UNDER_REVIEW", "APPROVED", "REJECTED", "NEEDS_UPDATE"]),
});

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = reviewSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { id } = await params;
  const existing = await prisma.kycProfile.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const profile = await prisma.kycProfile.update({
    where: { id },
    data: {
      sanctionScreeningStatus: parsed.data.sanctionScreeningStatus ?? existing.sanctionScreeningStatus,
      mlroApproval: parsed.data.mlroApproval ?? existing.mlroApproval,
      mlroRemarks: parsed.data.mlroRemarks ?? existing.mlroRemarks,
      status: parsed.data.status,
      reviewedByUserId: payload.userId,
      reviewedAt: new Date(),
    },
    include: { owners: { orderBy: { sortOrder: "asc" } }, documents: { orderBy: { uploadedAt: "asc" } } },
  });

  return NextResponse.json({ profile });
}
