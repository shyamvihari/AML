import { NextResponse } from "next/server";
import { del } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string; docId: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id, docId } = await params;
  const document = await prisma.customerDocument.findUnique({ where: { id: docId }, include: { customer: true } });
  if (!document || document.customerId !== id || document.customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  await del(document.fileUrl, { token: process.env.BLOB_READ_WRITE_TOKEN });
  await prisma.customerDocument.delete({ where: { id: docId } });

  return NextResponse.json({});
}
