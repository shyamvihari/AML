import { NextResponse } from "next/server";
import { del } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const { id } = await params;
  const document = await prisma.kycDocument.findUnique({ where: { id }, include: { kycProfile: true } });
  if (!document || document.kycProfile.userId !== payload.userId) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  await del(document.fileUrl, { token: process.env.BLOB_READ_WRITE_TOKEN });
  await prisma.kycDocument.delete({ where: { id } });

  return NextResponse.json({});
}
