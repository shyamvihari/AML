import Link from "next/link";
import { SectionHeading } from "../SectionHeading";
import { ChecklistDownloadForm } from "./ChecklistDownloadForm";

export const metadata = {
  title: "Resources | Compass & Coin",
  description:
    "Downloadable checklists, an AML/CFT glossary, and answers to common questions on UAE real estate DNFBP compliance.",
};

const GLOSSARY: { term: string; meaning: string }[] = [
  { term: "AML/CFT", meaning: "Anti-Money Laundering / Countering the Financing of Terrorism" },
  { term: "CDD", meaning: "Customer Due Diligence — standard identity and risk checks on a client" },
  { term: "EDD", meaning: "Enhanced Due Diligence — deeper checks applied to higher-risk clients (e.g., PEPs)" },
  {
    term: "DNFBP",
    meaning:
      "Designated Non-Financial Business or Profession (e.g., real estate agents, dealers in precious metals, law firms, accountants)",
  },
  { term: "KYC", meaning: "Know Your Customer — the process of verifying client identity and risk" },
  {
    term: "MLRO",
    meaning: "Money Laundering Reporting Officer — the designated compliance officer for statutory reporting",
  },
  {
    term: "PEP",
    meaning: "Politically Exposed Person — an individual holding a prominent public function, requiring EDD",
  },
  {
    term: "SAR / STR",
    meaning: "Suspicious Activity Report / Suspicious Transaction Report filed with the Financial Intelligence Unit",
  },
  { term: "UBO", meaning: "Ultimate Beneficial Owner — the natural person(s) who ultimately own or control an entity" },
  {
    term: "goAML",
    meaning: "The UAE Financial Intelligence Unit's official system for AML/CFT regulatory reporting",
  },
  { term: "CBUAE", meaning: "Central Bank of the United Arab Emirates" },
  { term: "FATF", meaning: "Financial Action Task Force — global AML/CFT standard-setting body" },
];

const FAQS = [
  {
    q: "Do I need to register as a DNFBP?",
    a: "If your real estate activity falls within the scope set out in Cabinet Resolution 134 of 2025 — broadly, real estate agents and brokers involved in buying, selling, or leasing transactions above the relevant thresholds — you're required to register as a Designated Non-Financial Business or Profession and meet the associated AML/CFT obligations. Whether a specific business model is in scope depends on the activity itself, which is why we start every engagement with a registration-scoping assessment rather than assuming.",
  },
  {
    q: "What counts as Enhanced Due Diligence?",
    a: "Enhanced Due Diligence (EDD) is a deeper level of Customer Due Diligence applied to higher-risk clients — most notably Politically Exposed Persons (PEPs), but also clients or transactions carrying other elevated risk indicators. It typically means gathering more information on source of funds and beneficial ownership, and applying closer ongoing scrutiny than standard CDD.",
  },
  {
    q: "Does Compass & Coin file my SAR/STR for me?",
    a: "No. Filing a Suspicious Activity Report or Suspicious Transaction Report through goAML is the client's own regulated obligation and remains the client's action — we don't file on your behalf. What we provide is advisory support: helping you assess whether a transaction meets the threshold for a filing, and supporting your team through the reporting process itself.",
  },
  {
    q: "What's the difference between CDD and KYC?",
    a: "Know Your Customer (KYC) is the broader process of verifying who a client is and understanding their risk profile. Customer Due Diligence (CDD) is the standard set of checks — identity verification, ownership structure, risk classification — that KYC is built from. In practice the terms overlap heavily; EDD is the escalated version applied when standard CDD isn't sufficient for the risk presented.",
  },
  {
    q: "Who is the MLRO, and do I need to appoint one?",
    a: "The Money Laundering Reporting Officer (MLRO) is the individual designated within your business as responsible for AML/CFT compliance and statutory reporting, including goAML filings. If your firm is in scope as a DNFBP, appointing an MLRO — whether an internal team member or, in some structures, an outsourced compliance officer function — is a standard requirement we help clients put in place.",
  },
  {
    q: "How does UBO identification work for corporate buyers?",
    a: "For any buyer that isn't a natural person, we work through the ownership and control structure to identify the Ultimate Beneficial Owner(s) — the actual individual(s) who own or control the entity, even where that ownership sits behind multiple corporate layers. This is a standard part of CDD for corporate transactions, and it's an area regulators and FATF guidance both treat as a priority given how often layered structures are used to obscure ownership.",
  },
];

export default function ResourcesPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <SectionHeading
          eyebrow="Resources"
          title="Checklists, glossary, and FAQs"
          subtitle="Practical reference material for real estate firms working through UAE AML/CFT obligations."
        />

        <section className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-6">
          <h3 className="text-xl font-semibold text-charcoal">UAE Real Estate DNFBP Registration Checklist</h3>
          <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
            A step-by-step checklist covering how to assess whether your business falls within
            DNFBP registration scope, what to prepare before registering, and the policy
            documents typically required alongside it. Leave your details and we'll send it to
            your inbox — there's no automatic download link.
          </p>
          <div className="mt-5 max-w-md">
            <ChecklistDownloadForm />
          </div>
        </section>

        <section className="mt-8 rounded-lg border border-neutral-200 dark:border-neutral-700 p-6">
          <h3 className="text-xl font-semibold text-charcoal">Want a fuller picture?</h3>
          <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
            Take our AML Health-Check to benchmark your current program against UAE DNFBP
            requirements and see where the gaps are.
          </p>
          <div className="mt-5">
            <Link
              href="/tools/health-check"
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-5 py-3 text-sm font-medium text-charcoal hover:border-brand-start hover:text-brand-start"
            >
              Take the AML Health-Check
            </Link>
          </div>
        </section>

        <section className="mt-16 border-t border-neutral-200 dark:border-neutral-700 pt-16">
          <SectionHeading eyebrow="Glossary" title="AML/CFT terms, defined" />
          <dl className="grid gap-x-8 gap-y-5 sm:grid-cols-[minmax(0,180px)_1fr]">
            {GLOSSARY.map((item) => (
              <div key={item.term} className="contents">
                <dt className="font-semibold text-charcoal sm:pt-0">{item.term}</dt>
                <dd className="mb-4 text-sm text-neutral-600 dark:text-neutral-300 sm:mb-0">{item.meaning}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section className="mt-16 border-t border-neutral-200 dark:border-neutral-700 pt-16">
          <SectionHeading eyebrow="FAQs" title="Common questions" />
          <div className="flex flex-col divide-y divide-neutral-200 dark:divide-neutral-700">
            {FAQS.map((item) => (
              <div key={item.q} className="py-5">
                <h4 className="text-base font-semibold text-charcoal">{item.q}</h4>
                <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{item.a}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
