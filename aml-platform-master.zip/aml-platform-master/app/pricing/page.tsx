import { SectionHeading } from "../SectionHeading";
import { LeadForm } from "../LeadForm";

export const metadata = {
  title: "Pricing | Compass & Coin",
  description:
    "Project-based and retainer engagement models for UAE real estate AML/CFT compliance advisory. Book a scoping call for a custom quote.",
};

const PROJECT_MODEL = {
  name: "Project-Based Engagement",
  summary:
    "A fixed-scope package for a defined piece of work — a specific deliverable with a clear start and end, priced against that scope once we've discussed it.",
  inclusions: [
    "DNFBP registration scoping — an assessment of whether your activities fall within Cabinet Resolution 134 of 2025's mandatory registration scope",
    "AML/CFT policy manual and procedures drafting, tailored to your business model and transaction types",
    "One-time risk assessment and CDD/EDD methodology design for your onboarding flow",
    "goAML registration and reporting-process setup support",
    "A defined handover — documentation and training your team can operate going forward",
  ],
  fit: "Best suited to firms that need a specific compliance artefact in place — a policy manual, a registration decision, an onboarding methodology — and can run day-to-day screening and monitoring themselves once it's built.",
};

const RETAINER_MODEL = {
  name: "Ongoing Retainer",
  summary:
    "A continuous monthly engagement covering the operational work of staying compliant — the parts of an AML/CFT programme that don't stop once the initial setup is done.",
  inclusions: [
    "Continuous sanctions, PEP, and adverse-media screening for onboarding and periodic re-screening",
    "Compliance calendar management — tracking registration renewals, reporting deadlines, and policy review dates",
    "Periodic reporting support, including assistance preparing for CBUAE supervisory requests",
    "Ongoing advisory access for red-flag assessment and STR/SAR filing decisions as transactions arise",
    "Policy and procedure updates as regulatory guidance from CBUAE, FATF, or the Ministry of Economy evolves",
  ],
  fit: "Best suited to firms that want AML/CFT compliance run as an ongoing function rather than a one-time project — particularly those without a dedicated in-house Compliance Officer able to carry the full workload alone.",
};

export default function PricingPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <SectionHeading
          eyebrow="Pricing"
          title="Two ways to work with us"
          subtitle="Our service model is hybrid — fixed-scope projects and ongoing monthly retainers. Which fits depends on what you already have in place and how much of the ongoing workload you want to carry yourself. Actual scope and cost are set on a scoping call, not listed here."
        />

        <div className="grid gap-8 md:grid-cols-2">
          {[PROJECT_MODEL, RETAINER_MODEL].map((model) => (
            <div key={model.name} className="flex flex-col rounded-lg border border-neutral-200 dark:border-neutral-700 p-6">
              <h3 className="text-xl font-semibold text-charcoal">{model.name}</h3>
              <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{model.summary}</p>

              <p className="mt-5 text-sm font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400">
                What's included
              </p>
              <ul className="mt-3 flex flex-col gap-2">
                {model.inclusions.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-neutral-700 dark:text-neutral-300">
                    <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-start" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <p className="mt-5 border-t border-neutral-200 dark:border-neutral-700 pt-4 text-sm text-neutral-600 dark:text-neutral-300">
                <span className="font-semibold text-charcoal">Best fit: </span>
                {model.fit}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-6 rounded-lg bg-offwhite p-6 text-sm text-neutral-600 dark:text-neutral-300">
          Many clients start with a project-based engagement to get a policy manual and
          registration position in place, then move to a retainer once ongoing screening
          and reporting volume makes that the more efficient option. There's no obligation
          to pick one model up front — that's exactly what the scoping call is for.
        </div>

        <div className="mt-16 border-t border-neutral-200 dark:border-neutral-700 pt-16">
          <div className="mx-auto max-w-xl">
            <SectionHeading
              eyebrow="Get a custom quote"
              title="Book a scoping call"
              subtitle="Pricing depends on your transaction volume, client mix, and how much of the compliance workload you want us to carry. Tell us about your business and we'll quote against your actual scope on a call — no published price list, because no two firms' obligations look the same."
            />
            <LeadForm source="BOOKING_REQUEST" submitLabel="Book a scoping call" />
          </div>
        </div>
      </div>
    </main>
  );
}
