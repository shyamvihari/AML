"use client";

import { useEffect, useState } from "react";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";

const CONFIRM_PHRASE = "DELETE";

export default function ResetDataPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [confirmText, setConfirmText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ kycProfiles: number; customers: number; users: number } | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  if (user && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Super Admin access required.</div>;
  }

  async function reset() {
    setBusy(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch("/api/admin/reset-data", {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      setError("Could not reset data. Please try again.");
      setBusy(false);
      return;
    }
    const body = await res.json();
    setResult(body.deleted);
    setConfirmText("");
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Reset all data</h1>

      <div className="mt-4 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950 p-4 text-sm text-red-800 dark:text-red-200">
        <p className="font-medium">This permanently deletes every CLIENT and CUSTOMER account</p>
        <p className="mt-1">
          Along with their KYC profiles, customers, uploaded documents, and screening records. STAFF and
          SUPER_ADMIN accounts are not affected. This cannot be undone. Uploaded files in blob storage are not
          deleted by this action — only the database records.
        </p>
      </div>

      {result ? (
        <div className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
          <p className="font-medium text-charcoal">Done.</p>
          <p className="mt-1 text-neutral-600 dark:text-neutral-300">
            Deleted {result.users} account(s), {result.customers} customer(s), {result.kycProfiles} KYC profile(s)
            (and everything cascading from them).
          </p>
        </div>
      ) : (
        <div className="mt-6 flex flex-col gap-3">
          <label className="flex flex-col gap-1 text-sm">
            Type <span className="font-mono font-semibold">{CONFIRM_PHRASE}</span> to confirm
            <input
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2"
            />
          </label>
          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
          <button
            type="button"
            onClick={reset}
            disabled={confirmText !== CONFIRM_PHRASE || busy}
            className="w-fit rounded-md bg-red-600 dark:bg-red-700 px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Deleting..." : "Delete all CLIENT & CUSTOMER data"}
          </button>
        </div>
      )}
    </div>
  );
}
