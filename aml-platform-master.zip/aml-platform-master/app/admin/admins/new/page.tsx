"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";

export default function NewAdminPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"STAFF" | "SUPER_ADMIN">("STAFF");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState<{ email: string; tempPassword: string; role: "STAFF" | "SUPER_ADMIN" } | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch("/api/admin/admins", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ name, email, role }),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not add this admin. Please check the form and try again.");
      setSaving(false);
      return;
    }
    setCreated({ email, tempPassword: body.tempPassword, role });
    setSaving(false);
  }

  if (user && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Super Admin access required.</div>;
  }

  if (created) {
    return (
      <div className="mx-auto max-w-lg px-6 py-16">
        <h1 className="text-2xl font-semibold text-charcoal">Admin added</h1>
        <div className="mt-4 flex flex-col gap-2 rounded-md border border-neutral-200 dark:border-neutral-700 bg-offwhite p-4 text-sm text-charcoal">
          <p>
            Share these login details directly — this password is shown only once and won&apos;t be displayed
            again.
          </p>
          <p>
            <strong>Email:</strong> {created.email}
          </p>
          <p>
            <strong>Account type:</strong> {created.role === "SUPER_ADMIN" ? "Super Admin" : "Staff"}
          </p>
          <p>
            <strong>Temporary password:</strong>{" "}
            <code className="rounded bg-white dark:bg-neutral-900 px-1.5 py-0.5">{created.tempPassword}</code>
          </p>
        </div>
        <Link href="/admin" className="mt-6 inline-block text-sm text-brand-start hover:underline">
          Back to dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Add an admin</h1>
      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
      <form onSubmit={submit} className="mt-6 flex flex-col gap-3">
        <label className={labelClass}>
          Name
          <input required value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
        </label>
        <div className={labelClass}>
          <span id="role-label">Role</span>
          <div
            role="group"
            aria-labelledby="role-label"
            className="flex rounded-md border border-neutral-300 dark:border-neutral-600 p-1 text-sm"
          >
            <button
              type="button"
              onClick={() => setRole("STAFF")}
              aria-pressed={role === "STAFF"}
              className={`flex-1 rounded px-3 py-1.5 ${role === "STAFF" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
            >
              Staff
            </button>
            <button
              type="button"
              onClick={() => setRole("SUPER_ADMIN")}
              aria-pressed={role === "SUPER_ADMIN"}
              className={`flex-1 rounded px-3 py-1.5 ${role === "SUPER_ADMIN" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
            >
              Super Admin
            </button>
          </div>
        </div>
        <button
          type="submit"
          disabled={saving}
          className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving..." : "Add admin"}
        </button>
      </form>
    </div>
  );
}
