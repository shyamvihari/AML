import { SectionHeading } from "@/app/SectionHeading";
import { HealthCheckTool } from "./HealthCheckTool";

export const metadata = {
  title: "AML Health-Check Self-Assessment | Compass & Coin",
  description:
    "Answer 12 yes/no questions to benchmark your firm's current AML maturity against UAE Cabinet Resolution 134 of 2025 requirements, and get a printable score report.",
};

export default function HealthCheckPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <SectionHeading
        eyebrow="Free tool"
        title="AML Health-Check Self-Assessment"
        subtitle="Answer 12 yes/no questions covering policy, screening, reporting, and recordkeeping to benchmark your firm's current AML maturity under UAE Cabinet Resolution 134 of 2025 — then print or save your result as a PDF."
      />
      <HealthCheckTool />
    </div>
  );
}
