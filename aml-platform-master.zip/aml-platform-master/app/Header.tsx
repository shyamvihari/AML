import Image from "next/image";
import Link from "next/link";
import { HeaderAuthLinks } from "./HeaderAuthLinks";

const NAV_LINKS = [
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/industries", label: "Industries" },
  { href: "/pricing", label: "Pricing" },
  { href: "/insights", label: "Insights" },
  { href: "/resources", label: "Resources" },
  { href: "/case-studies", label: "Case Studies" },
  { href: "/contact", label: "Contact" },
];

export function Header() {
  return (
    <header id="site-header" className="border-b border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4">
        <Link href="/" className="flex items-center">
          <Image
            src="/compass-and-coin-logo.png"
            alt="Compass & Coin"
            width={160}
            height={72}
            priority
            className="h-9 w-auto"
          />
        </Link>
        <nav className="hidden flex-wrap items-center gap-x-5 gap-y-1 text-sm text-charcoal lg:flex">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="hover:text-brand-start">
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <HeaderAuthLinks />
          <Link
            href="/contact?intent=scoping-call"
            className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Book a Free AML Scoping Call
          </Link>
        </div>
      </div>
    </header>
  );
}
