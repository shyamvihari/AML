"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";

type ProfileSummary = {
  id: string;
  companyName: string | null;
  status: string;
  updatedAt: string;
  user: { name: string; email: string };
};

const STATUSES = ["", "DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "REJECTED", "NEEDS_UPDATE"];

export default function StaffKycListPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [profiles, setProfiles] = useState<ProfileSummary[]>([]);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || (user.role !== "STAFF" && user.role !== "SUPER_ADMIN")) return;
    const token = getClientToken();
    const qs = status ? `?status=${status}` : "";
    fetch(`/api/staff/kyc${qs}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.json())
      .then((body) => {
        setProfiles(body.profiles ?? []);
        setLoading(false);
      });
  }, [user, status]);

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">KYC review queue</h1>
      <select value={status} onChange={(e) => setStatus(e.target.value)} className="mt-4 rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm">
        {STATUSES.map((s) => (
          <option key={s} value={s}>{s || "All statuses"}</option>
        ))}
      </select>
      {loading ? (
        <p className="mt-4 text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
      ) : (
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
              <th className="py-2">Company</th>
              <th className="py-2">Client</th>
              <th className="py-2">Status</th>
              <th className="py-2">Updated</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
            {profiles.map((p) => (
              <tr key={p.id}>
                <td className="py-2">
                  <Link href={`/staff/kyc/${p.id}`} className="text-brand-start hover:underline">
                    {p.companyName || "(no company name yet)"}
                  </Link>
                </td>
                <td className="py-2">{p.user.email}</td>
                <td className="py-2 uppercase">{p.status}</td>
                <td className="py-2">{new Date(p.updatedAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
