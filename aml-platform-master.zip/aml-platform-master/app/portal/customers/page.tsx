"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken } from "@/lib/session";
import { PortalSidebar } from "../PortalSidebar";

type CustomerSummary = {
  id: string;
  name: string | null;
  companyName: string | null;
  email: string;
  status: string;
  createdAt: string;
};

export default function CustomersListPage() {
  const [customers, setCustomers] = useState<CustomerSummary[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    const token = getClientToken();
    fetch("/api/portal/customers", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => {
        if (!res.ok) {
          setLoadError("Could not load your customers. Please try signing in again.");
          return null;
        }
        return res.json();
      })
      .then((body) => {
        if (body) setCustomers(body.customers ?? []);
      });
  }, []);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-charcoal">Customers</h1>
          <Link
            href="/portal/customers/new"
            className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Add customer
          </Link>
        </div>
        {loadError ? (
          <p className="mt-6 text-sm text-red-600 dark:text-red-400">{loadError}</p>
        ) : customers === null ? (
          <p className="mt-6 text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
        ) : customers.length === 0 ? (
          <p className="mt-6 text-sm text-neutral-500 dark:text-neutral-400">
            No customers yet — add one to run KYC and screening on them.
          </p>
        ) : (
          <table className="mt-6 w-full text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
                <th className="py-2">Name</th>
                <th className="py-2">Email</th>
                <th className="py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {customers.map((c) => (
                <tr key={c.id}>
                  <td className="py-2">
                    <Link href={`/portal/customers/${c.id}`} className="text-brand-start hover:underline">
                      {c.name || c.companyName || "(unnamed)"}
                    </Link>
                  </td>
                  <td className="py-2">{c.email}</td>
                  <td className="py-2 uppercase">{c.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
