"use client";

import { use, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getClientToken } from "@/lib/session";
import { CUSTOMER_SCREENING_RISK_RATING_LABELS } from "@/lib/customerSchemas";

type ScreeningDetail = {
  id: string;
  subjectName: string;
  riskRating: string;
  scannedAt: string | null;
  screenedBy: string | null;
  alertRaised: boolean;
  sanctionMatchCount: number;
  notes: string | null;
  identifications: { identityType: string; identificationNumber: string }[];
  matches: { source: string; matchName: string; matchScore: number | null }[];
  customer: { name: string | null; companyName: string | null };
};

function fmt(v: string | null) {
  return v ? new Date(v).toLocaleDateString() : "—";
}

export default function CustomerScreeningDetailPage({ params }: { params: Promise<{ id: string; screeningId: string }> }) {
  const { id, screeningId } = use(params);
  const router = useRouter();
  const [record, setRecord] = useState<ScreeningDetail | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = getClientToken();
    fetch(`/api/portal/screening/${screeningId}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => {
        if (!res.ok) {
          setNotFound(true);
          return null;
        }
        return res.json();
      })
      .then((body) => {
        if (body) setRecord(body.record);
      });
  }, [screeningId]);

  async function remove() {
    const token = getClientToken();
    const res = await fetch(`/api/portal/screening/${screeningId}`, {
      method: "DELETE",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      setError("Failed to delete screening record. Please try again.");
      return;
    }
    router.push(`/portal/customers/${id}`);
  }

  if (notFound) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Screening record not found.</div>;

  if (!record) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Screening: {record.subjectName}</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400">
        {record.customer.name ?? record.customer.companyName ?? "(unnamed)"}
      </p>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <dl className="grid grid-cols-2 gap-2">
          <div><dt className="text-neutral-500 dark:text-neutral-400">Risk rating</dt><dd>{CUSTOMER_SCREENING_RISK_RATING_LABELS[record.riskRating as keyof typeof CUSTOMER_SCREENING_RISK_RATING_LABELS] ?? record.riskRating}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Scanned date</dt><dd>{fmt(record.scannedAt)}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Screened by</dt><dd>{record.screenedBy ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Alert raised</dt><dd>{record.alertRaised ? "Yes" : "No"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Sanction match count</dt><dd>{record.sanctionMatchCount}</dd></div>
        </dl>
        {record.notes && <p className="mt-2 text-neutral-600 dark:text-neutral-300">{record.notes}</p>}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Identification records</h2>
        {record.identifications.length ? (
          <ul className="flex flex-col gap-1">
            {record.identifications.map((ident, i) => (
              <li key={i}>{ident.identityType} — {ident.identificationNumber}</li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None recorded.</p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Sanction / PEP matches</h2>
        {record.matches.length ? (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
                <th className="py-2">Source</th>
                <th className="py-2">Name</th>
                <th className="py-2">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {record.matches.map((m, i) => (
                <tr key={i}>
                  <td className="py-2">{m.source}</td>
                  <td className="py-2">{m.matchName}</td>
                  <td className="py-2">{m.matchScore != null ? `${Math.round(m.matchScore * 100)}%` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None recorded.</p>
        )}
      </section>

      {error && <p className="mt-4 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <button
        type="button"
        onClick={remove}
        className="mt-6 rounded-md border border-red-300 dark:border-red-800 px-4 py-2 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950"
      >
        Delete screening record
      </button>
    </div>
  );
}
