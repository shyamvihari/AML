import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { PLAN_LIMITS, planInputSchema } from "@/lib/planSchemas";
import { getScreeningsUsedToday } from "@/lib/planUsage";

export async function GET(request: Request) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const user = await prisma.user.findUniqueOrThrow({ where: { id: payload.userId }, select: { plan: true } });
  const usedToday = await getScreeningsUsedToday(payload.userId);
  return NextResponse.json({ plan: user.plan, limit: PLAN_LIMITS[user.plan], usedToday });
}

export async function POST(request: Request) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = planInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const user = await prisma.user.update({
    where: { id: payload.userId },
    data: { plan: parsed.data.plan },
    select: { plan: true },
  });
  const usedToday = await getScreeningsUsedToday(payload.userId);
  return NextResponse.json({ plan: user.plan, limit: PLAN_LIMITS[user.plan], usedToday });
}
