import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";

export async function GET(request: Request, { params }: { params: Promise<{ screeningId: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { screeningId } = await params;
  const record = await prisma.customerScreeningRecord.findUnique({
    where: { id: screeningId },
    include: {
      identifications: { orderBy: { sortOrder: "asc" } },
      matches: { orderBy: { sortOrder: "asc" } },
      customer: { select: { clientUserId: true, name: true, companyName: true } },
    },
  });
  if (!record || record.customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json({ record });
}

export async function DELETE(request: Request, { params }: { params: Promise<{ screeningId: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { screeningId } = await params;
  const record = await prisma.customerScreeningRecord.findUnique({
    where: { id: screeningId },
    include: { customer: { select: { clientUserId: true } } },
  });
  if (!record || record.customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await prisma.customerScreeningRecord.delete({ where: { id: screeningId } });
  return NextResponse.json({});
}
