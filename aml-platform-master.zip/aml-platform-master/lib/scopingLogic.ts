export type ActivityType =
  | "SALE_PURCHASE_FACILITATION"
  | "VALUATION"
  | "MARKETING_ONLY"
  | "LEASING"
  | "PROPERTY_MANAGEMENT";

export interface ScopingAnswer {
  activityType: ActivityType;
  facilitatesConclusion: boolean; // does the firm conclude/close sale-purchase deals
}

export interface ScopingResult {
  likely: boolean;
  headline: string;
  reasoning: string;
}

export const ACTIVITY_LABELS: Record<ActivityType, string> = {
  SALE_PURCHASE_FACILITATION: "Facilitating sale/purchase transactions (brokerage)",
  VALUATION: "Property valuation services",
  MARKETING_ONLY: "Marketing properties on behalf of owners/developers",
  LEASING: "Leasing / rental transactions",
  PROPERTY_MANAGEMENT: "Property management services",
};

export function computeScopingResult(answer: ScopingAnswer): ScopingResult {
  // Per the source doc's Section 5.2 framing: DNFBP registration under Cabinet
  // Resolution 134 of 2025 turns primarily on concluding sale/purchase transactions,
  // distinct from valuation, marketing-only, leasing, or property management
  // activity, which fall outside the mandatory scope (though the firm still advises
  // property managers on voluntary best-practice CDD per the source doc's persona
  // table, Section 4).
  if (answer.activityType === "SALE_PURCHASE_FACILITATION" && answer.facilitatesConclusion) {
    return {
      likely: true,
      headline: "Registration is likely required",
      reasoning:
        "Based on your answers, your activity involves concluding real estate sale/purchase transactions, which falls within the DNFBP registration scope under UAE Cabinet Resolution 134 of 2025. We recommend a confirmation consultation to formally scope your registration and onboarding obligations.",
    };
  }
  if (answer.activityType === "LEASING" || answer.activityType === "PROPERTY_MANAGEMENT") {
    return {
      likely: false,
      headline: "Registration is likely not required — but voluntary best practice is recommended",
      reasoning:
        `${ACTIVITY_LABELS[answer.activityType]} generally falls outside the mandatory DNFBP registration scope. Many firms in this position still adopt voluntary CDD/EDD best practices given the reputational and counterparty-risk benefits. We recommend a scoping call to confirm your specific position.`,
    };
  }
  return {
    likely: false,
    headline: "Registration is likely not required based on this activity alone",
    reasoning:
      `${ACTIVITY_LABELS[answer.activityType]} alone does not typically trigger mandatory DNFBP registration under Cabinet Resolution 134 of 2025. If your firm also facilitates the conclusion of sale/purchase transactions in any capacity, that activity would need to be assessed separately.`,
  };
}

export const SCOPING_DISCLAIMER =
  "This tool provides a preliminary, non-binding indicator only and does not constitute legal or regulatory advice. UAE Cabinet Resolution 134 of 2025 and related AML/CFT Executive Regulations should be assessed against your firm's full activity profile by a qualified advisor. Book a confirmation consultation for a definitive scoping assessment.";
