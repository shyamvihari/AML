import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import type { KycStatus } from "@prisma/client";

const VALID_STATUSES = ["DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "REJECTED", "NEEDS_UPDATE"];

export async function GET(request: Request) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");

  const profiles = await prisma.kycProfile.findMany({
    where: status && VALID_STATUSES.includes(status) ? { status: status as KycStatus } : undefined,
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      companyName: true,
      status: true,
      updatedAt: true,
      user: { select: { name: true, email: true } },
    },
  });

  return NextResponse.json({ profiles });
}
