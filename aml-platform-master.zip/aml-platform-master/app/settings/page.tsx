"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getCurrentUser, logout, type SessionUser } from "@/lib/session";
import { ThemeToggle } from "../ThemeToggle";
import { ChangePasswordForm } from "./ChangePasswordForm";

export default function SettingsPage() {
  const router = useRouter();
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-8 px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Settings</h1>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-medium text-charcoal">Theme</h2>
        <ThemeToggle />
      </section>

      <section className="flex flex-col gap-3 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
        <h2 className="text-lg font-medium text-charcoal">Account</h2>
        {user ? (
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-neutral-500 dark:text-neutral-400">Name</dt>
              <dd>{user.name}</dd>
            </div>
            <div>
              <dt className="text-neutral-500 dark:text-neutral-400">Email</dt>
              <dd>{user.email}</dd>
            </div>
            <div>
              <dt className="text-neutral-500 dark:text-neutral-400">Role</dt>
              <dd className="uppercase">{user.role}</dd>
            </div>
          </dl>
        ) : (
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
        )}
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-medium text-charcoal">Change password</h2>
        <ChangePasswordForm />
      </section>

      {user?.role === "SUPER_ADMIN" && (
        <section className="flex flex-col gap-3 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950 p-4">
          <h2 className="text-lg font-medium text-red-800 dark:text-red-200">Reset all data</h2>
          <p className="text-sm text-red-800 dark:text-red-200">
            Permanently delete every CLIENT and CUSTOMER account, along with their KYC profiles, customers,
            documents, and screening records. Cannot be undone.
          </p>
          <Link
            href="/settings/reset-data"
            className="w-fit rounded-md bg-red-600 dark:bg-red-700 px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Reset all data
          </Link>
        </section>
      )}

      <section>
        <button
          type="button"
          onClick={() => {
            logout();
            router.push("/login");
          }}
          className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
        >
          Log out
        </button>
      </section>
    </div>
  );
}
