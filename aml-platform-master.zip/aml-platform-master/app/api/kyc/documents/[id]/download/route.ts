import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const { id } = await params;
  const document = await prisma.kycDocument.findUnique({ where: { id }, include: { kycProfile: true } });
  if (!document) return NextResponse.json({ error: "Document not found" }, { status: 404 });
  if (payload.role !== "STAFF" && payload.role !== "SUPER_ADMIN" && document.kycProfile.userId !== payload.userId) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  const blobRes = await fetch(document.fileUrl, {
    headers: { authorization: `Bearer ${process.env.BLOB_READ_WRITE_TOKEN}` },
  });
  if (!blobRes.ok || !blobRes.body) {
    return NextResponse.json({ error: "Document could not be retrieved" }, { status: 502 });
  }

  const safeFileName = document.fileName.replace(/["\r\n]/g, "");

  return new NextResponse(blobRes.body, {
    headers: {
      "Content-Type": blobRes.headers.get("content-type") ?? "application/octet-stream",
      "Content-Disposition": `attachment; filename="${safeFileName}"`,
    },
  });
}
