"use client";

import { useState } from "react";
import { LeadForm } from "../LeadForm";

export function ChecklistDownloadForm() {
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <p className="rounded-md bg-offwhite p-4 text-sm text-charcoal">
        Thanks — we've got your details. There's no automatic download here; a member
        of our team will email the UAE Real Estate DNFBP Registration Checklist to the
        address you provided shortly.
      </p>
    );
  }

  return (
    <LeadForm
      source="CHECKLIST_DOWNLOAD"
      submitLabel="Send me the checklist"
      showMessage={false}
      onSuccess={() => setSubmitted(true)}
    />
  );
}
