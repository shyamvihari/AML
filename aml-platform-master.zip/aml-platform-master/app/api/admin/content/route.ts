import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuperAdmin, ForbiddenError } from "@/lib/requireSuperAdmin";
import { UnauthorizedError } from "@/lib/requireAuth";
import { SITE_CONTENT_SECTIONS, SECTION_LABELS } from "@/lib/contentSchemas";

export async function GET(request: Request) {
  try {
    requireSuperAdmin(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const rows = await prisma.siteContent.findMany();
  const bySection = new Map(rows.map((row) => [row.section, row]));
  const sections = SITE_CONTENT_SECTIONS.map((section) => ({
    section,
    label: SECTION_LABELS[section],
    updatedAt: bySection.get(section)?.updatedAt ?? null,
  }));
  return NextResponse.json({ sections });
}
