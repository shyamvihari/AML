"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { getCurrentUser, type SessionUser } from "@/lib/session";

export default function AdminDashboardPage() {
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  if (user && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Super Admin access required.</div>;
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Super Admin</h1>
      <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
        {user ? `Welcome, ${user.name}.` : "Loading..."}
      </p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <Link
          href="/admin/content"
          className="flex flex-col gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6 hover:border-brand-start"
        >
          <h2 className="text-lg font-semibold text-charcoal">Website Content</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-300">
            Edit the homepage hero, the four service pillar summaries, and the About Us page.
          </p>
        </Link>
        <Link
          href="/admin/admins/new"
          className="flex flex-col gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6 hover:border-brand-start"
        >
          <h2 className="text-lg font-semibold text-charcoal">Add Admin</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-300">
            Create a new Admin or Super Admin account.
          </p>
        </Link>
      </div>
    </div>
  );
}
