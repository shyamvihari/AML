import { z } from "zod";

export const SCREENING_RISK_RATINGS = ["LOW", "MEDIUM", "HIGH", "UNRATED"] as const;

export const SCREENING_RISK_RATING_LABELS: Record<(typeof SCREENING_RISK_RATINGS)[number], string> = {
  LOW: "Low",
  MEDIUM: "Medium",
  HIGH: "High",
  UNRATED: "Unrated",
};

export const SCREENING_ALERT_STATUSES = ["OPEN", "CLOSED", "FALSE_POSITIVE"] as const;

export const SCREENING_ALERT_STATUS_LABELS: Record<(typeof SCREENING_ALERT_STATUSES)[number], string> = {
  OPEN: "Open",
  CLOSED: "Closed",
  FALSE_POSITIVE: "False positive",
};

export const screeningIdentificationSchema = z.object({
  identityType: z.string().min(1, "Identity type is required"),
  identificationNumber: z.string().min(1, "Identification number is required"),
  issuingCountry: z.string().optional(),
  placeOfIssue: z.string().optional(),
  dateOfIssuance: z.string().optional(),
  dateOfExpiry: z.string().optional(),
});
export type ScreeningIdentificationInput = z.infer<typeof screeningIdentificationSchema>;

export const screeningMatchSchema = z.object({
  source: z.string().min(1, "Source is required"),
  matchName: z.string().min(1, "Match name is required"),
  matchType: z.string().optional(),
  nationality: z.string().optional(),
  matchScore: z.number().min(0).max(1).optional(),
  sourceEntityId: z.string().optional(),
});
export type ScreeningMatchInput = z.infer<typeof screeningMatchSchema>;

export const screeningRecordInputSchema = z.object({
  subjectName: z.string().min(1, "Subject name is required"),
  customerType: z.string().optional(),
  gender: z.string().optional(),
  dateOfBirth: z.string().optional(),
  riskRating: z.enum(SCREENING_RISK_RATINGS).optional(),
  scannedAt: z.string().optional(),
  screenedBy: z.string().optional(),
  sourcesCheckedCount: z.number().int().min(0).optional(),
  sourcesNote: z.string().optional(),
  alertRaised: z.boolean().optional(),
  alertId: z.string().optional(),
  alertStatus: z.enum(SCREENING_ALERT_STATUSES).optional(),
  sanctionMatchCount: z.number().int().min(0).optional(),
  notes: z.string().optional(),
  identifications: z.array(screeningIdentificationSchema).optional(),
  matches: z.array(screeningMatchSchema).optional(),
});
export type ScreeningRecordInput = z.infer<typeof screeningRecordInputSchema>;
