import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { leadInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = leadInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const lead = await prisma.lead.create({
    data: {
      ...parsed.data,
      payload: parsed.data.payload as Prisma.InputJsonValue | undefined,
    },
  });
  return NextResponse.json({ id: lead.id }, { status: 201 });
}
