import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { generateInviteToken } from "@/lib/auth";
import { createInviteInputSchema } from "@/lib/inviteSchemas";
import { individualKycFieldsSchema, corporateKycFieldsSchema } from "@/lib/customerSchemas";
import { sendWhatsAppInviteLink } from "@/lib/whatsapp";

function buildInviteUrl(token: string, request: Request): string {
  const origin = new URL(request.url).origin;
  return `${origin}/invite/${token}`;
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findFirst({ where: { id, clientUserId: payload.userId } });
  if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

  const invite = await prisma.customerInvite.findFirst({
    where: { customerId: id, consumedAt: null },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ invite: invite ?? null });
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findFirst({ where: { id, clientUserId: payload.userId } });
  if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

  const body = await request.json().catch(() => null);
  const parsed = createInviteInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  if (parsed.data.purpose === "REVIEW_SIGNATURE") {
    // The manual-entry completion case: the client is handing off their
    // already-saved data for the customer to review + sign. Don't let a
    // review link be generated before the required fields are actually saved.
    const schema = customer.customerType === "CORPORATE" ? corporateKycFieldsSchema : individualKycFieldsSchema;
    const fieldsToValidate = {
      name: customer.name ?? undefined,
      dateOfBirth: customer.dateOfBirth ? customer.dateOfBirth.toISOString() : undefined,
      nationality: customer.nationality ?? undefined,
      passportOrEmiratesId: customer.passportOrEmiratesId ?? undefined,
      idExpiryDate: customer.idExpiryDate ? customer.idExpiryDate.toISOString() : undefined,
      residentialAddress: customer.residentialAddress ?? undefined,
      occupation: customer.occupation ?? undefined,
      companyName: customer.companyName ?? undefined,
      tradeLicenseNumber: customer.tradeLicenseNumber ?? undefined,
      licenseAuthority: customer.licenseAuthority ?? undefined,
      incorporationDate: customer.incorporationDate ? customer.incorporationDate.toISOString() : undefined,
      registeredAddress: customer.registeredAddress ?? undefined,
      businessActivity: customer.businessActivity ?? undefined,
      authorizedSignatoryName: customer.authorizedSignatoryName ?? undefined,
      phone: customer.phone ?? undefined,
      email: customer.email,
    };
    const fieldsValid = schema.safeParse(fieldsToValidate);
    if (!fieldsValid.success) {
      return NextResponse.json({ error: "Please complete all required fields before submitting" }, { status: 400 });
    }
  }

  const invite = await prisma.$transaction(async (tx) => {
    await tx.customerInvite.updateMany({
      where: { customerId: id, purpose: parsed.data.purpose, consumedAt: null },
      data: { consumedAt: new Date() },
    });
    if (parsed.data.purpose === "REVIEW_SIGNATURE" && customer.status === "DRAFT") {
      // Manual entry has no separate "submit" step — generating the review/signature
      // link IS the moment the client's manually-entered data is submitted and
      // handed off, awaiting the customer's review + signature.
      await tx.customer.update({ where: { id }, data: { status: "PENDING_REVIEW" } });
    }
    return tx.customerInvite.create({
      data: {
        customerId: id,
        token: generateInviteToken(),
        purpose: parsed.data.purpose,
        customerName: parsed.data.customerName,
        customerPhone: parsed.data.customerPhone,
        customerEmail: parsed.data.customerEmail,
        // Recorded at creation time: whoever is asked to review + sign here is
        // the customer, since it's the client who just finished entering the data.
        intendedSignerUserId: parsed.data.purpose === "REVIEW_SIGNATURE" ? customer.customerUserId : null,
      },
    });
  });

  const inviteUrl = buildInviteUrl(invite.token, request);
  let whatsapp: { attempted: boolean; ok?: boolean; error?: string } = { attempted: false };
  if (parsed.data.customerPhone) {
    const result = await sendWhatsAppInviteLink(parsed.data.customerPhone, inviteUrl);
    whatsapp = result.ok ? { attempted: true, ok: true } : { attempted: true, ok: false, error: result.error };
  }

  return NextResponse.json({ invite, inviteUrl, whatsapp }, { status: 201 });
}
