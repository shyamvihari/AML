import { requireAuth } from "./requireAuth";
import type { TokenPayload } from "./auth";

export class ForbiddenError extends Error {}

export function requireStaff(request: Request): TokenPayload {
  const payload = requireAuth(request);
  if (payload.role !== "STAFF" && payload.role !== "SUPER_ADMIN") throw new ForbiddenError("Staff access required");
  return payload;
}
