import Link from "next/link";
import { SectionHeading } from "../../SectionHeading";

export const metadata = {
  title: "Policy & Registration Advisory | Compass & Coin",
  description:
    "DNFBP registration scoping under Cabinet Resolution 134 of 2025, MOEC/goAML registration, MLRO appointment, and AML policy manual drafting.",
};

const POLICY_MANUAL_CONTENTS = [
  "AML/CFT governance structure and MLRO responsibilities",
  "Customer due diligence and enhanced due diligence procedures",
  "Screening, monitoring, and escalation workflows",
  "Record-keeping standards and retention periods",
  "Suspicious activity reporting and internal escalation paths",
  "Staff training and annual review requirements",
];

export default function PolicyRegistrationPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <SectionHeading
          eyebrow="Pillar B"
          title="Policy & Registration Advisory"
          subtitle="Getting your DNFBP status, registration, and governing policy in order — the foundation everything else in your AML program sits on."
        />

        <div className="flex flex-col gap-10 text-neutral-700 dark:text-neutral-300">
          <section>
            <h3 className="text-xl font-semibold text-charcoal">AML/CFT policy manual drafting</h3>
            <p className="mt-3">
              A registered DNFBP needs a written AML/CFT policy manual describing how the
              business identifies, assesses, and manages money-laundering risk — not a
              generic template, but a document that reflects how your firm actually
              transacts. A typical policy manual we draft for a client covers:
            </p>
            <ul className="mt-4 flex flex-col gap-2">
              {POLICY_MANUAL_CONTENTS.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-start" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4">
              We don't publish sample policy manuals on this site — the content is
              specific to each client's risk profile and would be misleading as a generic
              example. A full outline of what a policy manual covers is available on
              request during a scoping call.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Annual review and gap-assessment audits</h3>
            <p className="mt-3">
              Policies age. Regulatory guidance shifts, business activities expand, and a
              manual written for a five-person brokerage doesn't necessarily still fit
              once the firm has grown or diversified. We run annual gap-assessment audits
              against current obligations and update the policy manual so it stays a
              document a regulator can rely on, not one that was accurate the year it was
              written.
            </p>
          </section>

          <section className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-6">
            <h3 className="text-lg font-semibold text-charcoal">Talk to us about registration and policy</h3>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
              Book a scoping call and we'll confirm whether Cabinet Resolution 134 of
              2025 applies to your business and outline what registration and policy work
              would involve.
            </p>
            <Link
              href="/contact?intent=scoping-call"
              className="mt-4 inline-block rounded-md bg-brand-gradient px-5 py-3 text-sm font-medium text-white hover:opacity-90"
            >
              Book a consultation
            </Link>
          </section>
        </div>
      </div>
    </main>
  );
}
