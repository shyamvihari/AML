import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import { hashPassword, generateTempPassword } from "@/lib/auth";
import { staffCreateClientInputSchema } from "@/lib/staffSchemas";

export async function GET(request: Request) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const clients = await prisma.user.findMany({
    where: { role: "CLIENT" },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      companyName: true,
      plan: true,
      createdAt: true,
      _count: { select: { clientCustomers: true } },
    },
  });

  return NextResponse.json({
    clients: clients.map((c) => ({
      id: c.id,
      name: c.name,
      email: c.email,
      companyName: c.companyName,
      plan: c.plan,
      customerCount: c._count.clientCustomers,
      createdAt: c.createdAt,
    })),
  });
}

export async function POST(request: Request) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = staffCreateClientInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { email, ...fields } = parsed.data;

  const existingUser = await prisma.user.findUnique({ where: { email } });
  if (existingUser) {
    return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
  }

  const tempPassword = generateTempPassword();
  const passwordHash = await hashPassword(tempPassword);

  const client = await prisma.user.create({
    data: {
      name: fields.name,
      email,
      passwordHash,
      companyName: fields.companyName,
      role: "CLIENT",
    },
    select: { id: true, name: true, email: true, companyName: true, plan: true, createdAt: true },
  });

  return NextResponse.json({ client, tempPassword }, { status: 201 });
}
