-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "LeadSource" AS ENUM ('CONTACT_FORM', 'CHECKLIST_DOWNLOAD', 'SCOPING_TOOL', 'HEALTH_CHECK', 'BOOKING_REQUEST');

-- CreateEnum
CREATE TYPE "Persona" AS ENUM ('BROKER', 'DEVELOPER', 'PROPERTY_MANAGER', 'DNFBP_OFFICER', 'FINANCIAL_INSTITUTION', 'OTHER');

-- CreateTable
CREATE TABLE "Lead" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "company" TEXT,
    "persona" "Persona" NOT NULL DEFAULT 'OTHER',
    "source" "LeadSource" NOT NULL,
    "message" TEXT,
    "payload" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Lead_pkey" PRIMARY KEY ("id")
);

