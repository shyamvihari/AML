import { NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireInvite, InviteInvalidError } from "@/lib/requireInvite";
import { CUSTOMER_DOCUMENT_TYPES } from "@/lib/customerSchemas";

export async function POST(request: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }

  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  const type = formData?.get("type");
  if (!(file instanceof File) || typeof type !== "string") {
    return NextResponse.json({ error: "A file and document type are required" }, { status: 400 });
  }
  const MAX_FILE_SIZE = 15 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    return NextResponse.json({ error: "File must be 15MB or smaller" }, { status: 400 });
  }
  if (!(CUSTOMER_DOCUMENT_TYPES as readonly string[]).includes(type)) {
    return NextResponse.json({ error: "Invalid document type" }, { status: 400 });
  }

  const blob = await put(`customer/${invite.customerId}/${Date.now()}-${file.name}`, file, {
    access: "private",
    addRandomSuffix: true,
    token: process.env.BLOB_READ_WRITE_TOKEN,
  });

  const document = await prisma.customerDocument.create({
    data: {
      customerId: invite.customerId,
      type: type as (typeof CUSTOMER_DOCUMENT_TYPES)[number],
      fileName: file.name,
      fileUrl: blob.url,
    },
  });

  return NextResponse.json({ document }, { status: 201 });
}
