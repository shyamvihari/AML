import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET must be set — see .env.example");
}
const JWT_SECRET_VALIDATED: string = JWT_SECRET;

export interface TokenPayload {
  userId: string;
  role: "CLIENT" | "STAFF" | "CUSTOMER" | "SUPER_ADMIN";
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export function signToken(payload: TokenPayload): string {
  return jwt.sign(payload, JWT_SECRET_VALIDATED, { expiresIn: "7d" });
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET_VALIDATED) as TokenPayload;
  } catch {
    return null;
  }
}

export function generateTempPassword(): string {
  return crypto.randomBytes(9).toString("base64url");
}

export function generateInviteToken(): string {
  return crypto.randomBytes(24).toString("base64url");
}
