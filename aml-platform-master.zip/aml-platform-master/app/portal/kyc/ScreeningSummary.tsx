"use client";

import { useEffect, useState } from "react";
import { getClientToken } from "@/lib/session";
import { SCREENING_RISK_RATING_LABELS, SCREENING_ALERT_STATUS_LABELS } from "@/lib/screeningSchemas";

type ScreeningSummaryRecord = {
  id: string;
  subjectName: string;
  riskRating: string;
  alertStatus: string | null;
  scannedAt: string | null;
};

export function ScreeningSummary() {
  const [records, setRecords] = useState<ScreeningSummaryRecord[] | null>(null);

  useEffect(() => {
    const token = getClientToken();
    fetch("/api/kyc/screening", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.json())
      .then((body) => setRecords(body.records ?? []));
  }, []);

  if (!records || records.length === 0) return null;

  return (
    <section className="mt-8 flex flex-col gap-3">
      <h2 className="text-lg font-medium text-charcoal">Screening</h2>
      <ul className="flex flex-col gap-2">
        {records.map((r) => (
          <li key={r.id} className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
            <p className="font-medium text-charcoal">{r.subjectName}</p>
            <p className="text-neutral-500 dark:text-neutral-400">
              Risk: {SCREENING_RISK_RATING_LABELS[r.riskRating as keyof typeof SCREENING_RISK_RATING_LABELS] ?? r.riskRating}
              {r.alertStatus ? ` — Alert: ${SCREENING_ALERT_STATUS_LABELS[r.alertStatus as keyof typeof SCREENING_ALERT_STATUS_LABELS] ?? r.alertStatus}` : ""}
              {r.scannedAt ? ` — Scanned ${new Date(r.scannedAt).toLocaleDateString()}` : ""}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}
