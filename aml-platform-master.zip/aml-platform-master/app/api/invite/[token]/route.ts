import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireInvite, InviteInvalidError } from "@/lib/requireInvite";
import { individualKycFieldsSchema, corporateKycFieldsSchema } from "@/lib/customerSchemas";

export async function GET(request: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }

  const customer = await prisma.customer.findUnique({
    where: { id: invite.customerId },
    select: {
      id: true,
      customerType: true,
      name: true,
      companyName: true,
      email: true,
      phone: true,
      nationality: true,
      dateOfBirth: true,
      passportOrEmiratesId: true,
      idExpiryDate: true,
      residentialAddress: true,
      occupation: true,
      tradeLicenseNumber: true,
      licenseAuthority: true,
      incorporationDate: true,
      registeredAddress: true,
      businessActivity: true,
      authorizedSignatoryName: true,
      documents: { orderBy: { uploadedAt: "asc" } },
    },
  });
  return NextResponse.json({ purpose: invite.purpose, customer });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }
  if (invite.purpose !== "DATA_ENTRY") {
    return NextResponse.json({ error: "This link does not accept detail edits" }, { status: 400 });
  }
  if (invite.customer.status === "COMPLETED") {
    return NextResponse.json({ error: "This record has already been completed" }, { status: 400 });
  }

  const body = await request.json().catch(() => null);
  const schema = invite.customer.customerType === "CORPORATE" ? corporateKycFieldsSchema : individualKycFieldsSchema;
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const data =
    invite.customer.customerType === "CORPORATE"
      ? { ...parsed.data, incorporationDate: new Date((parsed.data as { incorporationDate: string }).incorporationDate) }
      : {
          ...parsed.data,
          dateOfBirth: new Date((parsed.data as { dateOfBirth: string }).dateOfBirth),
          idExpiryDate: new Date((parsed.data as { idExpiryDate: string }).idExpiryDate),
        };

  const customer = await prisma.customer.update({ where: { id: invite.customerId }, data });
  return NextResponse.json({ customer });
}
