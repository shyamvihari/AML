import { NextResponse } from "next/server";
import { del } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireInvite, InviteInvalidError } from "@/lib/requireInvite";

export async function DELETE(request: Request, { params }: { params: Promise<{ token: string; docId: string }> }) {
  const { token, docId } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }

  const document = await prisma.customerDocument.findUnique({ where: { id: docId } });
  if (!document || document.customerId !== invite.customerId) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  await del(document.fileUrl, { token: process.env.BLOB_READ_WRITE_TOKEN });
  await prisma.customerDocument.delete({ where: { id: docId } });

  return NextResponse.json({});
}
