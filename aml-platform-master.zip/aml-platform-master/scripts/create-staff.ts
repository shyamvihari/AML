import { prisma } from "../lib/prisma";
import { hashPassword } from "../lib/auth";

async function main() {
  const args = process.argv.slice(2);
  const roleFlagIndex = args.findIndex((a) => a.startsWith("--role="));
  const role = roleFlagIndex >= 0 ? args[roleFlagIndex].split("=")[1] : "STAFF";
  const positional = args.filter((a) => !a.startsWith("--role="));
  const [email, password, name] = positional;

  if (!email || !password || !name) {
    console.error("Usage: npx tsx scripts/create-staff.ts <email> <password> <name> [--role=STAFF|SUPER_ADMIN]");
    process.exit(1);
  }
  if (role !== "STAFF" && role !== "SUPER_ADMIN") {
    console.error(`Invalid role "${role}". Must be STAFF or SUPER_ADMIN.`);
    process.exit(1);
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.error(`A user with email ${email} already exists (role: ${existing.role}).`);
    process.exit(1);
  }

  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({
    data: { name, email, passwordHash, role },
  });
  console.log(`Created ${user.role} user ${user.email} (id: ${user.id}).`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
