export interface HealthCheckQuestion {
  id: string;
  text: string;
}

export const HEALTH_CHECK_QUESTIONS: HealthCheckQuestion[] = [
  { id: "policy", text: "Does your firm have a documented, Board-approved AML/CFT policy?" },
  { id: "screening_onboarding", text: "Do you screen buyers/sellers against sanctions and PEP lists at onboarding?" },
  { id: "screening_ongoing", text: "Do you re-screen existing clients on an ongoing basis?" },
  { id: "mlro", text: "Do you have a designated Compliance Officer / MLRO?" },
  { id: "cdd_edd", text: "Do you conduct risk-based CDD vs. EDD routing for clients?" },
  { id: "ubo", text: "Do you maintain UBO/beneficial-ownership records for corporate clients?" },
  { id: "sar_process", text: "Do you have a documented process for filing SARs/STRs?" },
  { id: "compliance_calendar", text: "Do you track statutory compliance deadlines (policy renewal, training, audits)?" },
  { id: "staff_training", text: "Have your staff completed AML red-flag training in the last 12 months?" },
  { id: "record_retention", text: "Do you retain KYC/screening records per statutory retention requirements?" },
  { id: "audit_trail", text: "Do you have an audit trail for risk-rating changes and screening decisions?" },
  { id: "gap_assessment", text: "Have you had an independent AML gap-assessment or mock audit in the last 12 months?" },
];

export interface HealthCheckResult {
  score: number;
  maxScore: number;
  tier: "LOW" | "MODERATE" | "STRONG";
  summary: string;
}

export function computeHealthCheckScore(answers: Record<string, boolean>): HealthCheckResult {
  const maxScore = HEALTH_CHECK_QUESTIONS.length;
  const score = HEALTH_CHECK_QUESTIONS.reduce((sum, q) => sum + (answers[q.id] ? 1 : 0), 0);
  const pct = score / maxScore;

  if (pct < 0.4) {
    return {
      score,
      maxScore,
      tier: "LOW",
      summary:
        "Your current AML maturity shows significant gaps against the core requirements for UAE real estate DNFBPs. We recommend prioritising a documented AML/CFT policy, onboarding screening, and a designated Compliance Officer as immediate next steps.",
    };
  }
  if (pct < 0.75) {
    return {
      score,
      maxScore,
      tier: "MODERATE",
      summary:
        "Your firm has foundational AML practices in place, but there are meaningful gaps — particularly around ongoing monitoring, audit trails, or staff training — that would likely surface in a regulator or bank due-diligence review.",
    };
  }
  return {
    score,
    maxScore,
    tier: "STRONG",
    summary:
      "Your firm demonstrates strong AML maturity across policy, screening, and reporting. A periodic independent gap-assessment is still recommended to stay current with evolving Cabinet Resolution 134 requirements.",
  };
}
