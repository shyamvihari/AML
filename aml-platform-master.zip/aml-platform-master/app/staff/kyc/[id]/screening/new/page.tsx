"use client";

import { use, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";
import {
  SCREENING_RISK_RATINGS,
  SCREENING_RISK_RATING_LABELS,
  SCREENING_ALERT_STATUSES,
  SCREENING_ALERT_STATUS_LABELS,
  type ScreeningIdentificationInput,
  type ScreeningMatchInput,
} from "@/lib/screeningSchemas";

const EMPTY_IDENTIFICATION: ScreeningIdentificationInput = {
  identityType: "",
  identificationNumber: "",
  issuingCountry: "",
  placeOfIssue: "",
  dateOfIssuance: "",
  dateOfExpiry: "",
};

const EMPTY_MATCH: ScreeningMatchInput = { source: "", matchName: "", matchType: "", nationality: "" };

export default function NewScreeningRecordPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();

  const [subjectName, setSubjectName] = useState("");
  const [customerType, setCustomerType] = useState("");
  const [gender, setGender] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [riskRating, setRiskRating] = useState<(typeof SCREENING_RISK_RATINGS)[number]>("UNRATED");
  const [scannedAt, setScannedAt] = useState("");
  const [screenedBy, setScreenedBy] = useState("");
  const [sourcesCheckedCount, setSourcesCheckedCount] = useState("");
  const [sourcesNote, setSourcesNote] = useState("");
  const [alertRaised, setAlertRaised] = useState(false);
  const [alertId, setAlertId] = useState("");
  const [alertStatus, setAlertStatus] = useState<(typeof SCREENING_ALERT_STATUSES)[number] | "">("");
  const [sanctionMatchCount, setSanctionMatchCount] = useState("0");
  const [notes, setNotes] = useState("");
  const [identifications, setIdentifications] = useState<ScreeningIdentificationInput[]>([{ ...EMPTY_IDENTIFICATION }]);
  const [matches, setMatches] = useState<ScreeningMatchInput[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [runningScreening, setRunningScreening] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  async function runScreening() {
    setRunningScreening(true);
    setRunError(null);
    const token = getClientToken();
    const res = await fetch(`/api/staff/kyc/${id}/screening/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ subjectName, dateOfBirth: dateOfBirth || undefined }),
    });
    if (!res.ok) {
      setRunError("Could not run screening. Please try again or enter matches manually.");
      setRunningScreening(false);
      return;
    }
    const body = await res.json();
    setMatches(body.matches);
    setRiskRating(body.suggestedRiskRating);
    setScannedAt(new Date().toISOString().slice(0, 10));
    setScreenedBy("OpenSanctions");
    setSanctionMatchCount(String(body.sanctionMatchCount));
    setRunningScreening(false);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const token = getClientToken();
    const payload = {
      subjectName,
      customerType: customerType || undefined,
      gender: gender || undefined,
      dateOfBirth: dateOfBirth || undefined,
      riskRating,
      scannedAt: scannedAt || undefined,
      screenedBy: screenedBy || undefined,
      sourcesCheckedCount: sourcesCheckedCount ? Number(sourcesCheckedCount) : undefined,
      sourcesNote: sourcesNote || undefined,
      alertRaised,
      alertId: alertId || undefined,
      alertStatus: alertStatus || undefined,
      sanctionMatchCount: sanctionMatchCount ? Number(sanctionMatchCount) : 0,
      notes: notes || undefined,
      identifications: identifications
        .filter((i) => i.identityType.trim() && i.identificationNumber.trim())
        .map((i) => ({
          identityType: i.identityType,
          identificationNumber: i.identificationNumber,
          issuingCountry: i.issuingCountry || undefined,
          placeOfIssue: i.placeOfIssue || undefined,
          dateOfIssuance: i.dateOfIssuance || undefined,
          dateOfExpiry: i.dateOfExpiry || undefined,
        })),
      matches: matches
        .filter((m) => m.source.trim() && m.matchName.trim())
        .map((m) => ({
          source: m.source,
          matchName: m.matchName,
          matchType: m.matchType || undefined,
          nationality: m.nationality || undefined,
          matchScore: m.matchScore,
          sourceEntityId: m.sourceEntityId,
        })),
    };
    const res = await fetch(`/api/staff/kyc/${id}/screening`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      setError("Could not save. Please check the form and try again.");
      setSaving(false);
      return;
    }
    router.push(`/staff/kyc/${id}`);
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">New screening record</h1>

      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <form onSubmit={submit} className="mt-6 flex flex-col gap-8">
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Customer summary</h2>
          <label className={labelClass}>
            Subject name
            <input required value={subjectName} onChange={(e) => setSubjectName(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Customer type
            <input value={customerType} onChange={(e) => setCustomerType(e.target.value)} placeholder="Individual" className={inputClass} />
          </label>
          <label className={labelClass}>
            Gender
            <input value={gender} onChange={(e) => setGender(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Date of birth
            <input type="date" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} className={inputClass} />
          </label>
          <button
            type="button"
            onClick={runScreening}
            disabled={!subjectName.trim() || runningScreening}
            className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite disabled:opacity-50"
          >
            {runningScreening ? "Running screening..." : "Run screening"}
          </button>
          {runError && <p className="text-sm text-red-600 dark:text-red-400">{runError}</p>}
          <label className={labelClass}>
            Risk rating
            <select value={riskRating} onChange={(e) => setRiskRating(e.target.value as typeof riskRating)} className={inputClass}>
              {SCREENING_RISK_RATINGS.map((r) => (
                <option key={r} value={r}>{SCREENING_RISK_RATING_LABELS[r]}</option>
              ))}
            </select>
          </label>
          <label className={labelClass}>
            Scanned date
            <input type="date" value={scannedAt} onChange={(e) => setScannedAt(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Screened by
            <input value={screenedBy} onChange={(e) => setScreenedBy(e.target.value)} placeholder="IntelleWings" className={inputClass} />
          </label>
          <label className={labelClass}>
            Sources checked (count)
            <input type="number" min={0} value={sourcesCheckedCount} onChange={(e) => setSourcesCheckedCount(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Sources note (optional)
            <textarea value={sourcesNote} onChange={(e) => setSourcesNote(e.target.value)} rows={2} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Identification records</h2>
          {identifications.map((ident, index) => (
            <div key={index} className="grid grid-cols-2 gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-3">
              <input placeholder="Identity type (Passport, Emirates ID...)" value={ident.identityType} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, identityType: e.target.value } : it)))} className={inputClass} />
              <input placeholder="Identification number" value={ident.identificationNumber} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, identificationNumber: e.target.value } : it)))} className={inputClass} />
              <input placeholder="Issuing country" value={ident.issuingCountry ?? ""} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, issuingCountry: e.target.value } : it)))} className={inputClass} />
              <input placeholder="Place of issue" value={ident.placeOfIssue ?? ""} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, placeOfIssue: e.target.value } : it)))} className={inputClass} />
              <input type="date" placeholder="Date of issuance" value={ident.dateOfIssuance ?? ""} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, dateOfIssuance: e.target.value } : it)))} className={inputClass} />
              <input type="date" placeholder="Date of expiry" value={ident.dateOfExpiry ?? ""} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, dateOfExpiry: e.target.value } : it)))} className={inputClass} />
              <button type="button" onClick={() => setIdentifications((prev) => prev.filter((_, i) => i !== index))} className="text-sm text-red-600 dark:text-red-400">
                Remove
              </button>
            </div>
          ))}
          <button type="button" onClick={() => setIdentifications((prev) => [...prev, { ...EMPTY_IDENTIFICATION }])} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite">
            Add identification record
          </button>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Alert summary</h2>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={alertRaised} onChange={(e) => setAlertRaised(e.target.checked)} />
            Alert raised
          </label>
          <label className={labelClass}>
            Alert ID
            <input value={alertId} onChange={(e) => setAlertId(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Alert status
            <select value={alertStatus} onChange={(e) => setAlertStatus(e.target.value as typeof alertStatus)} className={inputClass}>
              <option value="">Select...</option>
              {SCREENING_ALERT_STATUSES.map((s) => (
                <option key={s} value={s}>{SCREENING_ALERT_STATUS_LABELS[s]}</option>
              ))}
            </select>
          </label>
          <label className={labelClass}>
            Sanction match count
            <input type="number" min={0} value={sanctionMatchCount} onChange={(e) => setSanctionMatchCount(e.target.value)} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Sanction / PEP matches</h2>
          {matches.map((m, index) => (
            <div key={index} className="grid grid-cols-2 gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-3">
              <input placeholder="Source list" value={m.source} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, source: e.target.value } : mm)))} className={inputClass} />
              <input placeholder="Matched name" value={m.matchName} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, matchName: e.target.value } : mm)))} className={inputClass} />
              <input placeholder="Match type" value={m.matchType ?? ""} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, matchType: e.target.value } : mm)))} className={inputClass} />
              <input placeholder="Nationality" value={m.nationality ?? ""} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, nationality: e.target.value } : mm)))} className={inputClass} />
              <button type="button" onClick={() => setMatches((prev) => prev.filter((_, i) => i !== index))} className="text-sm text-red-600 dark:text-red-400">
                Remove
              </button>
            </div>
          ))}
          <button type="button" onClick={() => setMatches((prev) => [...prev, { ...EMPTY_MATCH }])} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite">
            Add match
          </button>
        </section>

        <section className="flex flex-col gap-3">
          <label className={labelClass}>
            Notes
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className={inputClass} />
          </label>
        </section>

        <button type="submit" disabled={saving} className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50">
          {saving ? "Saving..." : "Save screening record"}
        </button>
      </form>
    </div>
  );
}
