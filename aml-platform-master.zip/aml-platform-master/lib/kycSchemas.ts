import { z } from "zod";

export const ENTITY_TYPES = [
  "SOLE_PROPRIETORSHIP",
  "PARTNERSHIP",
  "FREE_ZONE",
  "LLC",
  "PJSC_PSC",
  "ASSOCIATION_CLUB_SOCIETY",
  "OTHER",
] as const;

export const ENTITY_TYPE_LABELS: Record<(typeof ENTITY_TYPES)[number], string> = {
  SOLE_PROPRIETORSHIP: "Sole Proprietorship",
  PARTNERSHIP: "Partnership",
  FREE_ZONE: "Free Zone (FZE / FZCO)",
  LLC: "LLC",
  PJSC_PSC: "PJSC & PSC",
  ASSOCIATION_CLUB_SOCIETY: "Association / Club / Society",
  OTHER: "Others",
};

export const RELATED_COMPANY_SCOPES = ["NONE", "LOCAL", "INTERNATIONAL", "BOTH"] as const;

export const RELATED_COMPANY_SCOPE_LABELS: Record<(typeof RELATED_COMPANY_SCOPES)[number], string> = {
  NONE: "No",
  LOCAL: "Yes — locally",
  INTERNATIONAL: "Yes — internationally",
  BOTH: "Yes — locally and internationally",
};

export const KYC_DOCUMENT_TYPES = ["TRADE_LICENSE", "GOAML_SCREENSHOT", "OWNER_ID", "OTHER"] as const;

export const KYC_DOCUMENT_TYPE_LABELS: Record<(typeof KYC_DOCUMENT_TYPES)[number], string> = {
  TRADE_LICENSE: "Trade License",
  GOAML_SCREENSHOT: "goAML Screenshot",
  OWNER_ID: "Owner / Director ID",
  OTHER: "Other",
};

export const kycOwnerInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  designation: z.string().nullable().optional(),
  nationality: z.string().nullable().optional(),
  mobileIdType: z.string().nullable().optional(),
  percentShare: z.number().min(0).max(100).nullable().optional(),
});
export type KycOwnerInput = z.infer<typeof kycOwnerInputSchema>;

export const kycProfileDraftSchema = z.object({
  entityType: z.union([z.enum(ENTITY_TYPES), z.literal("")]).optional(),
  entityTypeOther: z.string().optional(),
  companyName: z.string().optional(),
  coreBusinessActivity: z.string().optional(),

  licenseNumber: z.string().optional(),
  licenseIssueDate: z.string().optional(),
  licenseExpiryDate: z.string().optional(),
  countryOfRegistration: z.string().optional(),
  licenseIssuingAuthority: z.string().optional(),
  dateOfIncorporation: z.string().optional(),

  poBox: z.string().optional(),
  telephone: z.string().optional(),
  emirate: z.string().optional(),
  trn: z.string().optional(),
  orn: z.string().optional(),
  registeredEmail: z.string().optional(),

  contactPersonName: z.string().optional(),
  contactPersonDesignation: z.string().optional(),
  contactPersonMobile: z.string().optional(),
  contactPersonEmail: z.string().optional(),

  estimatedAnnualTurnover: z.string().optional(),
  relatedCompanyScope: z.enum(RELATED_COMPANY_SCOPES).optional(),

  authorizedSignatoryName: z.string().optional(),
  declarationDate: z.string().optional(),

  owners: z.array(kycOwnerInputSchema).optional(),
});
export type KycProfileDraftInput = z.infer<typeof kycProfileDraftSchema>;

export const kycSubmitSchema = z.object({
  entityType: z.enum(ENTITY_TYPES),
  companyName: z.string().min(1, "Company name is required"),
  coreBusinessActivity: z.string().min(1, "Core business activity is required"),

  licenseNumber: z.string().min(1, "License number is required"),
  licenseIssueDate: z.string().min(1, "License issue date is required"),
  licenseExpiryDate: z.string().min(1, "License expiry date is required"),
  countryOfRegistration: z.string().min(1, "Country of registration is required"),
  licenseIssuingAuthority: z.string().min(1, "License issuing authority is required"),
  dateOfIncorporation: z.string().min(1, "Date of incorporation is required"),

  poBox: z.string().min(1, "P.O. Box is required"),
  emirate: z.string().min(1, "Emirate is required"),
  registeredEmail: z.string().email("Valid registered email is required"),

  contactPersonName: z.string().min(1, "Contact person name is required"),
  contactPersonEmail: z.string().email("Valid contact person email is required"),

  estimatedAnnualTurnover: z.string().min(1, "Estimated annual turnover is required"),

  authorizedSignatoryName: z.string().min(1, "Authorized signatory name is required"),
  declarationDate: z.string().min(1, "Declaration date is required"),
  declarationConsent: z.literal(true),

  owners: z.array(kycOwnerInputSchema).min(1, "At least one owner/director/shareholder is required"),
});
export type KycSubmitInput = z.infer<typeof kycSubmitSchema>;
