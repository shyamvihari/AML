"use client";

import { use, useState } from "react";
import { useRouter } from "next/navigation";
import { getClientToken } from "@/lib/session";
import {
  CUSTOMER_SCREENING_RISK_RATINGS,
  CUSTOMER_SCREENING_RISK_RATING_LABELS,
  type CustomerScreeningIdentificationInput,
  type CustomerScreeningMatchInput,
} from "@/lib/customerSchemas";

const EMPTY_IDENTIFICATION: CustomerScreeningIdentificationInput = { identityType: "", identificationNumber: "" };
const EMPTY_MATCH: CustomerScreeningMatchInput = { source: "", matchName: "" };

export default function NewCustomerScreeningPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();

  const [subjectName, setSubjectName] = useState("");
  const [riskRating, setRiskRating] = useState<(typeof CUSTOMER_SCREENING_RISK_RATINGS)[number]>("UNRATED");
  const [scannedAt, setScannedAt] = useState("");
  const [screenedBy, setScreenedBy] = useState("");
  const [alertRaised, setAlertRaised] = useState(false);
  const [sanctionMatchCount, setSanctionMatchCount] = useState("0");
  const [notes, setNotes] = useState("");
  const [identifications, setIdentifications] = useState<CustomerScreeningIdentificationInput[]>([{ ...EMPTY_IDENTIFICATION }]);
  const [matches, setMatches] = useState<CustomerScreeningMatchInput[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [runningScreening, setRunningScreening] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  async function runScreening() {
    setRunningScreening(true);
    setRunError(null);
    const token = getClientToken();
    const res = await fetch(`/api/portal/customers/${id}/screening/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ subjectName }),
    });
    if (!res.ok) {
      setRunError("Could not run screening. Please try again or enter matches manually.");
      setRunningScreening(false);
      return;
    }
    const body = await res.json();
    setMatches(body.matches);
    setRiskRating(body.suggestedRiskRating);
    setScannedAt(new Date().toISOString().slice(0, 10));
    setScreenedBy("OpenSanctions");
    setSanctionMatchCount(String(body.sanctionMatchCount));
    setRunningScreening(false);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const token = getClientToken();
    const payload = {
      subjectName,
      riskRating,
      scannedAt: scannedAt || undefined,
      screenedBy: screenedBy || undefined,
      alertRaised,
      sanctionMatchCount: sanctionMatchCount ? Number(sanctionMatchCount) : 0,
      notes: notes || undefined,
      identifications: identifications
        .filter((i) => i.identityType.trim() && i.identificationNumber.trim())
        .map((i) => ({ identityType: i.identityType, identificationNumber: i.identificationNumber })),
      matches: matches
        .filter((m) => m.source.trim() && m.matchName.trim())
        .map((m) => ({ source: m.source, matchName: m.matchName, matchScore: m.matchScore, sourceEntityId: m.sourceEntityId })),
    };
    const res = await fetch(`/api/portal/customers/${id}/screening`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(typeof body.error === "string" ? body.error : "Could not save. Please check the form and try again.");
      setSaving(false);
      return;
    }
    router.push(`/portal/customers/${id}`);
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Screen this customer</h1>
      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <form onSubmit={submit} className="mt-6 flex flex-col gap-8">
        <section className="flex flex-col gap-3">
          <label className={labelClass}>
            Subject name
            <input required value={subjectName} onChange={(e) => setSubjectName(e.target.value)} className={inputClass} />
          </label>
          <button
            type="button"
            onClick={runScreening}
            disabled={!subjectName.trim() || runningScreening}
            className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite disabled:opacity-50"
          >
            {runningScreening ? "Running screening..." : "Run screening"}
          </button>
          {runError && <p className="text-sm text-red-600 dark:text-red-400">{runError}</p>}
          <label className={labelClass}>
            Risk rating
            <select value={riskRating} onChange={(e) => setRiskRating(e.target.value as typeof riskRating)} className={inputClass}>
              {CUSTOMER_SCREENING_RISK_RATINGS.map((r) => (
                <option key={r} value={r}>{CUSTOMER_SCREENING_RISK_RATING_LABELS[r]}</option>
              ))}
            </select>
          </label>
          <label className={labelClass}>
            Scanned date
            <input type="date" value={scannedAt} onChange={(e) => setScannedAt(e.target.value)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Screened by
            <input value={screenedBy} onChange={(e) => setScreenedBy(e.target.value)} placeholder="OpenSanctions, IntelleWings..." className={inputClass} />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={alertRaised} onChange={(e) => setAlertRaised(e.target.checked)} />
            Alert raised
          </label>
          <label className={labelClass}>
            Sanction match count
            <input type="number" min={0} value={sanctionMatchCount} onChange={(e) => setSanctionMatchCount(e.target.value)} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Identification records</h2>
          {identifications.map((ident, index) => (
            <div key={index} className="grid grid-cols-2 gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-3">
              <input placeholder="Identity type" value={ident.identityType} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, identityType: e.target.value } : it)))} className={inputClass} />
              <input placeholder="Identification number" value={ident.identificationNumber} onChange={(e) => setIdentifications((prev) => prev.map((it, i) => (i === index ? { ...it, identificationNumber: e.target.value } : it)))} className={inputClass} />
              <button type="button" onClick={() => setIdentifications((prev) => prev.filter((_, i) => i !== index))} className="text-sm text-red-600 dark:text-red-400">
                Remove
              </button>
            </div>
          ))}
          <button type="button" onClick={() => setIdentifications((prev) => [...prev, { ...EMPTY_IDENTIFICATION }])} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite">
            Add identification record
          </button>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Sanction / PEP matches</h2>
          {matches.map((m, index) => (
            <div key={index} className="grid grid-cols-2 gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-3">
              <input placeholder="Source list" value={m.source} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, source: e.target.value } : mm)))} className={inputClass} />
              <input placeholder="Matched name" value={m.matchName} onChange={(e) => setMatches((prev) => prev.map((mm, i) => (i === index ? { ...mm, matchName: e.target.value } : mm)))} className={inputClass} />
              <button type="button" onClick={() => setMatches((prev) => prev.filter((_, i) => i !== index))} className="text-sm text-red-600 dark:text-red-400">
                Remove
              </button>
            </div>
          ))}
          <button type="button" onClick={() => setMatches((prev) => [...prev, { ...EMPTY_MATCH }])} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite">
            Add match
          </button>
        </section>

        <label className={labelClass}>
          Notes
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className={inputClass} />
        </label>

        <button type="submit" disabled={saving} className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50">
          {saving ? "Saving..." : "Save screening record"}
        </button>
      </form>
    </div>
  );
}
