import { z } from "zod";

export const SITE_CONTENT_SECTIONS = [
  "home_hero",
  "pillar_kyc",
  "pillar_policy",
  "pillar_screening",
  "pillar_reporting",
  "about_us",
] as const;
export type SiteContentSection = (typeof SITE_CONTENT_SECTIONS)[number];

export const SECTION_LABELS: Record<SiteContentSection, string> = {
  home_hero: "Homepage Hero",
  pillar_kyc: "KYC & Onboarding (homepage card)",
  pillar_policy: "Policy & Registration (homepage card)",
  pillar_screening: "Screening (homepage card)",
  pillar_reporting: "Reporting (homepage card)",
  about_us: "About Us",
};

export function isSiteContentSection(value: string): value is SiteContentSection {
  return (SITE_CONTENT_SECTIONS as readonly string[]).includes(value);
}

const heroSchema = z.object({
  titleStart: z.string().min(1, "Required"),
  titleHighlight: z.string().min(1, "Required"),
  subtitle: z.string().min(1, "Required"),
});
export type HeroData = z.infer<typeof heroSchema>;

const pillarSchema = z.object({
  title: z.string().min(1, "Required"),
  description: z.string().min(1, "Required"),
});
export type PillarData = z.infer<typeof pillarSchema>;

const aboutUsSchema = z.object({
  eyebrow: z.string().min(1, "Required"),
  title: z.string().min(1, "Required"),
  subtitle: z.string().min(1, "Required"),
  blocks: z
    .array(
      z.object({
        heading: z.string().nullable(),
        body: z.string().min(1, "Required"),
      }),
    )
    .min(1, "At least one block is required"),
});
export type AboutUsData = z.infer<typeof aboutUsSchema>;

export const SECTION_SCHEMAS: Record<SiteContentSection, z.ZodTypeAny> = {
  home_hero: heroSchema,
  pillar_kyc: pillarSchema,
  pillar_policy: pillarSchema,
  pillar_screening: pillarSchema,
  pillar_reporting: pillarSchema,
  about_us: aboutUsSchema,
};
