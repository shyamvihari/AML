"use client";

import { use, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";
import { SCREENING_RISK_RATING_LABELS, SCREENING_ALERT_STATUS_LABELS } from "@/lib/screeningSchemas";

type ScreeningDetail = {
  id: string;
  subjectName: string;
  customerType: string | null;
  gender: string | null;
  dateOfBirth: string | null;
  riskRating: string;
  scannedAt: string | null;
  screenedBy: string | null;
  sourcesCheckedCount: number | null;
  sourcesNote: string | null;
  alertRaised: boolean;
  alertId: string | null;
  alertStatus: string | null;
  sanctionMatchCount: number;
  notes: string | null;
  identifications: { identityType: string; identificationNumber: string; issuingCountry: string | null; placeOfIssue: string | null; dateOfIssuance: string | null; dateOfExpiry: string | null }[];
  matches: { source: string; matchName: string; matchType: string | null; nationality: string | null; matchScore: number | null }[];
  kycProfile: { companyName: string | null };
};

function fmt(v: string | null) {
  return v ? new Date(v).toLocaleDateString() : "—";
}

export default function ScreeningDetailPage({ params }: { params: Promise<{ id: string; screeningId: string }> }) {
  const { id, screeningId } = use(params);
  const router = useRouter();
  const [record, setRecord] = useState<ScreeningDetail | null>(null);
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (user?.role !== "STAFF" && user?.role !== "SUPER_ADMIN") return;
    const token = getClientToken();
    fetch(`/api/staff/screening/${screeningId}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.json())
      .then((body) => setRecord(body.record));
  }, [screeningId, user]);

  async function remove() {
    const token = getClientToken();
    await fetch(`/api/staff/screening/${screeningId}`, {
      method: "DELETE",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    router.push(`/staff/kyc/${id}`);
  }

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }
  if (!record) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Screening: {record.subjectName}</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400">{record.kycProfile.companyName ?? "(no company name)"}</p>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Customer summary</h2>
        <dl className="grid grid-cols-2 gap-2">
          <div><dt className="text-neutral-500 dark:text-neutral-400">Customer type</dt><dd>{record.customerType ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Gender</dt><dd>{record.gender ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Date of birth</dt><dd>{fmt(record.dateOfBirth)}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Risk rating</dt><dd>{SCREENING_RISK_RATING_LABELS[record.riskRating as keyof typeof SCREENING_RISK_RATING_LABELS] ?? record.riskRating}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Scanned date</dt><dd>{fmt(record.scannedAt)}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Screened by</dt><dd>{record.screenedBy ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Sources checked</dt><dd>{record.sourcesCheckedCount ?? "—"}</dd></div>
        </dl>
        {record.sourcesNote && <p className="mt-2 text-neutral-600 dark:text-neutral-300">{record.sourcesNote}</p>}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Identification records</h2>
        {record.identifications.length ? (
          <ul className="flex flex-col gap-1">
            {record.identifications.map((ident, i) => (
              <li key={i}>{ident.identityType} — {ident.identificationNumber} — {ident.issuingCountry ?? "—"} — issued {fmt(ident.dateOfIssuance)}, expires {fmt(ident.dateOfExpiry)}</li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None recorded.</p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Alert summary</h2>
        <dl className="grid grid-cols-2 gap-2">
          <div><dt className="text-neutral-500 dark:text-neutral-400">Alert raised</dt><dd>{record.alertRaised ? "Yes" : "No"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Alert ID</dt><dd>{record.alertId ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Alert status</dt><dd>{record.alertStatus ? SCREENING_ALERT_STATUS_LABELS[record.alertStatus as keyof typeof SCREENING_ALERT_STATUS_LABELS] : "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Sanction match count</dt><dd>{record.sanctionMatchCount}</dd></div>
        </dl>
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Sanction / PEP matches</h2>
        {record.matches.length ? (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
                <th className="py-2">Source</th>
                <th className="py-2">Name</th>
                <th className="py-2">Type</th>
                <th className="py-2">Nationality</th>
                <th className="py-2">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {record.matches.map((m, i) => (
                <tr key={i}>
                  <td className="py-2">{m.source}</td>
                  <td className="py-2">{m.matchName}</td>
                  <td className="py-2">{m.matchType ?? "—"}</td>
                  <td className="py-2">{m.nationality ?? "—"}</td>
                  <td className="py-2">{m.matchScore != null ? `${Math.round(m.matchScore * 100)}%` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">None recorded.</p>
        )}
      </section>

      {record.notes && (
        <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
          <h2 className="mb-2 font-medium text-charcoal">Notes</h2>
          <p className="text-neutral-600 dark:text-neutral-300">{record.notes}</p>
        </section>
      )}

      <button
        type="button"
        onClick={remove}
        className="mt-6 rounded-md border border-red-300 dark:border-red-800 px-4 py-2 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950"
      >
        Delete screening record
      </button>
    </div>
  );
}
