-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'SUPER_ADMIN';

-- CreateTable
CREATE TABLE "SiteContent" (
    "id" TEXT NOT NULL,
    "section" TEXT NOT NULL,
    "data" JSONB NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "updatedByUserId" TEXT,

    CONSTRAINT "SiteContent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "SiteContent_section_key" ON "SiteContent"("section");


-- Seed the six editable sections with today's hardcoded copy, so nothing
-- visually changes on the site until a Super Admin makes an edit.
INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-home-hero', 'home_hero', $json$
{"titleStart": "AML and KYC compliance built for", "titleHighlight": "UAE real estate DNFBPs", "subtitle": "Compass & Coin is a Dubai-based advisory practice focused exclusively on anti-money-laundering compliance for real estate brokers, developers, property managers, and other designated non-financial businesses and professions. We help you register, screen, document, and report to the standard UAE regulators expect — and keep you audit-ready as those obligations evolve."}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;

INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-pillar-kyc', 'pillar_kyc', $json$
{"title": "KYC & Onboarding", "description": "Risk-based customer due diligence, UBO and beneficial-ownership record-keeping, and EDD routing for higher-risk clients."}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;

INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-pillar-policy', 'pillar_policy', $json$
{"title": "Policy & Registration", "description": "DNFBP registration guidance under Cabinet Resolution 134 of 2025, MOEC/goAML registration, and drafting the AML policies your designated Compliance Officer needs on file."}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;

INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-pillar-screening', 'pillar_screening', $json$
{"title": "Screening", "description": "Sanctions, PEP, and adverse-media screening at onboarding, with ongoing re-screening so existing client relationships stay current as watchlists change."}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;

INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-pillar-reporting', 'pillar_reporting', $json$
{"title": "Reporting", "description": "SAR/STR drafting and filing support, goAML submission tracking, and a compliance calendar that keeps policy renewals, training, and audits on schedule."}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;

INSERT INTO "SiteContent" (id, section, data, "updatedAt") VALUES
('sitecontent-about-us', 'about_us', $json$
{"eyebrow": "About Us", "title": "A compliance practice, built to scale", "subtitle": "Compass & Coin Technologies FZE converts hands-on AML advisory experience into a repeatable, technology-enabled service for Dubai's DNFBP sector.", "blocks": [{"heading": null, "body": "Compass & Coin began as a founder-led AML advisory practice working directly with Designated Non-Financial Businesses and Professions (DNFBPs) across Dubai. That hands-on work — registering entities under Cabinet Resolution 134 of 2025, building AML policies from the ground up, and sitting alongside Compliance Officers as they prepared for their first goAML filings — surfaced the same gap again and again: firms needed rigorous, audit-ready compliance support, but most were too small to justify a full in-house function and too exposed to go without one."}, {"heading": null, "body": "Our mission is to close that gap by turning individual advisory engagements into a scalable, technology-enabled service — one that keeps the judgment and accountability of a boutique practice while removing the friction that usually comes with growing beyond a single advisor. We are building the systems, templates, and screening workflows now so that as our client base grows, the quality of the advice does not thin out."}, {"heading": "Our people", "body": "Compass & Coin is led by its founder, who has worked directly with DNFBPs on AML registration, policy design, and regulator-facing compliance since the practice's earliest engagements. The founder sets the firm's advisory standards and remains personally involved in client onboarding and higher-risk case review.\n\nDay-to-day compliance operations are overseen by our AML Manager, who holds the DridhOn CAMP (Certified Anti-Money Laundering Professional) certification. The AML Manager is responsible for screening workflows, ongoing monitoring, and ensuring that client files stay audit-ready between regulator engagements. As the practice grows beyond founder-led capacity, this role anchors the consistency of our methodology across a larger client book."}, {"heading": "Where we work", "body": "Compass & Coin Technologies FZE is based in Motor City, Dubai, at 301, Abstract Business Center, Motor City, Dubai, United Arab Emirates. We work primarily with DNFBPs operating in and around Dubai, with engagements conducted on-site and remotely as each client's registration and reporting timeline requires."}, {"heading": "What we stand for", "body": "We describe our positioning as \"boutique, but scalable\" — every engagement gets the direct attention of people who have done this work before, but the underlying process is designed to be repeatable, not reinvented for each client. We build client files to be audit-ready by design: documentation, screening records, and policy artifacts are structured from day one to withstand regulator scrutiny, not assembled retroactively when an inspection is announced. That combination — personal accountability paired with systematic rigor — is what we mean when we say we are precise, regulatory-literate, and reassuring in how we work."}]}
$json$::jsonb, now())
ON CONFLICT (section) DO NOTHING;
