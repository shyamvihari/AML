import { requireAuth } from "./requireAuth";
import type { TokenPayload } from "./auth";

export class ForbiddenError extends Error {}

export function requireClient(request: Request): TokenPayload {
  const payload = requireAuth(request);
  if (payload.role !== "CLIENT") throw new ForbiddenError("Client access required");
  return payload;
}
