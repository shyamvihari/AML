"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken } from "@/lib/session";
import { PortalSidebar } from "../PortalSidebar";

type CustomerSummary = { id: string; status: string };

export default function CustomerOverviewPage() {
  const [customers, setCustomers] = useState<CustomerSummary[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    const token = getClientToken();
    fetch("/api/portal/customers", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => {
        if (!res.ok) {
          setLoadError("Could not load your customers. Please try signing in again.");
          return null;
        }
        return res.json();
      })
      .then((body) => {
        if (body) setCustomers(body.customers ?? []);
      });
  }, []);

  const counts = customers
    ? {
        total: customers.length,
        draft: customers.filter((c) => c.status === "DRAFT").length,
        pendingReview: customers.filter((c) => c.status === "PENDING_REVIEW").length,
        completed: customers.filter((c) => c.status === "COMPLETED").length,
      }
    : null;

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <h1 className="text-2xl font-semibold text-charcoal">Customer summary</h1>
        <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
          A quick look at your customers and where each one stands. To add or screen a customer, use{" "}
          <Link href="/portal/customers" className="text-brand-start hover:underline">
            Screening
          </Link>
          .
        </p>
        {loadError ? (
          <p className="mt-6 text-sm text-red-600 dark:text-red-400">{loadError}</p>
        ) : (
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
              <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Total Customers</p>
              <p className="mt-1 text-2xl font-semibold text-charcoal">{counts ? counts.total : "..."}</p>
            </div>
            <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
              <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Draft</p>
              <p className="mt-1 text-2xl font-semibold text-charcoal">{counts ? counts.draft : "..."}</p>
            </div>
            <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
              <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Pending Review</p>
              <p className="mt-1 text-2xl font-semibold text-charcoal">{counts ? counts.pendingReview : "..."}</p>
            </div>
            <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4">
              <p className="text-xs uppercase text-neutral-500 dark:text-neutral-400">Completed</p>
              <p className="mt-1 text-2xl font-semibold text-charcoal">{counts ? counts.completed : "..."}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
