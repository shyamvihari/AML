import { prisma } from "./prisma";

export function todayUtcMidnight(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

export async function getScreeningsUsedToday(userId: string): Promise<number> {
  return prisma.customerScreeningRecord.count({
    where: { createdByUserId: userId, createdAt: { gte: todayUtcMidnight() } },
  });
}
