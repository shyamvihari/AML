"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { getCurrentUser, logout, type SessionUser } from "@/lib/session";

export function HeaderAuthLinks() {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, [pathname]);

  if (user) {
    return (
      <details className="group relative hidden sm:block">
        <summary className="flex cursor-pointer list-none items-center gap-1 text-sm text-charcoal hover:text-brand-start">
          {user.name.split(" ")[0]}
          <svg
            className="h-3 w-3 transition-transform group-open:rotate-180"
            viewBox="0 0 12 12"
            fill="none"
            aria-hidden="true"
          >
            <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </summary>
        <div className="absolute right-0 top-full z-20 mt-2 flex w-40 flex-col gap-1 rounded-md border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-2 shadow-lg">
          {user.role === "SUPER_ADMIN" ? (
            <>
              <Link href="/admin" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
                Admin Dashboard
              </Link>
              <Link href="/staff/kyc" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
                Review Queue
              </Link>
            </>
          ) : user.role === "STAFF" ? (
            <>
              <Link href="/staff" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
                Dashboard
              </Link>
              <Link href="/staff/kyc" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
                Review Queue
              </Link>
            </>
          ) : (
            <Link href="/portal" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
              Client Portal
            </Link>
          )}
          <Link href="/settings" className="rounded px-3 py-1.5 text-sm text-charcoal hover:bg-offwhite">
            Settings
          </Link>
          <button
            type="button"
            onClick={() => {
              logout();
              router.push("/login");
            }}
            className="rounded px-3 py-1.5 text-left text-sm text-charcoal hover:bg-offwhite"
          >
            Log out
          </button>
        </div>
      </details>
    );
  }

  return (
    <Link href="/login" className="hidden text-sm text-charcoal hover:text-brand-start sm:inline">
      Client Portal
    </Link>
  );
}
