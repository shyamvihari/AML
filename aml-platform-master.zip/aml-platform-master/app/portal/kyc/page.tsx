"use client";

import { SectionHeading } from "../../SectionHeading";
import { KycForm } from "./KycForm";
import { ScreeningSummary } from "./ScreeningSummary";
import { PortalSidebar } from "../PortalSidebar";
import { CustomerKycSection } from "./CustomerKycSection";

export default function PortalKycPage() {
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <SectionHeading eyebrow="Client Portal" title="Corporate KYC" subtitle="Fill in, save, and update your company's KYC profile." />
        <KycForm />
        <ScreeningSummary />
        <CustomerKycSection />
      </div>
    </div>
  );
}
