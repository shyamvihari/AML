import { NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { CUSTOMER_DOCUMENT_TYPES } from "@/lib/customerSchemas";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findFirst({ where: { id, clientUserId: payload.userId } });
  if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  const type = formData?.get("type");
  if (!(file instanceof File) || typeof type !== "string") {
    return NextResponse.json({ error: "A file and document type are required" }, { status: 400 });
  }
  const MAX_FILE_SIZE = 15 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    return NextResponse.json({ error: "File must be 15MB or smaller" }, { status: 400 });
  }
  if (!(CUSTOMER_DOCUMENT_TYPES as readonly string[]).includes(type)) {
    return NextResponse.json({ error: "Invalid document type" }, { status: 400 });
  }

  const blob = await put(`customer/${customer.id}/${Date.now()}-${file.name}`, file, {
    access: "private",
    addRandomSuffix: true,
    token: process.env.BLOB_READ_WRITE_TOKEN,
  });

  const document = await prisma.customerDocument.create({
    data: {
      customerId: customer.id,
      type: type as (typeof CUSTOMER_DOCUMENT_TYPES)[number],
      fileName: file.name,
      fileUrl: blob.url,
    },
  });

  return NextResponse.json({ document }, { status: 201 });
}
