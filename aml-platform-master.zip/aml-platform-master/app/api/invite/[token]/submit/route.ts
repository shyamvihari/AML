import { NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireInvite, InviteInvalidError } from "@/lib/requireInvite";
import { generateInviteToken } from "@/lib/auth";
import { signatureSubmitSchema } from "@/lib/inviteSchemas";
import { individualKycFieldsSchema, corporateKycFieldsSchema } from "@/lib/customerSchemas";

export async function POST(request: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }

  if (invite.purpose === "DATA_ENTRY") {
    if (invite.customer.status === "COMPLETED") {
      return NextResponse.json({ error: "This record has already been completed" }, { status: 400 });
    }

    const c = invite.customer;
    const schema = c.customerType === "CORPORATE" ? corporateKycFieldsSchema : individualKycFieldsSchema;
    const fieldsToValidate = {
      name: c.name ?? undefined,
      dateOfBirth: c.dateOfBirth ? c.dateOfBirth.toISOString() : undefined,
      nationality: c.nationality ?? undefined,
      passportOrEmiratesId: c.passportOrEmiratesId ?? undefined,
      idExpiryDate: c.idExpiryDate ? c.idExpiryDate.toISOString() : undefined,
      residentialAddress: c.residentialAddress ?? undefined,
      occupation: c.occupation ?? undefined,
      companyName: c.companyName ?? undefined,
      tradeLicenseNumber: c.tradeLicenseNumber ?? undefined,
      licenseAuthority: c.licenseAuthority ?? undefined,
      incorporationDate: c.incorporationDate ? c.incorporationDate.toISOString() : undefined,
      registeredAddress: c.registeredAddress ?? undefined,
      businessActivity: c.businessActivity ?? undefined,
      authorizedSignatoryName: c.authorizedSignatoryName ?? undefined,
      phone: c.phone ?? undefined,
      email: c.email,
    };
    const fieldsValid = schema.safeParse(fieldsToValidate);
    if (!fieldsValid.success) {
      return NextResponse.json({ error: "Please complete all required fields before submitting" }, { status: 400 });
    }

    const origin = new URL(request.url).origin;
    const [customer, reviewInvite] = await prisma.$transaction(async (tx) => {
      const updatedCustomer = await tx.customer.update({
        where: { id: invite.customerId },
        data: { status: "PENDING_REVIEW" },
      });
      await tx.customerInvite.update({ where: { id: invite.id }, data: { consumedAt: new Date() } });
      const nextInvite = await tx.customerInvite.create({
        data: {
          customerId: invite.customerId,
          token: generateInviteToken(),
          purpose: "REVIEW_SIGNATURE",
          customerName: invite.customerName,
          customerPhone: invite.customerPhone,
          customerEmail: invite.customerEmail,
          intendedSignerUserId: invite.customer.clientUserId,
        },
      });
      return [updatedCustomer, nextInvite];
    });
    return NextResponse.json({ customer, reviewInviteUrl: `${origin}/invite/${reviewInvite.token}` });
  }

  // REVIEW_SIGNATURE
  if (invite.customer.status === "COMPLETED") {
    return NextResponse.json({ error: "This record has already been completed" }, { status: 400 });
  }

  const body = await request.json().catch(() => null);
  const parsed = signatureSubmitSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const base64 = parsed.data.signatureDataUrl.split(",")[1] ?? "";
  const buffer = Buffer.from(base64, "base64");
  const blob = await put(`customer/${invite.customerId}/signature-${Date.now()}.png`, buffer, {
    access: "private",
    addRandomSuffix: true,
    contentType: "image/png",
    token: process.env.BLOB_READ_WRITE_TOKEN,
  });

  // The signer's identity was recorded at the moment this REVIEW_SIGNATURE
  // invite was created (see app/api/portal/customers/[id]/invite/route.ts
  // and the DATA_ENTRY branch above), so it does not need to be inferred here.
  const signedByUserId = invite.intendedSignerUserId;

  const [customer] = await prisma.$transaction(async (tx) => {
    const updatedCustomer = await tx.customer.update({
      where: { id: invite.customerId },
      data: { status: "COMPLETED", signatureUrl: blob.url, signedByUserId, signedAt: new Date() },
    });
    await tx.customerInvite.update({ where: { id: invite.id }, data: { consumedAt: new Date() } });
    // Invalidate every other outstanding invite for this customer so a stale
    // DATA_ENTRY/REVIEW_SIGNATURE link can never reopen a completed record.
    await tx.customerInvite.updateMany({
      where: { customerId: invite.customerId, consumedAt: null, id: { not: invite.id } },
      data: { consumedAt: new Date() },
    });
    return [updatedCustomer];
  });

  return NextResponse.json({ customer });
}
