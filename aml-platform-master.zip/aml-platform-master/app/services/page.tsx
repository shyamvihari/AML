import { PillarCard } from "../PillarCard";
import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Services | Compass & Coin",
  description:
    "Four AML compliance pillars for UAE DNFBPs — KYC & Onboarding, Policy & Registration, Screening, and Reporting — delivered as advisory services and as a working compliance platform.",
};

const PILLARS = [
  {
    href: "/services/kyc",
    title: "KYC & Onboarding",
    description:
      "Digital KYC intake for individuals, corporates, trusts, and PEP-linked parties, with document collection, UBO/ownership-chain mapping, and risk-based CDD/EDD routing built around real estate transaction structures.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <circle cx="12" cy="8" r="3.25" />
        <path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" />
      </svg>
    ),
  },
  {
    href: "/services/policy-registration",
    title: "Policy & Registration",
    description:
      "AML/CFT policy manual drafting, DNFBP registration scoping under Cabinet Resolution 134 of 2025, MOEC/goAML registration and MLRO appointment support, and annual gap-assessment audits.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <path d="M6 2h9l4 4v16H6z" />
        <path d="M14 2v5h5M9 12h6M9 16h6" />
      </svg>
    ),
  },
  {
    href: "/services/screening",
    title: "Screening",
    description:
      "Sanctions (UN, OFAC, EU, UK OFSI, UAE Local Terrorist List), PEP, and adverse-media screening at onboarding and on a recurring schedule, with perpetual monitoring and a structured match-review workflow.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="M20 20l-4.6-4.6" />
      </svg>
    ),
  },
  {
    href: "/services/reporting",
    title: "Reporting",
    description:
      "Transaction-level red-flag monitoring against FATF/CBUAE real estate typologies, a guided SAR/STR drafting workspace, goAML filing-workflow tracking, and a compliance calendar for renewals and audits.",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <path d="M4 19V5a1 1 0 0 1 1-1h9l6 6v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z" />
        <path d="M14 4v6h6M8 13h8M8 17h5" />
      </svg>
    ),
  },
];

export default function ServicesPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <SectionHeading
          eyebrow="Services"
          title="Four pillars, delivered as advisory and as a working system"
          subtitle="Each pillar below is both a service you can engage on its own and a module of the Compass & Coin platform. Whether you need a one-off registration scoped or a full AML program run end to end, the underlying work is the same discipline: document it, screen it, and be able to show a regulator how the decision was made."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((pillar) => (
            <PillarCard key={pillar.href} {...pillar} />
          ))}
        </div>
      </div>
    </main>
  );
}
