"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken } from "@/lib/session";
import { CUSTOMER_DOCUMENT_TYPE_LABELS, CUSTOMER_SCREENING_RISK_RATING_LABELS } from "@/lib/customerSchemas";

type CustomerDetail = {
  id: string;
  name: string | null;
  companyName: string | null;
  email: string;
  phone: string | null;
  nationality: string | null;
  idType: string | null;
  idNumber: string | null;
  notes: string | null;
  status: string;
  customerNote: string | null;
  documents: { id: string; type: string; fileName: string }[];
};

type ScreeningSummary = {
  id: string;
  subjectName: string;
  riskRating: string;
  alertRaised: boolean;
  scannedAt: string | null;
};

export default function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [customer, setCustomer] = useState<CustomerDetail | null>(null);
  const [screeningRecords, setScreeningRecords] = useState<ScreeningSummary[]>([]);
  const [notFound, setNotFound] = useState(false);
  const [screeningLoadError, setScreeningLoadError] = useState(false);

  useEffect(() => {
    const token = getClientToken();
    fetch(`/api/portal/customers/${id}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => {
        if (!res.ok) {
          setNotFound(true);
          return null;
        }
        return res.json();
      })
      .then((body) => {
        if (body) setCustomer(body.customer);
      });
    fetch(`/api/portal/customers/${id}/screening`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => {
        if (!res.ok) {
          setScreeningLoadError(true);
          return null;
        }
        return res.json();
      })
      .then((body) => {
        if (body) setScreeningRecords(body.records ?? []);
      });
  }, [id]);

  if (notFound) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Customer not found.</div>;

  if (!customer) return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">{customer.name || customer.companyName || "(unnamed)"}</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400">
        {customer.email} — status: <strong className="uppercase">{customer.status}</strong>
      </p>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Details</h2>
        <dl className="grid grid-cols-2 gap-2">
          <div><dt className="text-neutral-500 dark:text-neutral-400">Company</dt><dd>{customer.companyName ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Phone</dt><dd>{customer.phone ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">Nationality</dt><dd>{customer.nationality ?? "—"}</dd></div>
          <div><dt className="text-neutral-500 dark:text-neutral-400">ID</dt><dd>{customer.idType ?? "—"} {customer.idNumber ?? ""}</dd></div>
        </dl>
        {customer.notes && <p className="mt-2 text-neutral-600 dark:text-neutral-300">{customer.notes}</p>}
        {customer.customerNote && (
          <p className="mt-2 text-neutral-600 dark:text-neutral-300">
            <strong>Customer note:</strong> {customer.customerNote}
          </p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Documents</h2>
        {customer.documents.length ? (
          <ul className="flex flex-col gap-1">
            {customer.documents.map((d) => (
              <li key={d.id}>
                <a href={`/api/portal/customers/${id}/documents/${d.id}/download`} className="text-brand-start hover:underline">
                  {d.fileName} ({CUSTOMER_DOCUMENT_TYPE_LABELS[d.type as keyof typeof CUSTOMER_DOCUMENT_TYPE_LABELS] ?? d.type})
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">Nothing uploaded yet.</p>
        )}
      </section>

      <section className="mt-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 text-sm">
        <h2 className="mb-2 font-medium text-charcoal">Screening</h2>
        {screeningLoadError ? (
          <p className="text-red-600 dark:text-red-400">Could not load screening records.</p>
        ) : screeningRecords.length ? (
          <ul className="flex flex-col gap-2">
            {screeningRecords.map((r) => (
              <li key={r.id}>
                <Link href={`/portal/customers/${id}/screening/${r.id}`} className="text-brand-start hover:underline">
                  {r.subjectName}
                </Link>
                {" — "}risk: {CUSTOMER_SCREENING_RISK_RATING_LABELS[r.riskRating as keyof typeof CUSTOMER_SCREENING_RISK_RATING_LABELS] ?? r.riskRating}
                {r.alertRaised ? " — alert raised" : ""}
                {r.scannedAt ? ` — scanned ${new Date(r.scannedAt).toLocaleDateString()}` : ""}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-neutral-500 dark:text-neutral-400">No screening records yet.</p>
        )}
        <Link
          href={`/portal/customers/${id}/screening/new`}
          className="mt-3 inline-block rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite"
        >
          Screen this customer
        </Link>
      </section>
    </div>
  );
}
