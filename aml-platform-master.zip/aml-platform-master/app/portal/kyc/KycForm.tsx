"use client";

import { useEffect, useRef, useState } from "react";
import { getClientToken } from "@/lib/session";
import {
  ENTITY_TYPES,
  ENTITY_TYPE_LABELS,
  RELATED_COMPANY_SCOPES,
  RELATED_COMPANY_SCOPE_LABELS,
  KYC_DOCUMENT_TYPES,
  KYC_DOCUMENT_TYPE_LABELS,
  type KycOwnerInput,
} from "@/lib/kycSchemas";

type KycDocument = { id: string; type: string; fileName: string; uploadedAt: string };

type KycProfile = {
  id: string;
  status: string;
  entityType: string | null;
  entityTypeOther: string | null;
  companyName: string | null;
  coreBusinessActivity: string | null;
  licenseNumber: string | null;
  licenseIssueDate: string | null;
  licenseExpiryDate: string | null;
  countryOfRegistration: string | null;
  licenseIssuingAuthority: string | null;
  dateOfIncorporation: string | null;
  poBox: string | null;
  telephone: string | null;
  emirate: string | null;
  trn: string | null;
  orn: string | null;
  registeredEmail: string | null;
  contactPersonName: string | null;
  contactPersonDesignation: string | null;
  contactPersonMobile: string | null;
  contactPersonEmail: string | null;
  estimatedAnnualTurnover: string | null;
  relatedCompanyScope: string;
  authorizedSignatoryName: string | null;
  declarationDate: string | null;
  sanctionScreeningStatus: string | null;
  mlroApproval: string | null;
  mlroRemarks: string | null;
  owners: KycOwnerInput[];
  documents: KycDocument[];
};

const EMPTY_OWNER: KycOwnerInput = { name: "", designation: "", nationality: "", mobileIdType: "", percentShare: undefined };

function toDateInput(value: string | null) {
  return value ? value.slice(0, 10) : "";
}

export function KycForm() {
  const [profile, setProfile] = useState<KycProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [owners, setOwners] = useState<KycOwnerInput[]>([EMPTY_OWNER]);
  const [consent, setConsent] = useState(false);
  const [uploadType, setUploadType] = useState<(typeof KYC_DOCUMENT_TYPES)[number]>("TRADE_LICENSE");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const formRef = useRef<HTMLFormElement>(null);

  async function load() {
    const token = getClientToken();
    const res = await fetch("/api/kyc", { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    const body = await res.json();
    setProfile(body.profile);
    if (body.profile?.owners?.length) setOwners(body.profile.owners);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  function field(name: keyof KycProfile) {
    return (profile?.[name] as string | null) ?? "";
  }

  function collectFields(): Record<string, unknown> {
    if (!formRef.current) return {};
    const formData = new FormData(formRef.current);
    const fields: Record<string, unknown> = {};
    for (const [key, value] of formData.entries()) fields[key] = value;
    fields.owners = owners.filter((o) => o.name.trim().length > 0);
    return fields;
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setNotice(null);
    const payload = collectFields();

    const token = getClientToken();
    const res = await fetch("/api/kyc", {
      method: "PUT",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      setError("Could not save. Please check the form and try again.");
      setSaving(false);
      return;
    }
    const body = await res.json();
    setProfile(body.profile);
    if (body.profile?.owners?.length) setOwners(body.profile.owners);
    setNotice("Draft saved.");
    setSaving(false);
  }

  async function submit() {
    if (!consent) {
      setError("Please confirm the declaration before submitting.");
      return;
    }
    setSaving(true);
    setError(null);
    setNotice(null);
    const token = getClientToken();

    // Save the current form's live values first — this button lives outside
    // the form's own onSubmit, and the profile state can be stale if the
    // user typed into fields without clicking "Save draft" first.
    const draftPayload = collectFields();
    const draftRes = await fetch("/api/kyc", {
      method: "PUT",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(draftPayload),
    });
    if (!draftRes.ok) {
      setError("Could not save your changes before submitting. Please try again.");
      setSaving(false);
      return;
    }

    const submitPayload = { ...collectFields(), declarationConsent: true };
    const res = await fetch("/api/kyc/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(submitPayload),
    });
    const body = await res.json();
    if (!res.ok) {
      const firstError = body.error?.fieldErrors
        ? Object.values(body.error.fieldErrors as Record<string, string[]>).flat()[0]
        : body.error;
      setError(firstError ?? "Submission failed. Please fill in all required fields.");
      setSaving(false);
      return;
    }
    setProfile(body.profile);
    if (body.profile?.owners?.length) setOwners(body.profile.owners);
    setNotice("Submitted for review.");
    setSaving(false);
  }

  async function uploadDocument() {
    if (!uploadFile) return;
    setSaving(true);
    setError(null);
    const token = getClientToken();
    const formData = new FormData();
    formData.append("file", uploadFile);
    formData.append("type", uploadType);
    const res = await fetch("/api/kyc/documents", {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    if (!res.ok) {
      setError("Document upload failed.");
      setSaving(false);
      return;
    }
    setUploadFile(null);
    await load();
    setSaving(false);
  }

  async function deleteDocument(id: string) {
    const token = getClientToken();
    await fetch(`/api/kyc/documents/${id}`, {
      method: "DELETE",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    await load();
  }

  function updateOwner(index: number, key: keyof KycOwnerInput, value: string) {
    setOwners((prev) =>
      prev.map((o, i) =>
        i === index ? { ...o, [key]: key === "percentShare" ? (value ? Number(value) : undefined) : value } : o,
      ),
    );
  }

  if (loading) return <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>;

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2";
  const labelClass = "flex flex-col gap-1 text-sm";

  return (
    <div className="flex flex-col gap-8">
      <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-4 text-sm text-charcoal">
        Status: <strong className="uppercase">{profile?.status ?? "DRAFT"}</strong>
      </div>

      {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
      {notice && <p className="text-sm text-green-700 dark:text-green-400">{notice}</p>}

      <form ref={formRef} onSubmit={save} className="flex flex-col gap-8">
        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Corporate customer details</h2>
          <label className={labelClass}>
            Type of entity
            <select name="entityType" defaultValue={field("entityType")} className={inputClass}>
              <option value="">Select...</option>
              {ENTITY_TYPES.map((t) => (
                <option key={t} value={t}>{ENTITY_TYPE_LABELS[t]}</option>
              ))}
            </select>
          </label>
          <label className={labelClass}>
            If "Others", please specify
            <input name="entityTypeOther" defaultValue={field("entityTypeOther")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Company name as per trade license
            <input name="companyName" defaultValue={field("companyName")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Core business activity
            <input name="coreBusinessActivity" defaultValue={field("coreBusinessActivity")} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Trade / professional license details</h2>
          <label className={labelClass}>
            License number
            <input name="licenseNumber" defaultValue={field("licenseNumber")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Issue date
            <input type="date" name="licenseIssueDate" defaultValue={toDateInput(profile?.licenseIssueDate ?? null)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Expiry date
            <input type="date" name="licenseExpiryDate" defaultValue={toDateInput(profile?.licenseExpiryDate ?? null)} className={inputClass} />
          </label>
          <label className={labelClass}>
            Country of registration
            <input name="countryOfRegistration" defaultValue={field("countryOfRegistration")} className={inputClass} />
          </label>
          <label className={labelClass}>
            License issuing authority
            <input name="licenseIssuingAuthority" defaultValue={field("licenseIssuingAuthority")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Date of incorporation
            <input type="date" name="dateOfIncorporation" defaultValue={toDateInput(profile?.dateOfIncorporation ?? null)} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Registered address</h2>
          <label className={labelClass}>
            P.O. Box
            <input name="poBox" defaultValue={field("poBox")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Telephone
            <input name="telephone" defaultValue={field("telephone")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Emirate
            <input name="emirate" defaultValue={field("emirate")} className={inputClass} />
          </label>
          <label className={labelClass}>
            TRN
            <input name="trn" defaultValue={field("trn")} className={inputClass} />
          </label>
          <label className={labelClass}>
            ORN
            <input name="orn" defaultValue={field("orn")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Email
            <input type="email" name="registeredEmail" defaultValue={field("registeredEmail")} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Contact person</h2>
          <label className={labelClass}>
            Name
            <input name="contactPersonName" defaultValue={field("contactPersonName")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Designation
            <input name="contactPersonDesignation" defaultValue={field("contactPersonDesignation")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Mobile
            <input name="contactPersonMobile" defaultValue={field("contactPersonMobile")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Email
            <input type="email" name="contactPersonEmail" defaultValue={field("contactPersonEmail")} className={inputClass} />
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Owners / partners / directors / shareholders</h2>
          {owners.map((owner, index) => (
            <div key={index} className="grid grid-cols-2 gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-3">
              <input placeholder="Name" value={owner.name} onChange={(e) => updateOwner(index, "name", e.target.value)} className={inputClass} />
              <input placeholder="Designation" value={owner.designation ?? ""} onChange={(e) => updateOwner(index, "designation", e.target.value)} className={inputClass} />
              <input placeholder="Nationality" value={owner.nationality ?? ""} onChange={(e) => updateOwner(index, "nationality", e.target.value)} className={inputClass} />
              <input placeholder="Mobile / ID type" value={owner.mobileIdType ?? ""} onChange={(e) => updateOwner(index, "mobileIdType", e.target.value)} className={inputClass} />
              <input placeholder="% of share" type="number" min={0} max={100} value={owner.percentShare ?? ""} onChange={(e) => updateOwner(index, "percentShare", e.target.value)} className={inputClass} />
              <button type="button" onClick={() => setOwners((prev) => prev.filter((_, i) => i !== index))} className="text-sm text-red-600 dark:text-red-400">
                Remove
              </button>
            </div>
          ))}
          <button type="button" onClick={() => setOwners((prev) => [...prev, { ...EMPTY_OWNER }])} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite">
            Add owner / director / shareholder
          </button>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Company details</h2>
          <label className={labelClass}>
            Estimated annual turnover
            <input name="estimatedAnnualTurnover" defaultValue={field("estimatedAnnualTurnover")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Sister / parent / subsidiary company
            <select name="relatedCompanyScope" defaultValue={profile?.relatedCompanyScope ?? "NONE"} className={inputClass}>
              {RELATED_COMPANY_SCOPES.map((s) => (
                <option key={s} value={s}>{RELATED_COMPANY_SCOPE_LABELS[s]}</option>
              ))}
            </select>
          </label>
        </section>

        <section className="flex flex-col gap-3">
          <h2 className="text-lg font-medium text-charcoal">Declaration</h2>
          <label className={labelClass}>
            Authorized name (signatory)
            <input name="authorizedSignatoryName" defaultValue={field("authorizedSignatoryName")} className={inputClass} />
          </label>
          <label className={labelClass}>
            Date
            <input type="date" name="declarationDate" defaultValue={toDateInput(profile?.declarationDate ?? null)} className={inputClass} />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            I hereby declare that the above information is correct.
          </label>
        </section>

        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:bg-offwhite disabled:opacity-50">
            {saving ? "Saving..." : "Save draft"}
          </button>
          <button type="button" onClick={submit} disabled={saving} className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50">
            Submit for review
          </button>
        </div>
      </form>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-medium text-charcoal">Supporting documents</h2>
        {profile?.documents.length ? (
          <ul className="flex flex-col gap-2">
            {profile.documents.map((doc) => (
              <li key={doc.id} className="flex items-center justify-between rounded-md border border-neutral-200 dark:border-neutral-700 px-3 py-2 text-sm">
                <a href={`/api/kyc/documents/${doc.id}/download`} className="text-brand-start hover:underline">
                  {doc.fileName} ({KYC_DOCUMENT_TYPE_LABELS[doc.type as keyof typeof KYC_DOCUMENT_TYPE_LABELS] ?? doc.type})
                </a>
                <button type="button" onClick={() => deleteDocument(doc.id)} className="text-red-600 dark:text-red-400">
                  Delete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-neutral-500 dark:text-neutral-400">No documents uploaded yet.</p>
        )}
        <div className="flex flex-wrap items-center gap-2">
          <select value={uploadType} onChange={(e) => setUploadType(e.target.value as (typeof KYC_DOCUMENT_TYPES)[number])} className={inputClass}>
            {KYC_DOCUMENT_TYPES.map((t) => (
              <option key={t} value={t}>{KYC_DOCUMENT_TYPE_LABELS[t]}</option>
            ))}
          </select>
          <input type="file" onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)} className="text-sm" />
          <button type="button" onClick={uploadDocument} disabled={!uploadFile || saving} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite disabled:opacity-50">
            Upload
          </button>
        </div>
      </section>
    </div>
  );
}
