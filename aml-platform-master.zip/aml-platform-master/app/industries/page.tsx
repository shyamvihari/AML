import Link from "next/link";
import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Industries We Serve | Compass & Coin",
  description:
    "AML, KYC, and DNFBP compliance advisory tailored to real estate brokers, developers, property managers, DNFBPs, and financial institution partners in the UAE.",
};

const PERSONAS = [
  {
    id: "brokers",
    name: "Real Estate Brokers & Agencies",
    tagline:
      "RERA-registered brokerages that facilitate sale and purchase transactions between buyers and sellers.",
    needs: [
      "Guidance on DNFBP registration for their specific activity mix",
      "KYC on both buyers and sellers in every transaction",
      "Source-of-funds checks calibrated to deal size and client profile",
      "Support preparing and filing Suspicious Activity Reports (SARs) when red flags arise",
    ],
  },
  {
    id: "developers",
    name: "Property Developers",
    tagline:
      "Off-plan and secondary-market developers selling directly to buyers.",
    needs: [
      "Buyer due diligence that scales across large volumes of transactions",
      "Sanctions screening built into the sales process",
      "AML policy documentation prepared specifically for RERA and DLD audits",
    ],
  },
  {
    id: "property-managers",
    name: "Property Management & Leasing Firms",
    tagline:
      "Firms managing rentals and leasing — a segment outside the mandatory DNFBP scope, where AML obligations are voluntary rather than mandated.",
    needs: [
      "Voluntary CDD/EDD best-practice guidance, applied even though registration isn't required",
      "Scoping advice on when a firm's activities would trigger mandatory DNFBP registration",
    ],
  },
  {
    id: "dnfbps",
    name: "DNFBP Compliance Officers",
    tagline:
      "In-house compliance leads at law firms, accountants, and dealers in precious metals and stones — the professionals who own AML/CFT compliance day to day.",
    needs: [
      "Policy templates suited to how the business actually operates",
      "Ongoing screening across onboarding and periodic re-screening",
      "Training for compliance and frontline staff",
      "Audit-ready reporting packs for supervisory review",
    ],
  },
  {
    id: "financial-institutions",
    name: "Financial Institution Partners",
    tagline:
      "Banks and exchange houses that refer or co-serve real estate clients alongside our DNFBP clients — a partnership relationship, not a direct client engagement.",
    needs: [
      "Confirmation of the AML posture of the real estate counterparties they refer or co-serve",
      "Shared due-diligence evidence to support their own compliance obligations",
    ],
  },
];

export default function IndustriesPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <SectionHeading
          eyebrow="Industries"
          title="Who we work with"
          subtitle="Real estate brokers, developers, property managers, DNFBPs, and financial institution partners each carry a different compliance obligation under UAE AML/CFT law. We tailor the approach to the segment."
        />

        <div className="flex flex-col gap-14 text-neutral-700 dark:text-neutral-300">
          {PERSONAS.map((persona) => (
            <section key={persona.id} id={persona.id} className="border-t border-neutral-200 dark:border-neutral-700 pt-10 first:border-t-0 first:pt-0">
              <h3 className="text-xl font-semibold text-charcoal">{persona.name}</h3>
              <p className="mt-3">{persona.tagline}</p>

              <p className="mt-5 text-sm font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400">
                What you need from us
              </p>
              <ul className="mt-3 flex flex-col gap-2">
                {persona.needs.map((need) => (
                  <li key={need} className="flex items-start gap-2 text-sm">
                    <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-start" />
                    <span>{need}</span>
                  </li>
                ))}
              </ul>

              <Link
                href="/contact"
                className="mt-5 inline-block text-sm font-medium text-brand-start hover:underline"
              >
                Talk to us about {persona.name} →
              </Link>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
