"use client";

import { useState } from "react";
import Link from "next/link";
import { getClientToken } from "@/lib/session";

export default function NewCustomerPage() {
  const [name, setName] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [nationality, setNationality] = useState("");
  const [idType, setIdType] = useState("");
  const [idNumber, setIdNumber] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState<{ email: string } | null>(null);

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch("/api/portal/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({
        name: name || undefined,
        companyName: companyName || undefined,
        email,
        phone: phone || undefined,
        nationality: nationality || undefined,
        idType: idType || undefined,
        idNumber: idNumber || undefined,
        notes: notes || undefined,
      }),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not add this customer. Please check the form and try again.");
      setSaving(false);
      return;
    }
    setCreated({ email });
    setSaving(false);
  }

  if (created) {
    return (
      <div className="mx-auto max-w-lg px-6 py-16">
        <h1 className="text-2xl font-semibold text-charcoal">Customer added</h1>
        <div className="mt-4 flex flex-col gap-2 rounded-md border border-neutral-200 dark:border-neutral-700 bg-offwhite p-4 text-sm text-charcoal">
          <p>
            <strong>{created.email}</strong> has been added.
          </p>
          <p className="text-neutral-600 dark:text-neutral-300">
            To collect their KYC details, go to <Link href="/portal/kyc" className="text-brand-start hover:underline">KYC</Link> —
            you can enter their details yourself or send them a link to fill in.
          </p>
        </div>
        <Link href="/portal/customers" className="mt-6 inline-block text-sm text-brand-start hover:underline">
          Back to customers
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Add a customer</h1>
      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
      <form onSubmit={submit} className="mt-6 flex flex-col gap-3">
        <label className={labelClass}>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Company name (optional)
          <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Phone
          <input value={phone} onChange={(e) => setPhone(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Nationality
          <input value={nationality} onChange={(e) => setNationality(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          ID type
          <input value={idType} onChange={(e) => setIdType(e.target.value)} placeholder="Passport, Emirates ID..." className={inputClass} />
        </label>
        <label className={labelClass}>
          ID number
          <input value={idNumber} onChange={(e) => setIdNumber(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Notes
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className={inputClass} />
        </label>
        <button
          type="submit"
          disabled={saving}
          className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving..." : "Add customer"}
        </button>
      </form>
    </div>
  );
}
