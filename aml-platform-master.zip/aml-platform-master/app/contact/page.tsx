import { SectionHeading } from "../SectionHeading";
import { LeadForm } from "../LeadForm";
import { WHATSAPP_NUMBER } from "@/lib/constants";

export const metadata = {
  title: "Contact | Compass & Coin",
  description:
    "Get in touch with Compass & Coin's AML advisory team in Motor City, Dubai — book a scoping call, reach us on WhatsApp, or find our office on the map.",
};

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<{ intent?: string }>;
}) {
  const { intent } = await searchParams;
  const isScopingCall = intent === "scoping-call";

  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <SectionHeading
          eyebrow="Contact"
          title={
            isScopingCall
              ? "Let's schedule your free AML scoping call"
              : "Get in touch"
          }
          subtitle={
            isScopingCall
              ? "Tell us about your business below and a member of our AML team will follow up to schedule your free scoping call — no calendar booking account needed yet, we'll coordinate a time by email or WhatsApp."
              : "Reach our AML advisory team by form, WhatsApp, or in person at our Motor City office."
          }
        />

        <div className="grid gap-12 md:grid-cols-2">
          <div>
            <LeadForm
              source="CONTACT_FORM"
              submitLabel={isScopingCall ? "Book my scoping call" : "Send message"}
            />
          </div>

          <div className="flex flex-col gap-8">
            <div>
              <h3 className="text-lg font-semibold text-charcoal">Office</h3>
              <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
                Compass & Coin Technologies FZE
                <br />
                301, Abstract Business Center
                <br />
                Motor City, Dubai, United Arab Emirates
              </p>
              <div className="mt-4 overflow-hidden rounded-lg border border-neutral-200 dark:border-neutral-700">
                <iframe
                  title="Compass & Coin office location — Motor City, Dubai"
                  src="https://www.google.com/maps?q=CONTROL+TOWER+Office+Building+Al+Hebiah+First+Dubai+Motor+City+Dubai&output=embed"
                  width="100%"
                  height="280"
                  style={{ border: 0 }}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-charcoal">WhatsApp</h3>
              <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
                Prefer a quicker channel? Message us directly on WhatsApp Business.
              </p>
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-block text-sm font-medium text-brand-start hover:underline"
              >
                Chat with us on WhatsApp →
              </a>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
