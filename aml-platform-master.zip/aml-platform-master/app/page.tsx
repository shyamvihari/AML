import Link from "next/link";
import { PillarCard } from "./PillarCard";
import { SectionHeading } from "./SectionHeading";
import { LeadForm } from "./LeadForm";
import { prisma } from "@/lib/prisma";
import { SITE_CONTENT_SECTIONS, type HeroData, type PillarData } from "@/lib/contentSchemas";

export const dynamic = "force-dynamic";

// Fallback copy matching the exact seeded rows in
// prisma/migrations/00000000000007_super_admin_site_content/migration.sql.
// Used only if a SiteContent row is ever missing, so the public homepage
// degrades gracefully instead of crashing.
const FALLBACK_HERO: HeroData = {
  titleStart: "AML and KYC compliance built for",
  titleHighlight: "UAE real estate DNFBPs",
  subtitle:
    "Compass & Coin is a Dubai-based advisory practice focused exclusively on anti-money-laundering compliance for real estate brokers, developers, property managers, and other designated non-financial businesses and professions. We help you register, screen, document, and report to the standard UAE regulators expect — and keep you audit-ready as those obligations evolve.",
};
const FALLBACK_PILLARS: Record<string, PillarData> = {
  pillar_kyc: {
    title: "KYC & Onboarding",
    description:
      "Risk-based customer due diligence, UBO and beneficial-ownership record-keeping, and EDD routing for higher-risk clients.",
  },
  pillar_policy: {
    title: "Policy & Registration",
    description:
      "DNFBP registration guidance under Cabinet Resolution 134 of 2025, MOEC/goAML registration, and drafting the AML policies your designated Compliance Officer needs on file.",
  },
  pillar_screening: {
    title: "Screening",
    description:
      "Sanctions, PEP, and adverse-media screening at onboarding, with ongoing re-screening so existing client relationships stay current as watchlists change.",
  },
  pillar_reporting: {
    title: "Reporting",
    description:
      "SAR/STR drafting and filing support, goAML submission tracking, and a compliance calendar that keeps policy renewals, training, and audits on schedule.",
  },
};

const TRUST_MARKERS = [
  "DridhOn CAMP-certified AML Manager",
  "Based in Motor City, Dubai",
  "Cabinet Resolution 134 of 2025 expertise",
];

const PILLAR_META = [
  {
    href: "/services/kyc",
    section: "pillar_kyc" as const,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <circle cx="12" cy="8" r="3.25" />
        <path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" />
      </svg>
    ),
  },
  {
    href: "/services/policy-registration",
    section: "pillar_policy" as const,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <path d="M6 2h9l4 4v16H6z" />
        <path d="M14 2v5h5M9 12h6M9 16h6" />
      </svg>
    ),
  },
  {
    href: "/services/screening",
    section: "pillar_screening" as const,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="M20 20l-4.6-4.6" />
      </svg>
    ),
  },
  {
    href: "/services/reporting",
    section: "pillar_reporting" as const,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} className="h-8 w-8">
        <path d="M4 19V5a1 1 0 0 1 1-1h9l6 6v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z" />
        <path d="M14 4v6h6M8 13h8M8 17h5" />
      </svg>
    ),
  },
];

export default async function HomePage() {
  const rows = await prisma.siteContent.findMany({
    where: { section: { in: SITE_CONTENT_SECTIONS.filter((s) => s !== "about_us") } },
  });
  const bySection = new Map(rows.map((row) => [row.section, row.data]));
  const hero = (bySection.get("home_hero") as HeroData | undefined) ?? FALLBACK_HERO;
  const pillars = PILLAR_META.map((meta) => {
    const pillarData = (bySection.get(meta.section) as PillarData | undefined) ?? FALLBACK_PILLARS[meta.section];
    return { href: meta.href, icon: meta.icon, title: pillarData.title, description: pillarData.description };
  });

  return (
    <>
      <section className="bg-white dark:bg-neutral-900">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-6 py-20">
          <h1 className="max-w-3xl text-4xl font-bold leading-tight text-charcoal sm:text-5xl">
            {hero.titleStart}{" "}
            <span className="text-brand-gradient">{hero.titleHighlight}</span>
          </h1>
          <p className="max-w-2xl text-lg text-neutral-600 dark:text-neutral-300">{hero.subtitle}</p>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/contact?intent=scoping-call"
              className="rounded-md bg-brand-gradient px-5 py-3 text-sm font-medium text-white hover:opacity-90"
            >
              Book a Free AML Scoping Call
            </Link>
            <Link
              href="/tools/dnfbp-scoping"
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-5 py-3 text-sm font-medium text-charcoal hover:border-brand-start hover:text-brand-start"
            >
              Check if DNFBP registration applies to you
            </Link>
            <Link
              href="/tools/health-check"
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-5 py-3 text-sm font-medium text-charcoal hover:border-brand-start hover:text-brand-start"
            >
              Benchmark your AML maturity
            </Link>
          </div>
        </div>
      </section>

      <section className="border-y border-neutral-200 dark:border-neutral-700 bg-offwhite">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-8 sm:flex-row sm:items-center sm:justify-between">
          {TRUST_MARKERS.map((marker) => (
            <p key={marker} className="text-sm font-medium text-charcoal">
              {marker}
            </p>
          ))}
        </div>
      </section>

      <section className="bg-white dark:bg-neutral-900">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <SectionHeading
            eyebrow="What we cover"
            title="Four pillars, one compliance program"
            subtitle="Each pillar is a distinct regulatory obligation and a distinct service — engage us for one, or run your full AML program through all four."
          />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {pillars.map((pillar) => (
              <PillarCard key={pillar.href} {...pillar} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-offwhite">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="max-w-3xl">
            <p className="text-sm font-medium uppercase tracking-wide text-brand-start">
              Why Compass & Coin
            </p>
            <h2 className="mt-2 text-3xl font-bold text-charcoal">
              One platform, full lifecycle
            </h2>
            <p className="mt-4 text-neutral-600 dark:text-neutral-300">
              Most firms piece together AML compliance from a policy template here, a
              screening subscription there, and a spreadsheet for filing deadlines.
              We run registration, onboarding, screening, and reporting as one
              connected program, so nothing falls between the cracks of separate
              vendors — and so what your Compliance Officer produces holds up under
              regulatory review.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-white dark:bg-neutral-900">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="mx-auto max-w-xl">
            <SectionHeading
              eyebrow="Get started"
              title="Talk to our AML team"
              subtitle="Tell us about your business and one of our team will follow up to scope your obligations under Cabinet Resolution 134 of 2025."
            />
            <LeadForm source="CONTACT_FORM" submitLabel="Talk to our AML team" />
          </div>
        </div>
      </section>
    </>
  );
}
