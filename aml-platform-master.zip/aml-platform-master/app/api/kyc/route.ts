import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";
import { kycProfileDraftSchema } from "@/lib/kycSchemas";

function loadProfile(userId: string) {
  return prisma.kycProfile.findUnique({
    where: { userId },
    include: { owners: { orderBy: { sortOrder: "asc" } }, documents: { orderBy: { uploadedAt: "asc" } } },
  });
}

export async function GET(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const profile = await loadProfile(payload.userId);
  return NextResponse.json({ profile });
}

const DATE_FIELDS = new Set([
  "licenseIssueDate",
  "licenseExpiryDate",
  "dateOfIncorporation",
  "declarationDate",
]);

function emptyStringsToNull(obj: Record<string, unknown>) {
  const result: Record<string, unknown> = { ...obj };
  for (const key of Object.keys(result)) {
    if (result[key] === "") result[key] = null;
    // HTML <input type="date"> submits date-only strings ("YYYY-MM-DD"),
    // which Prisma's DateTime columns reject as invalid ISO-8601. Convert
    // known date fields to Date objects before they reach Prisma.
    else if (DATE_FIELDS.has(key) && typeof result[key] === "string") {
      const parsed = new Date(result[key] as string);
      if (!Number.isNaN(parsed.getTime())) result[key] = parsed;
    }
  }
  return result;
}

export async function PUT(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = kycProfileDraftSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { owners, ...fields } = parsed.data;
  const data = emptyStringsToNull(fields) as Prisma.KycProfileUncheckedUpdateInput &
    Prisma.KycProfileUncheckedCreateInput;

  const existing = await prisma.kycProfile.findUnique({ where: { userId: payload.userId } });
  const resetAfterDecision =
    !!existing && existing.status !== "DRAFT" && existing.status !== "NEEDS_UPDATE";

  const profile = await prisma.$transaction(async (tx) => {
    const profile = await tx.kycProfile.upsert({
      where: { userId: payload.userId },
      create: { ...data, userId: payload.userId },
      update: {
        ...data,
        ...(resetAfterDecision
          ? {
              status: "DRAFT" as const,
              sanctionScreeningStatus: null,
              mlroApproval: null,
              mlroRemarks: null,
              reviewedByUserId: null,
              reviewedAt: null,
            }
          : {}),
      },
    });

    if (owners) {
      await tx.kycOwner.deleteMany({ where: { kycProfileId: profile.id } });
      if (owners.length > 0) {
        await tx.kycOwner.createMany({
          data: owners.map((owner, index) => ({ ...owner, kycProfileId: profile.id, sortOrder: index })),
        });
      }
    }

    return profile;
  });

  const full = await loadProfile(payload.userId);
  return NextResponse.json({ profile: full });
}
