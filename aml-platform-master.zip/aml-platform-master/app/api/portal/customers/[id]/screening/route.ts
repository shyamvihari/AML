import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { customerScreeningRecordInputSchema } from "@/lib/customerSchemas";
import { PLAN_LIMITS, PLAN_LABELS, NEXT_PLAN } from "@/lib/planSchemas";
import { getScreeningsUsedToday } from "@/lib/planUsage";

function toDateOrNull(value: string | undefined | null): Date | null {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findUnique({ where: { id } });
  if (!customer || customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const records = await prisma.customerScreeningRecord.findMany({
    where: { customerId: id },
    orderBy: { createdAt: "desc" },
    select: { id: true, subjectName: true, riskRating: true, alertRaised: true, scannedAt: true },
  });
  return NextResponse.json({ records });
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findUnique({ where: { id } });
  if (!customer || customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const client = await prisma.user.findUniqueOrThrow({ where: { id: payload.userId }, select: { plan: true } });
  const limit = PLAN_LIMITS[client.plan];
  if (limit !== null) {
    const usedToday = await getScreeningsUsedToday(payload.userId);
    if (usedToday >= limit) {
      const next = NEXT_PLAN[client.plan];
      const message = next
        ? `Daily limit reached for your ${PLAN_LABELS[client.plan]} plan (${limit}/day). Upgrade to ${PLAN_LABELS[next]} for ${PLAN_LIMITS[next] === null ? "unlimited" : `up to ${PLAN_LIMITS[next]}/day`}.`
        : `Daily limit reached for your ${PLAN_LABELS[client.plan]} plan (${limit}/day).`;
      return NextResponse.json({ error: message }, { status: 429 });
    }
  }

  const body = await request.json().catch(() => null);
  const parsed = customerScreeningRecordInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { identifications, matches, scannedAt, ...fields } = parsed.data;

  const created = await prisma.$transaction(async (tx) => {
    const record = await tx.customerScreeningRecord.create({
      data: {
        customerId: id,
        createdByUserId: payload.userId,
        ...fields,
        scannedAt: toDateOrNull(scannedAt),
      },
    });
    if (identifications?.length) {
      await tx.customerScreeningIdentification.createMany({
        data: identifications.map((ident, index) => ({
          identityType: ident.identityType,
          identificationNumber: ident.identificationNumber,
          screeningRecordId: record.id,
          sortOrder: index,
        })),
      });
    }
    if (matches?.length) {
      await tx.customerScreeningMatch.createMany({
        data: matches.map((m, index) => ({
          source: m.source,
          matchName: m.matchName,
          matchScore: m.matchScore,
          sourceEntityId: m.sourceEntityId,
          screeningRecordId: record.id,
          sortOrder: index,
        })),
      });
    }
    return record;
  });

  const full = await prisma.customerScreeningRecord.findUnique({
    where: { id: created.id },
    include: { identifications: { orderBy: { sortOrder: "asc" } }, matches: { orderBy: { sortOrder: "asc" } } },
  });
  return NextResponse.json({ record: full }, { status: 201 });
}
