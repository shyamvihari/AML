const TWILIO_API_BASE = "https://api.twilio.com/2010-04-01";

export async function sendWhatsAppInviteLink(
  toPhone: string,
  url: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_WHATSAPP_FROM;
  if (!accountSid || !authToken || !from) {
    return { ok: false, error: "WhatsApp sending is not configured" };
  }

  const digits = toPhone.replace(/[^\d+]/g, "");
  const normalized = digits.startsWith("+") ? digits : `+${digits}`;
  if (normalized.length < 8) {
    return { ok: false, error: "Invalid phone number" };
  }
  const to = `whatsapp:${normalized}`;

  const body = new URLSearchParams({
    From: from,
    To: to,
    Body: `You've been sent a link to complete your KYC details for Compass & Coin. Open it here: ${url}`,
  });

  const res = await fetch(`${TWILIO_API_BASE}/Accounts/${accountSid}/Messages.json`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => null);
    const message =
      errorBody && typeof errorBody.message === "string" ? errorBody.message : `Twilio error (${res.status})`;
    return { ok: false, error: message };
  }

  return { ok: true };
}
