"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ACTIVITY_LABELS,
  computeScopingResult,
  SCOPING_DISCLAIMER,
  type ActivityType,
  type ScopingResult,
} from "@/lib/scopingLogic";
import { PERSONAS, PERSONA_LABELS } from "@/lib/schemas";

const ACTIVITY_ORDER: ActivityType[] = [
  "SALE_PURCHASE_FACILITATION",
  "VALUATION",
  "MARKETING_ONLY",
  "LEASING",
  "PROPERTY_MANAGEMENT",
];

export function ScopingTool() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [activityType, setActivityType] = useState<ActivityType | null>(null);
  const [facilitatesConclusion, setFacilitatesConclusion] = useState<boolean | null>(null);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [persona, setPersona] = useState<(typeof PERSONAS)[number]>("OTHER");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScopingResult | null>(null);

  function chooseActivity(a: ActivityType) {
    setActivityType(a);
    if (a === "SALE_PURCHASE_FACILITATION") {
      setStep(2);
    } else {
      setFacilitatesConclusion(false);
      setStep(3);
    }
  }

  function chooseFacilitates(v: boolean) {
    setFacilitatesConclusion(v);
    setStep(3);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!activityType || facilitatesConclusion === null) return;
    setError(null);
    setBusy(true);

    const computed = computeScopingResult({ activityType, facilitatesConclusion });
    setResult(computed);

    try {
      const res = await fetch("/api/tools/scoping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activityType,
          facilitatesConclusion,
          lead: { name, email, phone, company, persona },
        }),
      });
      if (!res.ok) throw new Error("Submission failed");
    } catch {
      setError("Your result is shown below, but we couldn't save your details. Please email admin@compassandcoin.com to follow up.");
    } finally {
      setBusy(false);
    }
  }

  if (result) {
    return (
      <div className="flex flex-col gap-4 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
        <h3 className="text-xl font-bold text-charcoal">{result.headline}</h3>
        <p className="text-neutral-700 dark:text-neutral-300">{result.reasoning}</p>
        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        <p className="text-xs text-neutral-500 dark:text-neutral-400">{SCOPING_DISCLAIMER}</p>
        <Link
          href="/contact?intent=scoping-call"
          className="inline-block w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
        >
          Book a confirmation consultation
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
      <p className="text-sm text-neutral-500 dark:text-neutral-400">Step {step} of 3</p>

      {step === 1 && (
        <div className="flex flex-col gap-3">
          <p className="font-medium text-charcoal">Which best describes your firm&apos;s primary real estate activity?</p>
          <div className="flex flex-col gap-2">
            {ACTIVITY_ORDER.map((a) => (
              <button
                key={a}
                type="button"
                onClick={() => chooseActivity(a)}
                className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-3 text-left text-sm hover:border-brand-start hover:bg-offwhite"
              >
                {ACTIVITY_LABELS[a]}
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="flex flex-col gap-3">
          <p className="font-medium text-charcoal">
            Does your firm facilitate the conclusion (closing) of sale/purchase transactions?
          </p>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => chooseFacilitates(true)}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:border-brand-start hover:bg-offwhite"
            >
              Yes
            </button>
            <button
              type="button"
              onClick={() => chooseFacilitates(false)}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm hover:border-brand-start hover:bg-offwhite"
            >
              No
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <form onSubmit={submit} className="flex flex-col gap-3">
          <p className="font-medium text-charcoal">Almost done — where should we send your result?</p>
          <label className="flex flex-col gap-1 text-sm">
            Name
            <input required value={name} onChange={(e) => setName(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            Email
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            Phone (optional)
            <input value={phone} onChange={(e) => setPhone(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            Company (optional)
            <input value={company} onChange={(e) => setCompany(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            I am a...
            <select value={persona} onChange={(e) => setPersona(e.target.value as typeof persona)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2">
              {PERSONAS.map((p) => (
                <option key={p} value={p}>{PERSONA_LABELS[p]}</option>
              ))}
            </select>
          </label>
          <button type="submit" disabled={busy} className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50">
            {busy ? "Calculating..." : "See my result"}
          </button>
        </form>
      )}
    </div>
  );
}
