"use client";

import type { CorporateKycFieldsInput } from "@/lib/customerSchemas";

type Value = Partial<CorporateKycFieldsInput>;

export function CorporateKycFields({
  value,
  onChange,
  disabled,
}: {
  value: Value;
  onChange: (next: Value) => void;
  disabled?: boolean;
}) {
  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  function set<K extends keyof Value>(key: K, v: Value[K]) {
    onChange({ ...value, [key]: v });
  }

  return (
    <div className="flex flex-col gap-3">
      <label className={labelClass}>
        Company name
        <input disabled={disabled} value={value.companyName ?? ""} onChange={(e) => set("companyName", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Trade license number
        <input disabled={disabled} value={value.tradeLicenseNumber ?? ""} onChange={(e) => set("tradeLicenseNumber", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        License issuing authority
        <input disabled={disabled} value={value.licenseAuthority ?? ""} onChange={(e) => set("licenseAuthority", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Incorporation date
        <input type="date" disabled={disabled} value={value.incorporationDate ?? ""} onChange={(e) => set("incorporationDate", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Registered address
        <input disabled={disabled} value={value.registeredAddress ?? ""} onChange={(e) => set("registeredAddress", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Business activity
        <input disabled={disabled} value={value.businessActivity ?? ""} onChange={(e) => set("businessActivity", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Authorized signatory name
        <input disabled={disabled} value={value.authorizedSignatoryName ?? ""} onChange={(e) => set("authorizedSignatoryName", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Phone
        <input disabled={disabled} value={value.phone ?? ""} onChange={(e) => set("phone", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Email
        <input type="email" disabled={disabled} value={value.email ?? ""} onChange={(e) => set("email", e.target.value)} className={inputClass} />
      </label>
    </div>
  );
}
