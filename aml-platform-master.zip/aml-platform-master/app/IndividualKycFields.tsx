"use client";

import type { IndividualKycFieldsInput } from "@/lib/customerSchemas";

type Value = Partial<IndividualKycFieldsInput>;

export function IndividualKycFields({
  value,
  onChange,
  disabled,
}: {
  value: Value;
  onChange: (next: Value) => void;
  disabled?: boolean;
}) {
  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  function set<K extends keyof Value>(key: K, v: Value[K]) {
    onChange({ ...value, [key]: v });
  }

  return (
    <div className="flex flex-col gap-3">
      <label className={labelClass}>
        Full name
        <input disabled={disabled} value={value.name ?? ""} onChange={(e) => set("name", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Date of birth
        <input type="date" disabled={disabled} value={value.dateOfBirth ?? ""} onChange={(e) => set("dateOfBirth", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Nationality
        <input disabled={disabled} value={value.nationality ?? ""} onChange={(e) => set("nationality", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Passport or Emirates ID number
        <input disabled={disabled} value={value.passportOrEmiratesId ?? ""} onChange={(e) => set("passportOrEmiratesId", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        ID expiry date
        <input type="date" disabled={disabled} value={value.idExpiryDate ?? ""} onChange={(e) => set("idExpiryDate", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Residential address
        <input disabled={disabled} value={value.residentialAddress ?? ""} onChange={(e) => set("residentialAddress", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Occupation
        <input disabled={disabled} value={value.occupation ?? ""} onChange={(e) => set("occupation", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Phone
        <input disabled={disabled} value={value.phone ?? ""} onChange={(e) => set("phone", e.target.value)} className={inputClass} />
      </label>
      <label className={labelClass}>
        Email
        <input type="email" disabled={disabled} value={value.email ?? ""} onChange={(e) => set("email", e.target.value)} className={inputClass} />
      </label>
    </div>
  );
}
