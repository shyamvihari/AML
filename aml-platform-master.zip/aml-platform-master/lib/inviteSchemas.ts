import { z } from "zod";

export const INVITE_PURPOSES = ["DATA_ENTRY", "REVIEW_SIGNATURE"] as const;

export const createInviteInputSchema = z.object({
  purpose: z.enum(INVITE_PURPOSES),
  customerName: z.string().min(1, "Customer name is required"),
  customerPhone: z.string().optional(),
  customerEmail: z.string().email("Valid email is required"),
});
export type CreateInviteInput = z.infer<typeof createInviteInputSchema>;

export const signatureSubmitSchema = z.object({
  signatureDataUrl: z.string().startsWith("data:image/png;base64,", "Signature must be a PNG image"),
});
export type SignatureSubmitInput = z.infer<typeof signatureSubmitSchema>;
