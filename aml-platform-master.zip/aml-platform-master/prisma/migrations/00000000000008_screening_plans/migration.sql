-- CreateEnum
CREATE TYPE "ScreeningPlan" AS ENUM ('REGULAR', 'PRO', 'MAX');

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "plan" "ScreeningPlan" NOT NULL DEFAULT 'REGULAR';

