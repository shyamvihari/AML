-- CreateEnum
CREATE TYPE "ScreeningRiskRating" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'UNRATED');

-- CreateEnum
CREATE TYPE "ScreeningAlertStatus" AS ENUM ('OPEN', 'CLOSED', 'FALSE_POSITIVE');

-- CreateTable
CREATE TABLE "ScreeningRecord" (
    "id" TEXT NOT NULL,
    "kycProfileId" TEXT NOT NULL,
    "subjectName" TEXT NOT NULL,
    "customerType" TEXT,
    "gender" TEXT,
    "dateOfBirth" TIMESTAMP(3),
    "riskRating" "ScreeningRiskRating" NOT NULL DEFAULT 'UNRATED',
    "scannedAt" TIMESTAMP(3),
    "screenedBy" TEXT,
    "sourcesCheckedCount" INTEGER,
    "sourcesNote" TEXT,
    "alertRaised" BOOLEAN NOT NULL DEFAULT false,
    "alertId" TEXT,
    "alertStatus" "ScreeningAlertStatus",
    "sanctionMatchCount" INTEGER NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdByUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ScreeningRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ScreeningIdentification" (
    "id" TEXT NOT NULL,
    "screeningRecordId" TEXT NOT NULL,
    "identityType" TEXT NOT NULL,
    "identificationNumber" TEXT NOT NULL,
    "issuingCountry" TEXT,
    "placeOfIssue" TEXT,
    "dateOfIssuance" TIMESTAMP(3),
    "dateOfExpiry" TIMESTAMP(3),
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ScreeningIdentification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ScreeningMatch" (
    "id" TEXT NOT NULL,
    "screeningRecordId" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "matchName" TEXT NOT NULL,
    "matchType" TEXT,
    "nationality" TEXT,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ScreeningMatch_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "ScreeningRecord" ADD CONSTRAINT "ScreeningRecord_kycProfileId_fkey" FOREIGN KEY ("kycProfileId") REFERENCES "KycProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScreeningIdentification" ADD CONSTRAINT "ScreeningIdentification_screeningRecordId_fkey" FOREIGN KEY ("screeningRecordId") REFERENCES "ScreeningRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScreeningMatch" ADD CONSTRAINT "ScreeningMatch_screeningRecordId_fkey" FOREIGN KEY ("screeningRecordId") REFERENCES "ScreeningRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

