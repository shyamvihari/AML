export function SectionHeading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <div className="mb-8 flex flex-col gap-2">
      {eyebrow && <p className="text-sm font-medium uppercase tracking-wide text-brand-start">{eyebrow}</p>}
      <h2 className="text-3xl font-bold text-charcoal">{title}</h2>
      {subtitle && <p className="max-w-2xl text-neutral-600 dark:text-neutral-300">{subtitle}</p>}
    </div>
  );
}
