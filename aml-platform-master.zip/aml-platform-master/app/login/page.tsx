"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { setSession, type SessionUser } from "@/lib/session";
import { isSafeNextPath } from "@/lib/authGate";

export default function LoginPage() {
  const [role, setRole] = useState<"CLIENT" | "STAFF" | "SUPER_ADMIN">("CLIENT");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [signupHref, setSignupHref] = useState("/signup");

  useEffect(() => {
    const qs = window.location.search;
    setSignupHref(qs ? `/signup${qs}` : "/signup");
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role }),
      });
      if (!res.ok) throw new Error("Invalid credentials");
      const data = (await res.json()) as { token: string; user: SessionUser };
      setSession(data.token, data.user);
      const next = new URLSearchParams(window.location.search).get("next");
      const fallback = role === "STAFF" ? "/staff" : role === "SUPER_ADMIN" ? "/admin" : "/portal";
      window.location.href = isSafeNextPath(next) ? next : fallback;
    } catch {
      setError("Invalid email, password, or account type.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-sm flex-col gap-6 px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Log in</h1>

      <div className="flex rounded-md border border-neutral-300 dark:border-neutral-600 p-1 text-sm">
        <button
          type="button"
          onClick={() => setRole("CLIENT")}
          className={`flex-1 rounded px-3 py-1.5 ${role === "CLIENT" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
        >
          Client
        </button>
        <button
          type="button"
          onClick={() => setRole("STAFF")}
          className={`flex-1 rounded px-3 py-1.5 ${role === "STAFF" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
        >
          Staff
        </button>
        <button
          type="button"
          onClick={() => setRole("SUPER_ADMIN")}
          className={`flex-1 rounded px-3 py-1.5 ${role === "SUPER_ADMIN" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
        >
          Super Admin
        </button>
      </div>

      <form onSubmit={submit} className="flex flex-col gap-3">
        <label className="flex flex-col gap-1 text-sm">
          Email
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2"
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Password
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2"
          />
        </label>
        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          Log in
        </button>
      </form>

      {role === "CLIENT" && (
        <p className="text-center text-sm text-neutral-600 dark:text-neutral-300">
          No account? <Link href={signupHref} className="text-brand-start hover:underline">Sign up</Link>
        </p>
      )}
    </div>
  );
}
