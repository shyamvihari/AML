import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Careers | Compass & Coin",
  description:
    "Compass & Coin is growing beyond founder-led capacity. Send a speculative application to admin@compassandcoin.com.",
};

export default function CareersPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <SectionHeading
        eyebrow="Careers"
        title="We're growing"
        subtitle="Open roles as the team scales beyond the AML Manager."
      />

      <div className="flex flex-col gap-6 text-neutral-700 dark:text-neutral-300">
        <p>
          Compass & Coin is currently a small, founder-led team: our founder
          and a DridhOn CAMP-certified AML Manager cover advisory, screening,
          and client delivery directly. As our client base grows, so does the
          volume of onboarding, screening, and reporting work that a
          founder-led practice alone cannot sustainably carry — and that means
          we expect to bring on additional compliance and operations
          capacity over time.
        </p>
        <p>
          We don't currently have specific open roles to advertise, and we
          would rather not list positions that aren't real. What we can say is
          that as the team grows, we will be looking for people who share the
          same standard we hold ourselves to: precise, regulatory-literate,
          and comfortable with the accountability that comes with AML work in
          a regulated sector.
        </p>
        <p>
          If that sounds like you — whether your background is in AML
          compliance, KYC operations, DNFBP regulatory work, or a related
          discipline — we welcome speculative applications. Send a short
          introduction and your CV to{" "}
          <a
            href="mailto:admin@compassandcoin.com"
            className="font-medium text-brand-start hover:underline"
          >
            admin@compassandcoin.com
          </a>
          . We review applications as they come in and will reach out if a
          fit emerges as our hiring needs take shape.
        </p>
      </div>
    </main>
  );
}
