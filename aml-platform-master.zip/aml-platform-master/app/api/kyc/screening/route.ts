import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";

export async function GET(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const profile = await prisma.kycProfile.findUnique({ where: { userId: payload.userId } });
  if (!profile) return NextResponse.json({ records: [] });

  const records = await prisma.screeningRecord.findMany({
    where: { kycProfileId: profile.id },
    orderBy: { createdAt: "desc" },
    select: { id: true, subjectName: true, riskRating: true, alertStatus: true, scannedAt: true },
  });
  return NextResponse.json({ records });
}
