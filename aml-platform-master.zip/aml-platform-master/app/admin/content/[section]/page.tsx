"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";
import type { HeroData, PillarData, AboutUsData } from "@/lib/contentSchemas";

type ContentData = HeroData | PillarData | AboutUsData;

const inputClass = "w-full rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2";
const labelClass = "flex flex-col gap-1 text-sm";

export default function AdminContentEditPage({ params }: { params: Promise<{ section: string }> }) {
  const { section } = use(params);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [data, setData] = useState<ContentData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || user.role !== "SUPER_ADMIN") return;
    const token = getClientToken();
    fetch(`/api/admin/content/${section}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.json())
      .then((body) => setData(body.data));
  }, [user, section]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!data) return;
    setBusy(true);
    setError(null);
    setSaved(false);
    const token = getClientToken();
    const res = await fetch(`/api/admin/content/${section}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(typeof body.error === "string" ? body.error : "Could not save. Check every field is filled in.");
      setBusy(false);
      return;
    }
    setSaved(true);
    setBusy(false);
  }

  if (user && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Super Admin access required.</div>;
  }
  if (!data) {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;
  }

  const isHero = "titleStart" in data;
  const isPillar = "title" in data && "description" in data;
  const isAboutUs = "blocks" in data;

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <Link href="/admin/content" className="text-sm text-brand-start hover:underline">← Back to Website Content</Link>
      <h1 className="mt-3 text-2xl font-semibold text-charcoal">Edit section</h1>

      <form onSubmit={save} className="mt-6 flex flex-col gap-4">
        {isHero && (
          <>
            <label className={labelClass}>
              Title (before highlight)
              <input required value={(data as HeroData).titleStart} onChange={(e) => setData({ ...(data as HeroData), titleStart: e.target.value })} className={inputClass} />
            </label>
            <label className={labelClass}>
              Title (highlighted phrase)
              <input required value={(data as HeroData).titleHighlight} onChange={(e) => setData({ ...(data as HeroData), titleHighlight: e.target.value })} className={inputClass} />
            </label>
            <label className={labelClass}>
              Subtitle
              <textarea required rows={3} value={(data as HeroData).subtitle} onChange={(e) => setData({ ...(data as HeroData), subtitle: e.target.value })} className={inputClass} />
            </label>
          </>
        )}

        {isPillar && (
          <>
            <label className={labelClass}>
              Title
              <input required value={(data as PillarData).title} onChange={(e) => setData({ ...(data as PillarData), title: e.target.value })} className={inputClass} />
            </label>
            <label className={labelClass}>
              Description
              <textarea required rows={4} value={(data as PillarData).description} onChange={(e) => setData({ ...(data as PillarData), description: e.target.value })} className={inputClass} />
            </label>
          </>
        )}

        {isAboutUs && (
          <>
            <label className={labelClass}>
              Eyebrow
              <input required value={(data as AboutUsData).eyebrow} onChange={(e) => setData({ ...(data as AboutUsData), eyebrow: e.target.value })} className={inputClass} />
            </label>
            <label className={labelClass}>
              Title
              <input required value={(data as AboutUsData).title} onChange={(e) => setData({ ...(data as AboutUsData), title: e.target.value })} className={inputClass} />
            </label>
            <label className={labelClass}>
              Subtitle
              <textarea required rows={2} value={(data as AboutUsData).subtitle} onChange={(e) => setData({ ...(data as AboutUsData), subtitle: e.target.value })} className={inputClass} />
            </label>
            <div className="flex flex-col gap-4">
              {(data as AboutUsData).blocks.map((block, i) => (
                <div key={i} className="flex flex-col gap-2 rounded-lg border border-neutral-200 dark:border-neutral-700 p-4">
                  <label className={labelClass}>
                    Heading (optional)
                    <input
                      value={block.heading ?? ""}
                      onChange={(e) => {
                        const blocks = [...(data as AboutUsData).blocks];
                        blocks[i] = { ...block, heading: e.target.value || null };
                        setData({ ...(data as AboutUsData), blocks });
                      }}
                      className={inputClass}
                    />
                  </label>
                  <label className={labelClass}>
                    Body
                    <textarea
                      required
                      rows={5}
                      value={block.body}
                      onChange={(e) => {
                        const blocks = [...(data as AboutUsData).blocks];
                        blocks[i] = { ...block, body: e.target.value };
                        setData({ ...(data as AboutUsData), blocks });
                      }}
                      className={inputClass}
                    />
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const blocks = (data as AboutUsData).blocks.filter((_, j) => j !== i);
                        setData({ ...(data as AboutUsData), blocks });
                      }}
                      className="w-fit rounded-md border border-red-300 dark:border-red-800 px-3 py-1 text-xs text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950"
                    >
                      Remove block
                    </button>
                    {i > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          const blocks = [...(data as AboutUsData).blocks];
                          [blocks[i - 1], blocks[i]] = [blocks[i], blocks[i - 1]];
                          setData({ ...(data as AboutUsData), blocks });
                        }}
                        className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1 text-xs hover:bg-neutral-100 dark:hover:bg-neutral-800"
                      >
                        Move up
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                const blocks = [...(data as AboutUsData).blocks, { heading: null, body: "" }];
                setData({ ...(data as AboutUsData), blocks });
              }}
              className="w-fit rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              Add block
            </button>
          </>
        )}

        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        {saved && <p className="text-sm text-green-700 dark:text-green-400">Saved.</p>}
        <button
          type="submit"
          disabled={busy}
          className="w-fit rounded-md bg-brand-gradient px-5 py-2.5 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Saving..." : "Save"}
        </button>
      </form>
    </div>
  );
}
