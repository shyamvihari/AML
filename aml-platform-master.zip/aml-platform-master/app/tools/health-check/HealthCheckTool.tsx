"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  HEALTH_CHECK_QUESTIONS,
  computeHealthCheckScore,
  type HealthCheckResult,
} from "@/lib/healthCheckLogic";
import { PERSONAS, PERSONA_LABELS } from "@/lib/schemas";
import { getCurrentUser } from "@/lib/session";
import { saveGatedIntent, loadGatedIntent, clearGatedIntent } from "@/lib/authGate";
import { WHATSAPP_NUMBER } from "@/lib/constants";

const TIER_STYLES: Record<HealthCheckResult["tier"], string> = {
  LOW: "bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800",
  MODERATE: "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800",
  STRONG: "bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800",
};

const TIER_LABELS: Record<HealthCheckResult["tier"], string> = {
  LOW: "Low Maturity",
  MODERATE: "Moderate Maturity",
  STRONG: "Strong Maturity",
};

interface HealthCheckGatedIntent {
  answers: Record<string, boolean>;
  result: HealthCheckResult;
  name: string;
  email: string;
  phone: string;
  company: string;
  persona: (typeof PERSONAS)[number];
  generatedAt: string;
}

export function HealthCheckTool() {
  const [answers, setAnswers] = useState<Record<string, boolean>>({});

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [persona, setPersona] = useState<(typeof PERSONAS)[number]>("OTHER");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<HealthCheckResult | null>(null);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [generatedAt, setGeneratedAt] = useState("");

  useEffect(() => {
    const pending = loadGatedIntent<HealthCheckGatedIntent>("health-check");
    if (!pending || !getCurrentUser()) return;
    setAnswers(pending.answers);
    setResult(pending.result);
    setName(pending.name);
    setEmail(pending.email);
    setPhone(pending.phone);
    setCompany(pending.company);
    setPersona(pending.persona);
    setGeneratedAt(pending.generatedAt);
    clearGatedIntent("health-check");
    setTimeout(() => window.print(), 300);
  }, []);

  const answeredCount = Object.keys(answers).length;
  const allAnswered = answeredCount === HEALTH_CHECK_QUESTIONS.length;

  function setAnswer(id: string, value: boolean) {
    setAnswers((prev) => ({ ...prev, [id]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!allAnswered) return;
    setError(null);
    setBusy(true);

    const computed = computeHealthCheckScore(answers);
    setResult(computed);
    setGeneratedAt(new Date().toLocaleString());

    try {
      const res = await fetch("/api/tools/health-check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          answers,
          lead: { name, email, phone, company, persona },
        }),
      });
      if (!res.ok) throw new Error("Submission failed");
    } catch {
      setError(
        "Your result is shown below, but we couldn't save your details. Please email admin@compassandcoin.com to follow up."
      );
    } finally {
      setBusy(false);
    }
  }

  function handleDownloadClick() {
    if (getCurrentUser()) {
      window.print();
      return;
    }
    if (result) {
      saveGatedIntent<HealthCheckGatedIntent>("health-check", {
        answers,
        result,
        name,
        email,
        phone,
        company,
        persona,
        generatedAt,
      });
    }
    setShowAuthGate(true);
  }

  if (result) {
    return (
      <div id="health-check-result" className="flex flex-col gap-6 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
        <style jsx global>{`
          @media print {
            #site-header,
            #site-footer,
            #whatsapp-button,
            #health-check-print-hide {
              display: none !important;
            }
          }
        `}</style>
        <div className="flex flex-col gap-1 border-b border-neutral-200 dark:border-neutral-700 pb-4">
          <div className="flex items-start justify-between gap-4">
            <Image
              src="/compass-and-coin-logo.png"
              alt="Compass & Coin"
              width={160}
              height={72}
              className="h-10 w-auto"
            />
            <p className="text-right text-xs text-neutral-500 dark:text-neutral-400">Generated {generatedAt}</p>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Compass &amp; Coin Technologies FZE — 301, Abstract Business Center, Motor City, Dubai, United Arab
            Emirates
          </p>
        </div>

        <p className="text-sm text-neutral-700 dark:text-neutral-300">
          Dear {name || "Customer"}, this is your generated report of your AML Health-Check. Please review it, and
          if you have any queries, get in touch with us via email at{" "}
          <a href="mailto:admin@compassandcoin.com" className="text-brand-start hover:underline">
            admin@compassandcoin.com
          </a>{" "}
          or WhatsApp at{" "}
          <a href={`https://wa.me/${WHATSAPP_NUMBER}`} className="text-brand-start hover:underline">
            +971 52 842 6365
          </a>
          .
        </p>

        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium uppercase tracking-wide text-neutral-500 dark:text-neutral-400">Your AML Health-Check Result</p>
          <p className="text-4xl font-bold text-charcoal">
            {result.score} / {result.maxScore}
          </p>
          <span
            className={`inline-block w-fit rounded-full border px-3 py-1 text-sm font-semibold ${TIER_STYLES[result.tier]}`}
          >
            {TIER_LABELS[result.tier]}
          </span>
        </div>
        <p className="text-neutral-700 dark:text-neutral-300">{result.summary}</p>
        <div className="flex flex-col gap-2">
          <h2 className="font-medium text-charcoal">Your answers</h2>
          <dl className="flex flex-col gap-2 text-sm">
            {HEALTH_CHECK_QUESTIONS.map((q, i) => (
              <div
                key={q.id}
                className="flex items-start justify-between gap-4 border-b border-neutral-100 dark:border-neutral-800 pb-2 last:border-b-0"
              >
                <dt className="text-neutral-700 dark:text-neutral-300">
                  {i + 1}. {q.text}
                </dt>
                <dd
                  className={`shrink-0 font-medium ${
                    answers[q.id] ? "text-green-700 dark:text-green-400" : "text-red-600 dark:text-red-400"
                  }`}
                >
                  {answers[q.id] ? "Yes" : "No"}
                </dd>
              </div>
            ))}
          </dl>
        </div>
        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        <p className="text-xs text-neutral-500 dark:text-neutral-400">
          This self-assessment provides a preliminary, non-binding indicator only and does not constitute legal or
          regulatory advice. A full AML gap-assessment against UAE Cabinet Resolution 134 of 2025 should be
          conducted by a qualified advisor.
        </p>
        <div id="health-check-print-hide" className="flex flex-wrap gap-3">
          {showAuthGate ? (
            <div className="flex flex-col gap-2 rounded-md border border-neutral-200 dark:border-neutral-700 bg-offwhite p-4 text-sm text-charcoal">
              <p>Log in or create a free account to download your report — we&apos;ll bring you right back to it.</p>
              <div className="flex gap-3">
                <Link
                  href="/login?next=/tools/health-check"
                  className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm font-medium hover:border-brand-start hover:bg-white dark:hover:bg-neutral-900"
                >
                  Log in
                </Link>
                <Link
                  href="/signup?next=/tools/health-check"
                  className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
                >
                  Sign up
                </Link>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleDownloadClick}
              className="rounded-md border border-neutral-300 dark:border-neutral-600 px-4 py-2 text-sm font-medium text-charcoal hover:border-brand-start hover:bg-offwhite"
            >
              Print / Save as PDF
            </button>
          )}
          <Link
            href="/contact?intent=scoping-call"
            className="inline-block w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Book a scoping call
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-8 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
      <div className="flex flex-col gap-4">
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          {answeredCount} of {HEALTH_CHECK_QUESTIONS.length} answered
        </p>
        {HEALTH_CHECK_QUESTIONS.map((q, i) => (
          <div key={q.id} className="flex flex-col gap-2 border-b border-neutral-100 dark:border-neutral-800 pb-4 last:border-b-0 sm:flex-row sm:items-center sm:justify-between">
            <p className="font-medium text-charcoal">
              {i + 1}. {q.text}
            </p>
            <div className="flex shrink-0 gap-2">
              <button
                type="button"
                onClick={() => setAnswer(q.id, true)}
                aria-pressed={answers[q.id] === true}
                className={`rounded-md border px-4 py-2 text-sm ${
                  answers[q.id] === true
                    ? "border-brand-start bg-brand-gradient text-white"
                    : "border-neutral-300 dark:border-neutral-600 hover:border-brand-start hover:bg-offwhite"
                }`}
              >
                Yes
              </button>
              <button
                type="button"
                onClick={() => setAnswer(q.id, false)}
                aria-pressed={answers[q.id] === false}
                className={`rounded-md border px-4 py-2 text-sm ${
                  answers[q.id] === false
                    ? "border-brand-start bg-brand-gradient text-white"
                    : "border-neutral-300 dark:border-neutral-600 hover:border-brand-start hover:bg-offwhite"
                }`}
              >
                No
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col gap-3 border-t border-neutral-200 dark:border-neutral-700 pt-6">
        <p className="font-medium text-charcoal">Almost done — where should we send your result?</p>
        <label className="flex flex-col gap-1 text-sm">
          Name
          <input required value={name} onChange={(e) => setName(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Phone (optional)
          <input value={phone} onChange={(e) => setPhone(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Company (optional)
          <input value={company} onChange={(e) => setCompany(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          I am a...
          <select value={persona} onChange={(e) => setPersona(e.target.value as typeof persona)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2">
            {PERSONAS.map((p) => (
              <option key={p} value={p}>
                {PERSONA_LABELS[p]}
              </option>
            ))}
          </select>
        </label>
        <button
          type="submit"
          disabled={busy || !allAnswered}
          className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Calculating..." : "See my result"}
        </button>
        {!allAnswered && (
          <p className="text-xs text-neutral-500 dark:text-neutral-400">Please answer all {HEALTH_CHECK_QUESTIONS.length} questions above to see your result.</p>
        )}
      </div>
    </form>
  );
}
