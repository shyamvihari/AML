import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuperAdmin, ForbiddenError } from "@/lib/requireSuperAdmin";
import { UnauthorizedError } from "@/lib/requireAuth";

export async function POST(request: Request) {
  try {
    requireSuperAdmin(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const deleted = await prisma.$transaction(async (tx) => {
    // KycProfile cascades to KycOwner/KycDocument/ScreeningRecord (and its
    // own children) — only CLIENT users ever have one, so deleting all of
    // them is safe.
    const kycProfiles = await tx.kycProfile.deleteMany({});
    // Customer cascades to CustomerDocument/CustomerScreeningRecord/
    // CustomerInvite (and their own children) — only exists for
    // CLIENT-registered customers.
    const customers = await tx.customer.deleteMany({});
    // Now safe to remove the CLIENT/CUSTOMER accounts themselves. STAFF
    // and SUPER_ADMIN accounts are deliberately untouched.
    const users = await tx.user.deleteMany({ where: { role: { in: ["CLIENT", "CUSTOMER"] } } });
    return { kycProfiles: kycProfiles.count, customers: customers.count, users: users.count };
  });

  return NextResponse.json({ deleted });
}
