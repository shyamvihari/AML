"use client";

import { useEffect, useState } from "react";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";
import { SCREENING_PLANS, PLAN_LABELS, PLAN_DESCRIPTIONS, type ScreeningPlanValue } from "@/lib/planSchemas";
import { PortalSidebar } from "../PortalSidebar";

type PlanState = { plan: ScreeningPlanValue; limit: number | null; usedToday: number };

export default function PlanPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [state, setState] = useState<PlanState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || user.role !== "CLIENT") return;
    const token = getClientToken();
    fetch("/api/portal/plan", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => body && setState(body));
  }, [user]);

  async function choose(plan: ScreeningPlanValue) {
    setBusy(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch("/api/portal/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ plan }),
    });
    if (!res.ok) {
      setError("Could not switch plans. Please try again.");
      setBusy(false);
      return;
    }
    setState(await res.json());
    setBusy(false);
  }

  if (user && user.role !== "CLIENT") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Client access required.</div>;
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <h1 className="text-2xl font-semibold text-charcoal">Screening plan</h1>
        {!state ? (
          <p className="mt-4 text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
        ) : (
          <>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
              Today: {state.usedToday} of {state.limit === null ? "unlimited" : state.limit} screenings used.
            </p>
            {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {SCREENING_PLANS.map((plan) => (
                <button
                  key={plan}
                  type="button"
                  disabled={busy}
                  onClick={() => choose(plan)}
                  className={`flex flex-col gap-2 rounded-lg border p-6 text-left disabled:opacity-50 ${
                    state.plan === plan
                      ? "border-brand-start bg-offwhite"
                      : "border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 hover:border-brand-start"
                  }`}
                >
                  <h2 className="text-lg font-semibold text-charcoal">{PLAN_LABELS[plan]}</h2>
                  <p className="text-sm text-neutral-600 dark:text-neutral-300">{PLAN_DESCRIPTIONS[plan]}</p>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400">Contact us for pricing</p>
                  {state.plan === plan && <span className="text-xs font-medium text-brand-start">Current plan</span>}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
