import { z } from "zod";

export const PERSONAS = [
  "BROKER",
  "DEVELOPER",
  "PROPERTY_MANAGER",
  "DNFBP_OFFICER",
  "FINANCIAL_INSTITUTION",
  "OTHER",
] as const;

export const PERSONA_LABELS: Record<(typeof PERSONAS)[number], string> = {
  BROKER: "Real Estate Broker / Agency",
  DEVELOPER: "Property Developer",
  PROPERTY_MANAGER: "Property Management / Leasing Firm",
  DNFBP_OFFICER: "DNFBP Compliance Officer",
  FINANCIAL_INSTITUTION: "Financial Institution Partner",
  OTHER: "Other",
};

export const LEAD_SOURCES = [
  "CONTACT_FORM",
  "CHECKLIST_DOWNLOAD",
  "SCOPING_TOOL",
  "HEALTH_CHECK",
  "BOOKING_REQUEST",
] as const;

export const leadInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().optional(),
  company: z.string().optional(),
  persona: z.enum(PERSONAS).default("OTHER"),
  source: z.enum(LEAD_SOURCES),
  message: z.string().optional(),
  payload: z.record(z.string(), z.unknown()).optional(),
});
export type LeadInput = z.infer<typeof leadInputSchema>;

export const signupInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  companyName: z.string().optional(),
});
export type SignupInput = z.infer<typeof signupInputSchema>;

export const loginInputSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  role: z.enum(["CLIENT", "STAFF", "CUSTOMER", "SUPER_ADMIN"]),
});
export type LoginInput = z.infer<typeof loginInputSchema>;

export const changePasswordInputSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8, "Password must be at least 8 characters"),
});
export type ChangePasswordInput = z.infer<typeof changePasswordInputSchema>;
