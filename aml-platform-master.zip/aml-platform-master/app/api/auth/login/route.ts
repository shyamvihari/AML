import { NextResponse } from "next/server";
import { loginInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";
import { signToken, verifyPassword, type TokenPayload } from "@/lib/auth";

function toSessionUser(user: { id: string; name: string; email: string; role: string; companyName: string | null }) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, companyName: user.companyName };
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = loginInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { email, password, role } = parsed.data;

  const invalid = () => NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return invalid();
  if (user.role === "CUSTOMER") return invalid();
  const passwordOk = await verifyPassword(password, user.passwordHash);
  if (!passwordOk) return invalid();
  if (user.role !== role) return invalid();

  const token = signToken({ userId: user.id, role: user.role as TokenPayload["role"] });
  return NextResponse.json({ token, user: toSessionUser(user) });
}
