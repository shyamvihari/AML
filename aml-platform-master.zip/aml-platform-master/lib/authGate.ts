const PREFIX = "aml_gate_";

export function saveGatedIntent<T>(key: string, data: T): void {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(`${PREFIX}${key}`, JSON.stringify(data));
}

export function loadGatedIntent<T>(key: string): T | null {
  if (typeof window === "undefined") return null;
  const raw = sessionStorage.getItem(`${PREFIX}${key}`);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function clearGatedIntent(key: string): void {
  if (typeof window === "undefined") return;
  sessionStorage.removeItem(`${PREFIX}${key}`);
}

export function isSafeNextPath(path: string | null): path is string {
  if (!path) return false;
  try {
    const url = new URL(path, window.location.origin);
    return url.origin === window.location.origin && path.startsWith("/");
  } catch {
    return false;
  }
}
