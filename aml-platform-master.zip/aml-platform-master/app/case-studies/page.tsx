import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Case Studies | Compass & Coin",
  description:
    "Illustrative, composite outcome scenarios showing how Compass & Coin supports DNFBP registration, audit readiness, and SAR/STR filing.",
};

const CASE_STUDIES = [
  {
    label: "DNFBP registration scoping",
    title: "A Dubai-based brokerage clarifies its registration position",
    situation:
      "A mid-sized real estate brokerage handling both off-plan and secondary-market sales was uncertain whether all of its transaction types fell within Cabinet Resolution 134 of 2025's DNFBP scope. Internal opinions differed, and no formal assessment had been done.",
    action:
      "Compass & Coin ran a registration-scoping assessment across the brokerage's transaction types and revenue lines, mapped each against the DNFBP criteria, and produced a written scoping memo. Where activities were in scope, we supported the firm through DNFBP registration and drafted the accompanying AML/CFT policy manual.",
    outcome:
      "The brokerage registered as a DNFBP with a clear, documented rationale for its scoping decisions, and had a policy manual in place ahead of its next supervisory review.",
  },
  {
    label: "Audit-readiness engagement",
    title: "A property management firm prepares for a supervisory review",
    situation:
      "A property management firm with an existing AML/CFT programme had never tested it against a formal review. Leadership wanted assurance the programme would hold up before a scheduled supervisory audit.",
    action:
      "We ran a mock regulatory audit against the firm's existing CDD files, screening records, and reporting logs, benchmarked against CBUAE guidance and FATF expectations. We flagged gaps in documentation completeness and re-screening frequency, and worked with the compliance team to close them before the real audit date.",
    outcome:
      "The firm entered its supervisory review with remediated files and a documented action log showing the gaps identified and closed, rather than discovering the gaps during the audit itself.",
  },
  {
    label: "SAR/STR support",
    title: "A developer's sales team escalates an unusual transaction",
    situation:
      "A developer's sales team flagged a high-value off-plan purchase involving a third-party payment structure that didn't match the buyer's stated profile. The firm's designated MLRO wanted an independent view before deciding whether the transaction met the threshold for a filing.",
    action:
      "Compass & Coin reviewed the transaction details and supporting documentation against red-flag indicators and advised that the pattern warranted a Suspicious Transaction Report. We supported the MLRO in preparing the filing content and walked the team through the goAML submission process — the filing itself remained the client's own regulated action.",
    outcome:
      "The firm filed its STR within the appropriate timeframe, with a documented rationale for the decision, and used the episode to tighten its internal escalation process for future flags.",
  },
];

export default function CaseStudiesPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-5xl px-6 py-16">
        <SectionHeading
          eyebrow="Case Studies"
          title="Illustrative outcome scenarios"
          subtitle="These are anonymised, composite scenarios."
        />

        <div className="-mt-6 mb-12 rounded-lg border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950 p-5 text-sm text-amber-900 dark:text-amber-200">
          <strong>Note:</strong> The following are illustrative composite scenarios based on
          typical engagements, not accounts of specific named clients. Details have been
          generalised and combined to demonstrate the kind of work we do while protecting
          client confidentiality — we don't publish real client case studies without their
          explicit consent.
        </div>

        <div className="flex flex-col gap-8">
          {CASE_STUDIES.map((cs) => (
            <article key={cs.title} className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-6">
              <span className="inline-flex w-fit items-center rounded-full bg-offwhite px-3 py-1 text-xs font-semibold uppercase tracking-wide text-neutral-600 dark:text-neutral-300">
                {cs.label}
              </span>
              <h3 className="mt-3 text-xl font-semibold text-charcoal">{cs.title}</h3>

              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400">Situation</p>
                  <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">{cs.situation}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400">What we did</p>
                  <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">{cs.action}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400">Outcome</p>
                  <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">{cs.outcome}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}
