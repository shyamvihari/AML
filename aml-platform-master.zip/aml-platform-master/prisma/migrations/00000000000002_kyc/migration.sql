-- CreateEnum
CREATE TYPE "EntityType" AS ENUM ('SOLE_PROPRIETORSHIP', 'PARTNERSHIP', 'FREE_ZONE', 'LLC', 'PJSC_PSC', 'ASSOCIATION_CLUB_SOCIETY', 'OTHER');

-- CreateEnum
CREATE TYPE "RelatedCompanyScope" AS ENUM ('NONE', 'LOCAL', 'INTERNATIONAL', 'BOTH');

-- CreateEnum
CREATE TYPE "KycStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'NEEDS_UPDATE');

-- CreateEnum
CREATE TYPE "KycDocumentType" AS ENUM ('TRADE_LICENSE', 'GOAML_SCREENSHOT', 'OWNER_ID', 'OTHER');

-- CreateTable
CREATE TABLE "KycProfile" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "status" "KycStatus" NOT NULL DEFAULT 'DRAFT',
    "entityType" "EntityType",
    "entityTypeOther" TEXT,
    "companyName" TEXT,
    "coreBusinessActivity" TEXT,
    "licenseNumber" TEXT,
    "licenseIssueDate" TIMESTAMP(3),
    "licenseExpiryDate" TIMESTAMP(3),
    "countryOfRegistration" TEXT,
    "licenseIssuingAuthority" TEXT,
    "dateOfIncorporation" TIMESTAMP(3),
    "poBox" TEXT,
    "telephone" TEXT,
    "emirate" TEXT,
    "trn" TEXT,
    "orn" TEXT,
    "registeredEmail" TEXT,
    "contactPersonName" TEXT,
    "contactPersonDesignation" TEXT,
    "contactPersonMobile" TEXT,
    "contactPersonEmail" TEXT,
    "estimatedAnnualTurnover" TEXT,
    "relatedCompanyScope" "RelatedCompanyScope" NOT NULL DEFAULT 'NONE',
    "authorizedSignatoryName" TEXT,
    "declarationDate" TIMESTAMP(3),
    "sanctionScreeningStatus" TEXT,
    "mlroApproval" TEXT,
    "mlroRemarks" TEXT,
    "reviewedByUserId" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "KycProfile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "KycOwner" (
    "id" TEXT NOT NULL,
    "kycProfileId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "designation" TEXT,
    "nationality" TEXT,
    "mobileIdType" TEXT,
    "percentShare" DOUBLE PRECISION,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "KycOwner_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "KycDocument" (
    "id" TEXT NOT NULL,
    "kycProfileId" TEXT NOT NULL,
    "type" "KycDocumentType" NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "KycDocument_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "KycProfile_userId_key" ON "KycProfile"("userId");

-- AddForeignKey
ALTER TABLE "KycProfile" ADD CONSTRAINT "KycProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "KycOwner" ADD CONSTRAINT "KycOwner_kycProfileId_fkey" FOREIGN KEY ("kycProfileId") REFERENCES "KycProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "KycDocument" ADD CONSTRAINT "KycDocument_kycProfileId_fkey" FOREIGN KEY ("kycProfileId") REFERENCES "KycProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

