type CustomerLike = {
  customerType: string | null;
  name: string | null;
  companyName: string | null;
  email: string;
  phone: string | null;
  nationality: string | null;
  dateOfBirth: string | null;
  passportOrEmiratesId: string | null;
  idExpiryDate: string | null;
  residentialAddress: string | null;
  occupation: string | null;
  tradeLicenseNumber: string | null;
  licenseAuthority: string | null;
  incorporationDate: string | null;
  registeredAddress: string | null;
  businessActivity: string | null;
  authorizedSignatoryName: string | null;
};

function Row({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div>
      <dt className="text-neutral-500 dark:text-neutral-400">{label}</dt>
      <dd>{value ?? "—"}</dd>
    </div>
  );
}

export function CustomerDetailsSummary({ customer }: { customer: CustomerLike }) {
  const isCorporate = customer.customerType === "CORPORATE";
  return (
    <dl className="grid grid-cols-2 gap-3 text-sm">
      {isCorporate ? (
        <>
          <Row label="Company name" value={customer.companyName} />
          <Row label="Trade license number" value={customer.tradeLicenseNumber} />
          <Row label="License authority" value={customer.licenseAuthority} />
          <Row label="Incorporation date" value={customer.incorporationDate} />
          <Row label="Registered address" value={customer.registeredAddress} />
          <Row label="Business activity" value={customer.businessActivity} />
          <Row label="Authorized signatory" value={customer.authorizedSignatoryName} />
        </>
      ) : (
        <>
          <Row label="Full name" value={customer.name} />
          <Row label="Date of birth" value={customer.dateOfBirth} />
          <Row label="Nationality" value={customer.nationality} />
          <Row label="Passport / Emirates ID" value={customer.passportOrEmiratesId} />
          <Row label="ID expiry date" value={customer.idExpiryDate} />
          <Row label="Residential address" value={customer.residentialAddress} />
          <Row label="Occupation" value={customer.occupation} />
        </>
      )}
      <Row label="Email" value={customer.email} />
      <Row label="Phone" value={customer.phone} />
    </dl>
  );
}
