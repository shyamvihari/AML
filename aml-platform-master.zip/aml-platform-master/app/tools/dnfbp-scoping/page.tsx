import { SectionHeading } from "@/app/SectionHeading";
import { ScopingTool } from "./ScopingTool";

export const metadata = {
  title: "DNFBP Registration Scoping Tool | Compass & Coin",
  description:
    "Answer a few questions about your real estate activity to get a preliminary indicator of whether DNFBP registration under UAE Cabinet Resolution 134 of 2025 is likely required.",
};

export default function DnfbpScopingPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <SectionHeading
        eyebrow="Free tool"
        title="DNFBP Registration Scoping Tool"
        subtitle="Answer three short questions about your firm's real estate activity and get a preliminary, non-binding indicator of whether DNFBP registration under UAE Cabinet Resolution 134 of 2025 is likely required — drawing on our team's day-to-day regulatory work with brokers, developers, and property managers."
      />
      <ScopingTool />
    </div>
  );
}
