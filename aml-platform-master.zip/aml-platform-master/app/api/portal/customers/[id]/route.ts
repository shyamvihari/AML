import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { individualKycFieldsSchema, corporateKycFieldsSchema } from "@/lib/customerSchemas";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findUnique({
    where: { id },
    include: { documents: { orderBy: { uploadedAt: "asc" } } },
  });
  if (!customer || customer.clientUserId !== payload.userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json({ customer });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const customer = await prisma.customer.findFirst({ where: { id, clientUserId: payload.userId } });
  if (!customer || !customer.customerType) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const schema = customer.customerType === "CORPORATE" ? corporateKycFieldsSchema : individualKycFieldsSchema;
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const data =
    customer.customerType === "CORPORATE"
      ? { ...parsed.data, incorporationDate: new Date((parsed.data as { incorporationDate: string }).incorporationDate) }
      : {
          ...parsed.data,
          dateOfBirth: new Date((parsed.data as { dateOfBirth: string }).dateOfBirth),
          idExpiryDate: new Date((parsed.data as { idExpiryDate: string }).idExpiryDate),
        };

  const updated = await prisma.customer.update({ where: { id }, data });
  return NextResponse.json({ customer: updated });
}
