import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import { screeningRecordInputSchema } from "@/lib/screeningSchemas";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const records = await prisma.screeningRecord.findMany({
    where: { kycProfileId: id },
    orderBy: { createdAt: "desc" },
    select: { id: true, subjectName: true, riskRating: true, alertStatus: true, scannedAt: true },
  });
  return NextResponse.json({ records });
}

function toDateOrNull(value: string | undefined | null): Date | null {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  let payload;
  try {
    payload = requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const profile = await prisma.kycProfile.findUnique({ where: { id } });
  if (!profile) return NextResponse.json({ error: "KYC profile not found" }, { status: 404 });

  const body = await request.json().catch(() => null);
  const parsed = screeningRecordInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { identifications, matches, dateOfBirth, scannedAt, ...fields } = parsed.data;

  const created = await prisma.$transaction(async (tx) => {
    const record = await tx.screeningRecord.create({
      data: {
        kycProfileId: id,
        createdByUserId: payload.userId,
        ...fields,
        dateOfBirth: toDateOrNull(dateOfBirth),
        scannedAt: toDateOrNull(scannedAt),
      },
    });

    if (identifications?.length) {
      await tx.screeningIdentification.createMany({
        data: identifications.map((ident, index) => ({
          identityType: ident.identityType,
          identificationNumber: ident.identificationNumber,
          issuingCountry: ident.issuingCountry,
          placeOfIssue: ident.placeOfIssue,
          dateOfIssuance: toDateOrNull(ident.dateOfIssuance),
          dateOfExpiry: toDateOrNull(ident.dateOfExpiry),
          screeningRecordId: record.id,
          sortOrder: index,
        })),
      });
    }

    if (matches?.length) {
      await tx.screeningMatch.createMany({
        data: matches.map((m, index) => ({
          source: m.source,
          matchName: m.matchName,
          matchType: m.matchType,
          nationality: m.nationality,
          matchScore: m.matchScore,
          sourceEntityId: m.sourceEntityId,
          screeningRecordId: record.id,
          sortOrder: index,
        })),
      });
    }

    return record;
  });

  const full = await prisma.screeningRecord.findUnique({
    where: { id: created.id },
    include: {
      identifications: { orderBy: { sortOrder: "asc" } },
      matches: { orderBy: { sortOrder: "asc" } },
    },
  });
  return NextResponse.json({ record: full }, { status: 201 });
}
