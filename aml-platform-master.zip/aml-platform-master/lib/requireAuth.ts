import { verifyToken, type TokenPayload } from "./auth";

export class UnauthorizedError extends Error {}

function getCookieToken(request: Request): string | null {
  const cookieHeader = request.headers.get("cookie");
  if (!cookieHeader) return null;
  const match = cookieHeader.match(/(?:^|;\s*)aml_token=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

export function requireAuth(request: Request): TokenPayload {
  const header = request.headers.get("authorization");
  const bearerToken = header?.startsWith("Bearer ") ? header.slice(7) : null;
  const token = bearerToken ?? getCookieToken(request);
  if (!token) throw new UnauthorizedError("Not authenticated");
  const payload = verifyToken(token);
  if (!payload) throw new UnauthorizedError("Invalid or expired token");
  return payload;
}
