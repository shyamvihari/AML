import { SectionHeading } from "../SectionHeading";

export const metadata = {
  title: "Legal | Compass & Coin",
  description:
    "Privacy Policy, Terms of Engagement, and Cookie Policy for the Compass & Coin website.",
};

export default function LegalPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <SectionHeading
        eyebrow="Legal"
        title="Legal information"
        subtitle="Privacy Policy, Terms of Engagement, and Cookie Policy for this website."
      />

      <div className="flex flex-col gap-16">
        <section id="privacy" className="scroll-mt-24">
          <h3 className="mb-4 text-xl font-semibold text-charcoal">Privacy Policy</h3>
          <div className="flex flex-col gap-4 text-neutral-700 dark:text-neutral-300">
            <p>
              Compass & Coin Technologies FZE ("Compass & Coin," "we," "us")
              handles personal data submitted through this website in line
              with UAE Federal Decree-Law No. 45 of 2021 on the Protection of
              Personal Data (PDPL). This policy describes what we actually
              collect and do with that data today.
            </p>
            <p>
              <span className="font-medium text-charcoal">What we collect.</span>{" "}
              When you use the enquiry or consultation-booking form on this
              site, we collect the fields you submit: your name, email
              address, phone number, company name, the category that best
              describes you, and any message you choose to include. We do not
              collect payment information, government ID numbers, or other
              sensitive personal data through this website.
            </p>
            <p>
              <span className="font-medium text-charcoal">How we use it.</span>{" "}
              We use the information you submit to route your enquiry to the
              right person at Compass & Coin, respond to your request, and, if
              you go on to become a client, to deliver the AML advisory
              services you've engaged us for. We do not sell, rent, or trade
              your personal data to third parties, and we do not use it for
              advertising.
            </p>
            <p>
              <span className="font-medium text-charcoal">Where it's stored.</span>{" "}
              Form submissions are stored in a database that supports our
              enquiry-handling process. Access is limited to Compass & Coin
              personnel who need it to respond to your enquiry or deliver
              services. We retain enquiry records for as long as reasonably
              necessary to handle your request and, where a client
              relationship follows, in line with the record-keeping practice
              expected of a regulated AML advisory business; we review and
              remove data we no longer have a legitimate reason to hold.
            </p>
            <p>
              <span className="font-medium text-charcoal">Your rights.</span>{" "}
              Under the PDPL, you may request access to, correction of, or
              deletion of personal data we hold about you, and you may object
              to specific processing. To exercise any of these rights, contact
              us at{" "}
              <a
                href="mailto:admin@compassandcoin.com"
                className="font-medium text-brand-start hover:underline"
              >
                admin@compassandcoin.com
              </a>
              .
            </p>
          </div>
        </section>

        <section id="terms" className="scroll-mt-24">
          <h3 className="mb-4 text-xl font-semibold text-charcoal">Terms of Engagement</h3>
          <div className="flex flex-col gap-4 text-neutral-700 dark:text-neutral-300">
            <p>
              These terms cover your use of this website and the process of
              booking a consultation through it. They are not, and are not
              intended to be, a client services agreement — any engagement of
              Compass & Coin for AML advisory, registration, or compliance
              services is governed by a separate signed engagement letter or
              services agreement negotiated directly with you, which takes
              precedence over anything on this site.
            </p>
            <p>
              The content on this website — including service descriptions,
              regulatory references, and general commentary on AML obligations
              — is provided for general informational purposes and does not
              constitute legal or regulatory advice. Regulatory requirements
              referenced on this site, including those under Cabinet
              Resolution No. 134 of 2025 and related AML legislation, can
              change, and you should not rely on this website alone as a
              substitute for engaging us or another qualified advisor for
              advice specific to your circumstances.
            </p>
            <p>
              Submitting an enquiry or booking a consultation through this
              site does not by itself create a client relationship or any
              obligation on Compass & Coin's part to provide services. A
              client relationship begins only once both parties have agreed
              scope, fees, and terms in a separate engagement document.
            </p>
            <p>
              We aim to keep the information on this site accurate and
              current, but we make no warranty that it is complete or
              error-free, and we are not liable for actions taken in reliance
              on general website content rather than a formal engagement.
            </p>
          </div>
        </section>

        <section id="cookies" className="scroll-mt-24">
          <h3 className="mb-4 text-xl font-semibold text-charcoal">Cookie Policy</h3>
          <div className="flex flex-col gap-4 text-neutral-700 dark:text-neutral-300">
            <p>
              This website does not currently use analytics or tracking
              cookies. We are not running any third-party analytics,
              advertising, or behavioral-tracking scripts, and we do not
              currently place cookies on your device to monitor your activity
              across this site or elsewhere.
            </p>
            <p>
              Any cookies strictly required for the site's basic technical
              operation — for example, to support form submission — are
              limited to that purpose. If we introduce analytics or other
              non-essential cookies in the future, we will update this policy
              to describe what is collected, why, and how you can control it
              before any such tracking goes live.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
