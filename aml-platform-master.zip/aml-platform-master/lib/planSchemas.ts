import { z } from "zod";

export const SCREENING_PLANS = ["REGULAR", "PRO", "MAX"] as const;
export type ScreeningPlanValue = (typeof SCREENING_PLANS)[number];

// null = unlimited. Single source of truth for every quota check and every
// UI display of a plan's limit.
export const PLAN_LIMITS: Record<ScreeningPlanValue, number | null> = {
  REGULAR: 5,
  PRO: 50,
  MAX: null,
};

export const PLAN_LABELS: Record<ScreeningPlanValue, string> = {
  REGULAR: "Regular",
  PRO: "Pro",
  MAX: "Max",
};

export const PLAN_DESCRIPTIONS: Record<ScreeningPlanValue, string> = {
  REGULAR: "Up to 5 customer screenings per day.",
  PRO: "Up to 50 customer screenings per day.",
  MAX: "Unlimited customer screenings per day.",
};

// The plan to suggest upgrading to when the current one is exhausted. MAX
// has no next plan (it never blocks, so this is never read for MAX).
export const NEXT_PLAN: Record<ScreeningPlanValue, ScreeningPlanValue | null> = {
  REGULAR: "PRO",
  PRO: "MAX",
  MAX: null,
};

export const planInputSchema = z.object({
  plan: z.enum(SCREENING_PLANS),
});
export type PlanInput = z.infer<typeof planInputSchema>;
