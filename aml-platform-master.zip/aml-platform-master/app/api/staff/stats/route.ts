import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";

export async function GET(request: Request) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const [clientCount, customerCount, planGroups, screeningsTotal] = await Promise.all([
    prisma.user.count({ where: { role: "CLIENT" } }),
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.user.groupBy({ by: ["plan"], where: { role: "CLIENT" }, _count: { plan: true } }),
    prisma.customerScreeningRecord.count(),
  ]);

  const planBreakdown = { REGULAR: 0, PRO: 0, MAX: 0 };
  for (const group of planGroups) {
    planBreakdown[group.plan] = group._count.plan;
  }

  return NextResponse.json({ clientCount, customerCount, planBreakdown, screeningsTotal });
}
