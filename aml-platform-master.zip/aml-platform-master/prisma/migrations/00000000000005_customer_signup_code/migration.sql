-- AlterTable
ALTER TABLE "User" ADD COLUMN     "customerSignupCode" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "User_customerSignupCode_key" ON "User"("customerSignupCode");

