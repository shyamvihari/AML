import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireInvite, InviteInvalidError } from "@/lib/requireInvite";

export async function GET(request: Request, { params }: { params: Promise<{ token: string; docId: string }> }) {
  const { token, docId } = await params;
  let invite;
  try {
    invite = await requireInvite(token);
  } catch (err) {
    if (err instanceof InviteInvalidError) return NextResponse.json({ error: err.message }, { status: 410 });
    throw err;
  }

  const document = await prisma.customerDocument.findUnique({ where: { id: docId } });
  if (!document || document.customerId !== invite.customerId) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  const blobRes = await fetch(document.fileUrl, {
    headers: { authorization: `Bearer ${process.env.BLOB_READ_WRITE_TOKEN}` },
  });
  if (!blobRes.ok || !blobRes.body) {
    return NextResponse.json({ error: "Document could not be retrieved" }, { status: 502 });
  }

  const safeFileName = document.fileName.replace(/["\r\n]/g, "");
  return new NextResponse(blobRes.body, {
    headers: {
      "Content-Type": blobRes.headers.get("content-type") ?? "application/octet-stream",
      "Content-Disposition": `attachment; filename="${safeFileName}"`,
    },
  });
}
