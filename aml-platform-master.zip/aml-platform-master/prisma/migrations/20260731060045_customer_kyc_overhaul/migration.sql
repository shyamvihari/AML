/*
  Warnings:

  - You are about to drop the column `customerSignupCode` on the `User` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "CustomerType" AS ENUM ('INDIVIDUAL', 'CORPORATE');

-- CreateEnum
CREATE TYPE "InvitePurpose" AS ENUM ('DATA_ENTRY', 'REVIEW_SIGNATURE');

-- DropIndex
DROP INDEX "User_customerSignupCode_key";

-- AlterTable
ALTER TABLE "Customer" ADD COLUMN     "authorizedSignatoryName" TEXT,
ADD COLUMN     "businessActivity" TEXT,
ADD COLUMN     "customerType" "CustomerType",
ADD COLUMN     "dateOfBirth" TIMESTAMP(3),
ADD COLUMN     "idExpiryDate" TIMESTAMP(3),
ADD COLUMN     "incorporationDate" TIMESTAMP(3),
ADD COLUMN     "licenseAuthority" TEXT,
ADD COLUMN     "occupation" TEXT,
ADD COLUMN     "passportOrEmiratesId" TEXT,
ADD COLUMN     "registeredAddress" TEXT,
ADD COLUMN     "residentialAddress" TEXT,
ADD COLUMN     "signatureUrl" TEXT,
ADD COLUMN     "signedAt" TIMESTAMP(3),
ADD COLUMN     "signedByUserId" TEXT,
ADD COLUMN     "tradeLicenseNumber" TEXT;

-- AlterTable
ALTER TABLE "User" DROP COLUMN "customerSignupCode";

-- CreateTable
CREATE TABLE "CustomerInvite" (
    "id" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "purpose" "InvitePurpose" NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerEmail" TEXT NOT NULL,
    "consumedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CustomerInvite_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "CustomerInvite_token_key" ON "CustomerInvite"("token");

-- AddForeignKey
ALTER TABLE "Customer" ADD CONSTRAINT "Customer_signedByUserId_fkey" FOREIGN KEY ("signedByUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerInvite" ADD CONSTRAINT "CustomerInvite_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Backfill existing Customer rows so customerType is never left null
UPDATE "Customer" SET "customerType" = 'INDIVIDUAL' WHERE "customerType" IS NULL;
