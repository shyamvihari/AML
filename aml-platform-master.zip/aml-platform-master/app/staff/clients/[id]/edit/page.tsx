"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";

export default function EditClientPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newPassword, setNewPassword] = useState<string | null>(null);
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || (user.role !== "STAFF" && user.role !== "SUPER_ADMIN")) return;
    const token = getClientToken();
    fetch(`/api/staff/clients/${id}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => {
        if (body) {
          setName(body.client.name);
          setEmail(body.client.email);
          setCompanyName(body.client.companyName ?? "");
        }
        setLoaded(true);
      });
  }, [user, id]);

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm w-full";
  const labelClass = "flex flex-col gap-1 text-sm";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    const token = getClientToken();
    const res = await fetch(`/api/staff/clients/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ name, email, companyName: companyName || undefined }),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not save changes. Please check the form and try again.");
      setSaving(false);
      return;
    }
    setSaved(true);
    setSaving(false);
  }

  async function resetPassword() {
    if (!window.confirm("Generate a new temporary password for this client? Their current password will stop working immediately.")) {
      return;
    }
    setResetting(true);
    setError(null);
    const token = getClientToken();
    const res = await fetch(`/api/staff/clients/${id}/reset-password`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    const body = await res.json();
    if (!res.ok) {
      setError(typeof body.error === "string" ? body.error : "Could not reset password. Please try again.");
      setResetting(false);
      return;
    }
    setNewPassword(body.tempPassword);
    setResetting(false);
  }

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }

  if (!loaded) {
    return <div className="mx-auto max-w-lg px-6 py-16 text-sm text-neutral-500 dark:text-neutral-400">Loading...</div>;
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-16">
      <Link href="/staff" className="text-sm text-brand-start hover:underline">← Back to dashboard</Link>
      <h1 className="mt-3 text-2xl font-semibold text-charcoal">Edit client</h1>
      {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <form onSubmit={submit} className="mt-6 flex flex-col gap-3">
        <label className={labelClass}>
          Name
          <input required value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Company name (optional)
          <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className={inputClass} />
        </label>
        {saved && <p className="text-sm text-green-700 dark:text-green-400">Saved.</p>}
        <button
          type="submit"
          disabled={saving}
          className="w-fit rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving..." : "Save"}
        </button>
      </form>

      <div className="mt-8 flex flex-col gap-2 rounded-md border border-neutral-200 dark:border-neutral-700 p-4">
        <h2 className="text-sm font-semibold text-charcoal">Reset password</h2>
        {newPassword ? (
          <p className="text-sm text-charcoal">
            New temporary password: <code className="rounded bg-offwhite px-1.5 py-0.5">{newPassword}</code> — share
            this with the client directly, it won&apos;t be shown again.
          </p>
        ) : (
          <>
            <p className="text-sm text-neutral-600 dark:text-neutral-300">
              Generates a new one-time password for this client and immediately invalidates their current one.
            </p>
            <button
              type="button"
              onClick={resetPassword}
              disabled={resetting}
              className="w-fit rounded-md border border-red-300 dark:border-red-800 px-3 py-1.5 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 disabled:opacity-50"
            >
              {resetting ? "Resetting..." : "Reset password"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
