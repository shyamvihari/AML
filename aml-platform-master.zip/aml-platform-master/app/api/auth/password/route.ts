import { NextResponse } from "next/server";
import { changePasswordInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";
import { hashPassword, verifyPassword } from "@/lib/auth";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";

export async function PATCH(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = changePasswordInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { currentPassword, newPassword } = parsed.data;

  const user = await prisma.user.findUniqueOrThrow({ where: { id: payload.userId } });
  const currentOk = await verifyPassword(currentPassword, user.passwordHash);
  if (!currentOk) return NextResponse.json({ error: "Current password is incorrect" }, { status: 401 });

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash } });
  return NextResponse.json({}, { status: 200 });
}
