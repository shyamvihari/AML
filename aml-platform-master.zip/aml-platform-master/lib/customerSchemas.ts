import { z } from "zod";

export const CUSTOMER_TYPES = ["INDIVIDUAL", "CORPORATE"] as const;

export const CUSTOMER_TYPE_LABELS: Record<(typeof CUSTOMER_TYPES)[number], string> = {
  INDIVIDUAL: "Individual",
  CORPORATE: "Corporate",
};

export const CUSTOMER_DOCUMENT_TYPES = ["EMIRATES_ID", "PASSPORT", "TRADE_LICENSE", "OTHER"] as const;

export const CUSTOMER_DOCUMENT_TYPE_LABELS: Record<(typeof CUSTOMER_DOCUMENT_TYPES)[number], string> = {
  EMIRATES_ID: "Emirates ID",
  PASSPORT: "Passport",
  TRADE_LICENSE: "Trade License",
  OTHER: "Other",
};

export const CUSTOMER_SCREENING_RISK_RATINGS = ["LOW", "MEDIUM", "HIGH", "UNRATED"] as const;

export const CUSTOMER_SCREENING_RISK_RATING_LABELS: Record<(typeof CUSTOMER_SCREENING_RISK_RATINGS)[number], string> = {
  LOW: "Low",
  MEDIUM: "Medium",
  HIGH: "High",
  UNRATED: "Unrated",
};

export const customerInputSchema = z.object({
  customerType: z.enum(CUSTOMER_TYPES).optional(),
  name: z.string().optional(),
  companyName: z.string().optional(),
  email: z.string().email("Valid email is required"),
  phone: z.string().optional(),
  nationality: z.string().optional(),
  idType: z.string().optional(),
  idNumber: z.string().optional(),
  notes: z.string().optional(),
});
export type CustomerInput = z.infer<typeof customerInputSchema>;

export const individualKycFieldsSchema = z.object({
  name: z.string().min(1, "Name is required"),
  dateOfBirth: z.string().min(1, "Date of birth is required"),
  nationality: z.string().min(1, "Nationality is required"),
  passportOrEmiratesId: z.string().min(1, "Passport or Emirates ID number is required"),
  idExpiryDate: z.string().min(1, "ID expiry date is required"),
  residentialAddress: z.string().min(1, "Residential address is required"),
  occupation: z.string().min(1, "Occupation is required"),
  phone: z.string().optional(),
  email: z.string().email("Valid email is required"),
});
export type IndividualKycFieldsInput = z.infer<typeof individualKycFieldsSchema>;

export const corporateKycFieldsSchema = z.object({
  companyName: z.string().min(1, "Company name is required"),
  tradeLicenseNumber: z.string().min(1, "Trade license number is required"),
  licenseAuthority: z.string().min(1, "License authority is required"),
  incorporationDate: z.string().min(1, "Incorporation date is required"),
  registeredAddress: z.string().min(1, "Registered address is required"),
  businessActivity: z.string().min(1, "Business activity is required"),
  authorizedSignatoryName: z.string().min(1, "Authorized signatory name is required"),
  phone: z.string().optional(),
  email: z.string().email("Valid email is required"),
});
export type CorporateKycFieldsInput = z.infer<typeof corporateKycFieldsSchema>;

export const customerScreeningIdentificationSchema = z.object({
  identityType: z.string().min(1, "Identity type is required"),
  identificationNumber: z.string().min(1, "Identification number is required"),
});
export type CustomerScreeningIdentificationInput = z.infer<typeof customerScreeningIdentificationSchema>;

export const customerScreeningMatchSchema = z.object({
  source: z.string().min(1, "Source is required"),
  matchName: z.string().min(1, "Match name is required"),
  matchScore: z.number().min(0).max(1).optional(),
  sourceEntityId: z.string().optional(),
});
export type CustomerScreeningMatchInput = z.infer<typeof customerScreeningMatchSchema>;

export const customerScreeningRecordInputSchema = z.object({
  subjectName: z.string().min(1, "Subject name is required"),
  riskRating: z.enum(CUSTOMER_SCREENING_RISK_RATINGS).optional(),
  scannedAt: z.string().optional(),
  screenedBy: z.string().optional(),
  alertRaised: z.boolean().optional(),
  sanctionMatchCount: z.number().int().min(0).optional(),
  notes: z.string().optional(),
  identifications: z.array(customerScreeningIdentificationSchema).optional(),
  matches: z.array(customerScreeningMatchSchema).optional(),
});
export type CustomerScreeningRecordInput = z.infer<typeof customerScreeningRecordInputSchema>;

