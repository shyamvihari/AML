"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { getCurrentUser, type SessionUser } from "@/lib/session";
import { PlatformOverview } from "../PlatformOverview";

export default function StaffDashboardPage() {
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  if (user && user.role !== "STAFF" && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Staff access required.</div>;
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Staff Dashboard</h1>
      <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
        {user ? `Welcome, ${user.name}.` : "Loading..."}
      </p>
      <div className="mt-8">
        <PlatformOverview />
      </div>
      <div className="mt-8">
        <Link href="/staff/kyc" className="text-sm text-brand-start hover:underline">
          Go to KYC Review Queue →
        </Link>
      </div>
    </div>
  );
}
