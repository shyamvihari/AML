export function ThemeScript() {
  const script = `
    try {
      var t = localStorage.getItem("aml_theme");
      if (t === "dark") document.documentElement.classList.add("dark");
    } catch (e) {}
  `;
  // eslint-disable-next-line react/no-danger
  return <script dangerouslySetInnerHTML={{ __html: script }} />;
}
