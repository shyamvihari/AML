# Compass & Coin — AML Platform Marketing Site

Public marketing website for Compass & Coin's AML/compliance advisory platform,
built with Next.js (App Router), React 19, and Tailwind CSS v4.

## Development

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Stack

- Next.js 16 / React 19
- Tailwind CSS v4 (`app/globals.css` defines the brand theme tokens:
  `--color-brand-start`, `--color-brand-end`, `--color-charcoal`, `--color-offwhite`)
- TypeScript, ESLint (`eslint-config-next`)

## Brand assets

- `public/compass-and-coin-logo.png` — full logo (wordmark + compass mark)
- `public/compass-mark.png` — cropped compass-only mark, used as the favicon source
- `app/favicon.ico` — 32×32 favicon generated from `compass-mark.png`

## Notes

- `app/WhatsAppButton.tsx` uses a placeholder WhatsApp number — swap for
  Compass & Coin's real WhatsApp Business number before go-live.
