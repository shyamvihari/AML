"use client";

import { useEffect, useState } from "react";
import { getStoredTheme, setStoredTheme, type Theme } from "@/lib/theme";

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    setTheme(getStoredTheme());
  }, []);

  function choose(next: Theme) {
    setStoredTheme(next);
    setTheme(next);
  }

  return (
    <div className="flex rounded-md border border-neutral-300 dark:border-neutral-600 p-1 text-sm">
      <button
        type="button"
        onClick={() => choose("light")}
        className={`flex-1 rounded px-3 py-1.5 ${theme === "light" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
      >
        Light
      </button>
      <button
        type="button"
        onClick={() => choose("dark")}
        className={`flex-1 rounded px-3 py-1.5 ${theme === "dark" ? "bg-brand-gradient text-white" : "hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
      >
        Dark
      </button>
    </div>
  );
}
