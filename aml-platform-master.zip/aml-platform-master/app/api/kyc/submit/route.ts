import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";
import { kycSubmitSchema } from "@/lib/kycSchemas";

export async function POST(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = kycSubmitSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const existing = await prisma.kycProfile.findUnique({ where: { userId: payload.userId } });
  if (!existing) {
    return NextResponse.json({ error: "Save the form before submitting" }, { status: 400 });
  }
  if (existing.status !== "DRAFT" && existing.status !== "NEEDS_UPDATE") {
    return NextResponse.json(
      { error: `Cannot submit from status ${existing.status}` },
      { status: 400 },
    );
  }

  await prisma.kycProfile.update({ where: { id: existing.id }, data: { status: "SUBMITTED" } });

  const profile = await prisma.kycProfile.findUnique({
    where: { id: existing.id },
    include: { owners: { orderBy: { sortOrder: "asc" } }, documents: { orderBy: { uploadedAt: "asc" } } },
  });
  return NextResponse.json({ profile });
}
