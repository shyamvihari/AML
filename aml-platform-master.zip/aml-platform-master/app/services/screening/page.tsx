import Link from "next/link";
import { SectionHeading } from "../../SectionHeading";

export const metadata = {
  title: "Screening | Compass & Coin",
  description:
    "Sanctions, PEP, and adverse-media screening at onboarding and on an ongoing basis, with a structured match-review workflow.",
};

const FREQUENCY_OPTIONS = [
  {
    label: "Onboarding only",
    description:
      "A one-time sanctions, PEP, and adverse-media screen run at the point of client onboarding. Suits low-frequency or one-off transactions where the relationship doesn't continue afterward.",
  },
  {
    label: "Quarterly",
    description:
      "Onboarding screening plus a re-screen every quarter, catching new sanctions listings or adverse-media coverage that emerges after a relationship is established.",
  },
  {
    label: "Continuous monitoring",
    description:
      "Onboarding screening plus perpetual monitoring, with automatic re-screening triggered whenever watchlists update. The standard approach for ongoing client relationships and higher-risk portfolios.",
  },
];

const ALERT_WORKFLOW = [
  { step: "1", label: "Screening run", description: "A client or transaction party is checked against sanctions, PEP, and adverse-media sources." },
  { step: "2", label: "Match flagged", description: "A potential match is surfaced for review rather than automatically actioned." },
  { step: "3", label: "Reviewer adjudicates", description: "A trained reviewer assesses the match and determines true-positive or false-positive." },
  { step: "4", label: "Outcome logged", description: "The decision and its rationale are recorded on the client file for audit purposes." },
];

export default function ScreeningPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <SectionHeading
          eyebrow="Pillar C"
          title="Screening"
          subtitle="Sanctions, PEP, and adverse-media screening at onboarding and on an ongoing basis, with a documented process for reviewing every match."
        />

        <div className="flex flex-col gap-10 text-neutral-700 dark:text-neutral-300">
          <section>
            <h3 className="text-xl font-semibold text-charcoal">Sanctions, PEP, and adverse-media screening</h3>
            <p className="mt-3">
              Every client and transaction party is screened against the sanctions lists
              a UAE DNFBP is expected to check: the UN Consolidated List, OFAC's
              Specially Designated Nationals list, EU sanctions, UK OFSI's consolidated
              list, and the UAE Local Terrorist List. Alongside sanctions screening, we
              check for politically exposed person (PEP) status and adverse media —
              negative news coverage that may not appear on a formal list but is
              nonetheless relevant to assessing risk.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Ongoing monitoring, not a one-time check</h3>
            <p className="mt-3">
              Sanctions and PEP status aren't static — a client who screened clean at
              onboarding can appear on a list months later. Perpetual monitoring
              re-screens your existing client book automatically whenever the underlying
              watchlists update, so a new designation is caught without waiting for the
              next scheduled review.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Choosing a screening frequency</h3>
            <p className="mt-3">
              How often you re-screen depends on the nature of your client relationships.
              These are the illustrative frequency options we configure for clients —
              pricing for each is covered on our{" "}
              <Link href="/pricing" className="text-brand-start underline">
                pricing page
              </Link>
              , not here:
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {FREQUENCY_OPTIONS.map((option) => (
                <div key={option.label} className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-4">
                  <p className="text-sm font-semibold text-charcoal">{option.label}</p>
                  <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{option.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">How a flagged match gets resolved</h3>
            <p className="mt-3">
              A screening hit is not the same as a confirmed match — names and entities
              can overlap without being the same party. Every flagged result goes through
              a structured review before any decision is made:
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-4">
              {ALERT_WORKFLOW.map((item, index) => (
                <div key={item.step} className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-brand-gradient text-xs font-semibold text-white">
                      {item.step}
                    </span>
                    {index < ALERT_WORKFLOW.length - 1 && (
                      <span className="hidden h-px flex-1 bg-neutral-200 dark:bg-neutral-700 sm:block" />
                    )}
                  </div>
                  <p className="text-sm font-semibold text-charcoal">{item.label}</p>
                  <p className="text-sm text-neutral-600 dark:text-neutral-300">{item.description}</p>
                </div>
              ))}
            </div>
            <p className="mt-4">
              Reviewers adjudicate each match as a true positive or false positive, and
              the outcome — along with the reasoning behind it — is logged against the
              client file, so the decision can be explained to a regulator later, not
              just remembered.
            </p>
          </section>

          <section className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-6">
            <h3 className="text-lg font-semibold text-charcoal">Set up screening for your client book</h3>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
              We'll recommend a screening frequency based on your client mix and
              transaction volume on a scoping call.
            </p>
            <Link
              href="/contact?intent=scoping-call"
              className="mt-4 inline-block rounded-md bg-brand-gradient px-5 py-3 text-sm font-medium text-white hover:opacity-90"
            >
              Book a Free AML Scoping Call
            </Link>
          </section>
        </div>
      </div>
    </main>
  );
}
