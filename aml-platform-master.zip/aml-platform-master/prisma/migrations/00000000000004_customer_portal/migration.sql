-- CreateEnum
CREATE TYPE "CustomerReviewStatus" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'COMPLETED');

-- CreateEnum
CREATE TYPE "CustomerDocumentType" AS ENUM ('EMIRATES_ID', 'PASSPORT', 'TRADE_LICENSE', 'OTHER');

-- CreateEnum
CREATE TYPE "CustomerScreeningRiskRating" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'UNRATED');

-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'CUSTOMER';

-- CreateTable
CREATE TABLE "Customer" (
    "id" TEXT NOT NULL,
    "clientUserId" TEXT NOT NULL,
    "customerUserId" TEXT NOT NULL,
    "name" TEXT,
    "companyName" TEXT,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "nationality" TEXT,
    "idType" TEXT,
    "idNumber" TEXT,
    "notes" TEXT,
    "status" "CustomerReviewStatus" NOT NULL DEFAULT 'DRAFT',
    "customerNote" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Customer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomerDocument" (
    "id" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "type" "CustomerDocumentType" NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CustomerDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomerScreeningRecord" (
    "id" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "subjectName" TEXT NOT NULL,
    "riskRating" "CustomerScreeningRiskRating" NOT NULL DEFAULT 'UNRATED',
    "scannedAt" TIMESTAMP(3),
    "screenedBy" TEXT,
    "alertRaised" BOOLEAN NOT NULL DEFAULT false,
    "sanctionMatchCount" INTEGER NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdByUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CustomerScreeningRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomerScreeningIdentification" (
    "id" TEXT NOT NULL,
    "screeningRecordId" TEXT NOT NULL,
    "identityType" TEXT NOT NULL,
    "identificationNumber" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "CustomerScreeningIdentification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomerScreeningMatch" (
    "id" TEXT NOT NULL,
    "screeningRecordId" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "matchName" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "CustomerScreeningMatch_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Customer_customerUserId_key" ON "Customer"("customerUserId");

-- AddForeignKey
ALTER TABLE "Customer" ADD CONSTRAINT "Customer_clientUserId_fkey" FOREIGN KEY ("clientUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Customer" ADD CONSTRAINT "Customer_customerUserId_fkey" FOREIGN KEY ("customerUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerDocument" ADD CONSTRAINT "CustomerDocument_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerScreeningRecord" ADD CONSTRAINT "CustomerScreeningRecord_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerScreeningIdentification" ADD CONSTRAINT "CustomerScreeningIdentification_screeningRecordId_fkey" FOREIGN KEY ("screeningRecordId") REFERENCES "CustomerScreeningRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerScreeningMatch" ADD CONSTRAINT "CustomerScreeningMatch_screeningRecordId_fkey" FOREIGN KEY ("screeningRecordId") REFERENCES "CustomerScreeningRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

