import Link from "next/link";

export function Footer() {
  return (
    <footer id="site-footer" className="border-t border-neutral-200 dark:border-neutral-700 bg-offwhite">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-10 text-sm text-charcoal sm:flex-row sm:justify-between">
        <div>
          <p className="font-semibold">Compass & Coin Technologies FZE</p>
          <p>301, Abstract Business Center, Motor City, Dubai, United Arab Emirates</p>
          <p>
            <a href="mailto:admin@compassandcoin.com" className="hover:text-brand-start">
              admin@compassandcoin.com
            </a>
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <Link href="/legal#privacy" className="hover:text-brand-start">Privacy Policy</Link>
          <Link href="/legal#terms" className="hover:text-brand-start">Terms of Engagement</Link>
          <Link href="/legal#cookies" className="hover:text-brand-start">Cookie Policy</Link>
          <Link href="/careers" className="hover:text-brand-start">Careers</Link>
        </div>
      </div>
    </footer>
  );
}
