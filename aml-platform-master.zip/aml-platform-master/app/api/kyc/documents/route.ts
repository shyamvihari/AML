import { NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { prisma } from "@/lib/prisma";
import { requireAuth, UnauthorizedError } from "@/lib/requireAuth";
import { KYC_DOCUMENT_TYPES } from "@/lib/kycSchemas";

export async function POST(request: Request) {
  let payload;
  try {
    payload = requireAuth(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }

  const profile = await prisma.kycProfile.findUnique({ where: { userId: payload.userId } });
  if (!profile) {
    return NextResponse.json({ error: "Save the KYC form before uploading documents" }, { status: 400 });
  }

  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  const type = formData?.get("type");
  if (!(file instanceof File) || typeof type !== "string") {
    return NextResponse.json({ error: "A file and document type are required" }, { status: 400 });
  }
  const MAX_FILE_SIZE = 15 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    return NextResponse.json({ error: "File must be 15MB or smaller" }, { status: 400 });
  }
  if (!(KYC_DOCUMENT_TYPES as readonly string[]).includes(type)) {
    return NextResponse.json({ error: "Invalid document type" }, { status: 400 });
  }

  const blob = await put(`kyc/${profile.id}/${Date.now()}-${file.name}`, file, {
    access: "private",
    addRandomSuffix: true,
    token: process.env.BLOB_READ_WRITE_TOKEN,
  });

  const document = await prisma.kycDocument.create({
    data: {
      kycProfileId: profile.id,
      type: type as (typeof KYC_DOCUMENT_TYPES)[number],
      fileName: file.name,
      fileUrl: blob.url,
    },
  });

  return NextResponse.json({ document }, { status: 201 });
}
