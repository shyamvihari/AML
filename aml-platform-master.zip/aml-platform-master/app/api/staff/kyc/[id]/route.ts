import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const profile = await prisma.kycProfile.findUnique({
    where: { id },
    include: {
      owners: { orderBy: { sortOrder: "asc" } },
      documents: { orderBy: { uploadedAt: "asc" } },
      user: { select: { name: true, email: true } },
    },
  });
  if (!profile) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json({ profile });
}
