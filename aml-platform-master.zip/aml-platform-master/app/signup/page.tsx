"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { setSession, type SessionUser } from "@/lib/session";
import { isSafeNextPath } from "@/lib/authGate";

export default function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loginHref, setLoginHref] = useState("/login");

  useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    setLoginHref(qs.toString() ? `/login?${qs.toString()}` : "/login");
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, companyName }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        const message =
          typeof body.error === "string" ? body.error : body.error?.formErrors?.[0] ?? "Signup failed. Please try again.";
        throw new Error(message);
      }
      const data = (await res.json()) as { token: string; user: SessionUser };
      setSession(data.token, data.user);
      const next = new URLSearchParams(window.location.search).get("next");
      window.location.href = isSafeNextPath(next) ? next : "/portal";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const inputClass = "rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2";
  const labelClass = "flex flex-col gap-1 text-sm";

  return (
    <div className="mx-auto flex max-w-sm flex-col gap-6 px-6 py-16">
      <h1 className="text-2xl font-semibold text-charcoal">Sign up</h1>

      <form onSubmit={submit} className="flex flex-col gap-3">
        <label className={labelClass}>
          Name
          <input required value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Company name (optional)
          <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
        </label>
        <label className={labelClass}>
          Password
          <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className={inputClass} />
        </label>
        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Signing up..." : "Sign up"}
        </button>
      </form>

      <p className="text-center text-sm text-neutral-600 dark:text-neutral-300">
        Already have an account? <Link href={loginHref} className="text-brand-start hover:underline">Log in</Link>
      </p>
    </div>
  );
}
