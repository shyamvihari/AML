"use client";

import { useEffect, useState } from "react";
import { getCurrentUser, getClientToken, type SessionUser } from "@/lib/session";
import { SectionHeading } from "../SectionHeading";
import { PortalSidebar } from "./PortalSidebar";
import { PLAN_LABELS, type ScreeningPlanValue } from "@/lib/planSchemas";

export default function PortalPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [plan, setPlan] = useState<ScreeningPlanValue | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || user.role !== "CLIENT") return;
    const token = getClientToken();
    fetch("/api/portal/plan", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => (res.ok ? res.json() : null))
      .then((body) => body && setPlan(body.plan));
  }, [user]);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-16 md:flex-row">
      <PortalSidebar />
      <div className="flex-1">
        <SectionHeading
          eyebrow="Client Portal"
          title={user ? `Welcome, ${user.name}` : "Welcome"}
          subtitle={
            user?.companyName
              ? `${user.companyName} — your KYC and screening status will appear here as those features come online.`
              : "Your KYC and screening status will appear here as those features come online."
          }
        />
        <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
          <h2 className="mb-3 text-lg font-medium text-charcoal">Account</h2>
          {user ? (
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-neutral-500 dark:text-neutral-400">Name</dt>
                <dd>{user.name}</dd>
              </div>
              <div>
                <dt className="text-neutral-500 dark:text-neutral-400">Email</dt>
                <dd>{user.email}</dd>
              </div>
              <div>
                <dt className="text-neutral-500 dark:text-neutral-400">Role</dt>
                <dd className="uppercase">{user.role}</dd>
              </div>
              {user.companyName && (
                <div>
                  <dt className="text-neutral-500 dark:text-neutral-400">Company</dt>
                  <dd>{user.companyName}</dd>
                </div>
              )}
              {plan && (
                <div>
                  <dt className="text-neutral-500 dark:text-neutral-400">Plan</dt>
                  <dd>
                    {PLAN_LABELS[plan]}{" "}
                    <a href="/portal/plan" className="text-brand-start hover:underline">
                      Change
                    </a>
                  </dd>
                </div>
              )}
            </dl>
          ) : (
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
          )}
        </div>
        <div className="mt-4 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-6">
          <h2 className="mb-3 text-lg font-medium text-charcoal">KYC</h2>
          <a href="/portal/kyc" className="text-sm text-brand-start hover:underline">
            Start or update your corporate KYC profile →
          </a>
        </div>
      </div>
    </div>
  );
}
