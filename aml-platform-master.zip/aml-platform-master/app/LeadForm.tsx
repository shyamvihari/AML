"use client";

import { useState } from "react";
import { PERSONAS, PERSONA_LABELS, type LEAD_SOURCES } from "@/lib/schemas";

type LeadSource = (typeof LEAD_SOURCES)[number];

export function LeadForm({
  source,
  submitLabel = "Submit",
  showPersona = true,
  showMessage = true,
  onSuccess,
}: {
  source: LeadSource;
  submitLabel?: string;
  showPersona?: boolean;
  showMessage?: boolean;
  onSuccess?: () => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [persona, setPersona] = useState<(typeof PERSONAS)[number]>("OTHER");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, company, persona, source, message }),
      });
      if (!res.ok) throw new Error("Submission failed");
      setDone(true);
      onSuccess?.();
    } catch {
      setError("Something went wrong. Please try again or email admin@compassandcoin.com directly.");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <p className="rounded-md bg-offwhite p-4 text-sm text-charcoal">
        Thank you — we've received your details and will be in touch shortly.
      </p>
    );
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-3">
      <label className="flex flex-col gap-1 text-sm">
        Name
        <input required value={name} onChange={(e) => setName(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        Email
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        Phone (optional)
        <input value={phone} onChange={(e) => setPhone(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        Company (optional)
        <input value={company} onChange={(e) => setCompany(e.target.value)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
      </label>
      {showPersona && (
        <label className="flex flex-col gap-1 text-sm">
          I am a...
          <select value={persona} onChange={(e) => setPersona(e.target.value as typeof persona)} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2">
            {PERSONAS.map((p) => (
              <option key={p} value={p}>{PERSONA_LABELS[p]}</option>
            ))}
          </select>
        </label>
      )}
      {showMessage && (
        <label className="flex flex-col gap-1 text-sm">
          Message (optional)
          <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={3} className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2" />
        </label>
      )}
      {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
      <button type="submit" disabled={busy} className="rounded-md bg-brand-gradient px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50">
        {busy ? "Submitting..." : submitLabel}
      </button>
    </form>
  );
}
