import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, ForbiddenError } from "@/lib/requireClient";
import { UnauthorizedError } from "@/lib/requireAuth";
import { hashPassword, generateTempPassword } from "@/lib/auth";
import { customerInputSchema } from "@/lib/customerSchemas";

export async function GET(request: Request) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const customers = await prisma.customer.findMany({
    where: { clientUserId: payload.userId },
    orderBy: { createdAt: "desc" },
    select: { id: true, name: true, companyName: true, email: true, status: true, createdAt: true },
  });
  return NextResponse.json({ customers });
}

export async function POST(request: Request) {
  let payload;
  try {
    payload = requireClient(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = customerInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { email, ...fields } = parsed.data;

  const existingUser = await prisma.user.findUnique({ where: { email } });
  if (existingUser) {
    return NextResponse.json(
      { error: "An account with this email already exists — customers can't currently be shared across clients" },
      { status: 409 },
    );
  }

  const tempPassword = generateTempPassword();
  const passwordHash = await hashPassword(tempPassword);

  const customer = await prisma.$transaction(async (tx) => {
    const customerUser = await tx.user.create({
      data: {
        name: fields.name || email,
        email,
        passwordHash,
        role: "CUSTOMER",
      },
    });
    return tx.customer.create({
      data: {
        clientUserId: payload.userId,
        customerUserId: customerUser.id,
        email,
        ...fields,
        status: "DRAFT",
      },
    });
  });

  return NextResponse.json({ customer }, { status: 201 });
}
