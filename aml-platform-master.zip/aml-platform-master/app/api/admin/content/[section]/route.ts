import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireSuperAdmin, ForbiddenError } from "@/lib/requireSuperAdmin";
import { UnauthorizedError } from "@/lib/requireAuth";
import { SECTION_SCHEMAS, isSiteContentSection } from "@/lib/contentSchemas";

export async function GET(request: Request, { params }: { params: Promise<{ section: string }> }) {
  try {
    requireSuperAdmin(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { section } = await params;
  if (!isSiteContentSection(section)) return NextResponse.json({ error: "Unknown section" }, { status: 404 });

  const row = await prisma.siteContent.findUnique({ where: { section } });
  if (!row) return NextResponse.json({ error: "Section not seeded" }, { status: 404 });
  return NextResponse.json({ section: row.section, data: row.data, updatedAt: row.updatedAt });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ section: string }> }) {
  let payload;
  try {
    payload = requireSuperAdmin(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { section } = await params;
  if (!isSiteContentSection(section)) return NextResponse.json({ error: "Unknown section" }, { status: 404 });

  const body = await request.json().catch(() => null);
  const parsed = SECTION_SCHEMAS[section].safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const row = await prisma.siteContent.update({
    where: { section },
    data: { data: parsed.data as Prisma.InputJsonValue, updatedByUserId: payload.userId },
  });
  return NextResponse.json({ section: row.section, data: row.data, updatedAt: row.updatedAt });
}
