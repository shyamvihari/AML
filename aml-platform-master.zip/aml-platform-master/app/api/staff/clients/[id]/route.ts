import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import { staffCreateClientInputSchema } from "@/lib/staffSchemas";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const client = await prisma.user.findFirst({
    where: { id, role: "CLIENT" },
    select: { id: true, name: true, email: true, companyName: true },
  });
  if (!client) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json({ client });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const existing = await prisma.user.findFirst({ where: { id, role: "CLIENT" } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const body = await request.json().catch(() => null);
  const parsed = staffCreateClientInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { email, ...fields } = parsed.data;

  const emailOwner = await prisma.user.findUnique({ where: { email } });
  if (emailOwner && emailOwner.id !== id) {
    return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
  }

  const client = await prisma.user.update({
    where: { id },
    data: { name: fields.name, email, companyName: fields.companyName ?? null },
    select: { id: true, name: true, email: true, companyName: true },
  });

  return NextResponse.json({ client });
}
