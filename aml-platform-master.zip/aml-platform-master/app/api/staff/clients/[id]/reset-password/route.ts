import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff, ForbiddenError } from "@/lib/requireStaff";
import { UnauthorizedError } from "@/lib/requireAuth";
import { hashPassword, generateTempPassword } from "@/lib/auth";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireStaff(request);
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: err.message }, { status: 401 });
    if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
    throw err;
  }

  const { id } = await params;
  const existing = await prisma.user.findFirst({ where: { id, role: "CLIENT" } });
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const tempPassword = generateTempPassword();
  const passwordHash = await hashPassword(tempPassword);
  await prisma.user.update({ where: { id }, data: { passwordHash } });

  return NextResponse.json({ tempPassword });
}
