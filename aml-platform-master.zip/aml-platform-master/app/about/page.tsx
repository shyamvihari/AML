import { SectionHeading } from "../SectionHeading";
import { prisma } from "@/lib/prisma";
import type { AboutUsData } from "@/lib/contentSchemas";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "About | Compass & Coin",
  description:
    "Compass & Coin Technologies FZE is a Dubai-based AML advisory and technology-enabled compliance practice, founded to bring institutional-grade anti-money laundering discipline to the DNFBP sector.",
};

// Fallback copy matching the exact seeded "about_us" row in
// prisma/migrations/00000000000007_super_admin_site_content/migration.sql.
// Used only if the row is ever missing, so this page degrades gracefully
// instead of crashing.
const FALLBACK_ABOUT_US: AboutUsData = {
  eyebrow: "About Us",
  title: "A compliance practice, built to scale",
  subtitle:
    "Compass & Coin Technologies FZE converts hands-on AML advisory experience into a repeatable, technology-enabled service for Dubai's DNFBP sector.",
  blocks: [
    {
      heading: null,
      body: "Compass & Coin began as a founder-led AML advisory practice working directly with Designated Non-Financial Businesses and Professions (DNFBPs) across Dubai. That hands-on work — registering entities under Cabinet Resolution 134 of 2025, building AML policies from the ground up, and sitting alongside Compliance Officers as they prepared for their first goAML filings — surfaced the same gap again and again: firms needed rigorous, audit-ready compliance support, but most were too small to justify a full in-house function and too exposed to go without one.",
    },
    {
      heading: null,
      body: "Our mission is to close that gap by turning individual advisory engagements into a scalable, technology-enabled service — one that keeps the judgment and accountability of a boutique practice while removing the friction that usually comes with growing beyond a single advisor. We are building the systems, templates, and screening workflows now so that as our client base grows, the quality of the advice does not thin out.",
    },
    {
      heading: "Our people",
      body: "Compass & Coin is led by its founder, who has worked directly with DNFBPs on AML registration, policy design, and regulator-facing compliance since the practice's earliest engagements. The founder sets the firm's advisory standards and remains personally involved in client onboarding and higher-risk case review.\n\nDay-to-day compliance operations are overseen by our AML Manager, who holds the DridhOn CAMP (Certified Anti-Money Laundering Professional) certification. The AML Manager is responsible for screening workflows, ongoing monitoring, and ensuring that client files stay audit-ready between regulator engagements. As the practice grows beyond founder-led capacity, this role anchors the consistency of our methodology across a larger client book.",
    },
    {
      heading: "Where we work",
      body: "Compass & Coin Technologies FZE is based in Motor City, Dubai, at 301, Abstract Business Center, Motor City, Dubai, United Arab Emirates. We work primarily with DNFBPs operating in and around Dubai, with engagements conducted on-site and remotely as each client's registration and reporting timeline requires.",
    },
    {
      heading: "What we stand for",
      body: 'We describe our positioning as "boutique, but scalable" — every engagement gets the direct attention of people who have done this work before, but the underlying process is designed to be repeatable, not reinvented for each client. We build client files to be audit-ready by design: documentation, screening records, and policy artifacts are structured from day one to withstand regulator scrutiny, not assembled retroactively when an inspection is announced. That combination — personal accountability paired with systematic rigor — is what we mean when we say we are precise, regulatory-literate, and reassuring in how we work.',
    },
  ],
};

export default async function AboutPage() {
  const row = await prisma.siteContent.findUnique({ where: { section: "about_us" } });
  const content = (row?.data as AboutUsData | undefined) ?? FALLBACK_ABOUT_US;

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <SectionHeading eyebrow={content.eyebrow} title={content.title} subtitle={content.subtitle} />

      <div className="flex flex-col gap-6 text-neutral-700 dark:text-neutral-300">
        {content.blocks.map((block, i) => (
          <div key={i} className="flex flex-col gap-6">
            {block.heading && <h3 className="text-xl font-semibold text-charcoal">{block.heading}</h3>}
            {block.body.split("\n\n").map((paragraph, j) => (
              <p key={j}>{paragraph}</p>
            ))}
          </div>
        ))}
      </div>
    </main>
  );
}
