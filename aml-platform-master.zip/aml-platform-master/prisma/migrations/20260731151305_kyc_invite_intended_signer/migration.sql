-- AlterTable
ALTER TABLE "CustomerInvite" ADD COLUMN     "intendedSignerUserId" TEXT;
