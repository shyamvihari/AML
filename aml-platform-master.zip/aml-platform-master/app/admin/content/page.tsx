"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { getClientToken, getCurrentUser, type SessionUser } from "@/lib/session";

type SectionSummary = { section: string; label: string; updatedAt: string | null };

export default function AdminContentListPage() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [sections, setSections] = useState<SectionSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  useEffect(() => {
    if (!user || user.role !== "SUPER_ADMIN") return;
    const token = getClientToken();
    fetch("/api/admin/content", { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((res) => res.json())
      .then((body) => {
        setSections(body.sections ?? []);
        setLoading(false);
      });
  }, [user]);

  if (user && user.role !== "SUPER_ADMIN") {
    return <div className="mx-auto max-w-3xl px-6 py-16 text-sm text-neutral-600 dark:text-neutral-300">Super Admin access required.</div>;
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <Link href="/admin" className="text-sm text-brand-start hover:underline">← Back to dashboard</Link>
      <h1 className="mt-3 text-2xl font-semibold text-charcoal">Website Content</h1>
      <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
        Choose a section to edit. Changes go live immediately.
      </p>
      {loading ? (
        <p className="mt-4 text-sm text-neutral-500 dark:text-neutral-400">Loading...</p>
      ) : (
        <div className="mt-6 flex flex-col gap-3">
          {sections.map((s) => (
            <Link
              key={s.section}
              href={`/admin/content/${s.section}`}
              className="flex items-center justify-between rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 p-4 hover:border-brand-start"
            >
              <span className="font-medium text-charcoal">{s.label}</span>
              <span className="text-xs text-neutral-500 dark:text-neutral-400">
                {s.updatedAt ? `Updated ${new Date(s.updatedAt).toLocaleDateString()}` : "Never edited"}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
