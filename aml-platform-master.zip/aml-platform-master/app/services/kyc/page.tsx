import Link from "next/link";
import { SectionHeading } from "../../SectionHeading";

export const metadata = {
  title: "KYC & Onboarding | Compass & Coin",
  description:
    "Digital KYC intake, document collection, UBO mapping, and risk-based CDD/EDD routing for UAE real estate DNFBPs.",
};

const DOCUMENT_CHECKLIST = [
  "Passport or Emirates ID (individuals and signatories)",
  "Trade licence (corporate buyers, sellers, and intermediaries)",
  "Memorandum of Association and shareholder register (corporates)",
  "Proof of address, current within the last three months",
  "Source-of-funds evidence appropriate to the transaction value",
];

const RISK_TIERS = [
  {
    label: "Low",
    color: "bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400",
    description:
      "UAE-resident individual buyer, transparent source of funds, no PEP or adverse-media hits. Standard CDD applies.",
  },
  {
    label: "Medium",
    color: "bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400",
    description:
      "Corporate buyer with a straightforward ownership structure, or a cross-border transaction requiring extra source-of-funds documentation. Enhanced document review applies.",
  },
  {
    label: "High",
    color: "bg-rose-50 dark:bg-rose-950 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-400",
    description:
      "PEP-linked party, complex or opaque ownership chain, high-risk jurisdiction exposure, or cash-intensive structuring. Routed to full Enhanced Due Diligence (EDD).",
  },
];

export default function KycPage() {
  return (
    <main className="bg-white dark:bg-neutral-900">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <SectionHeading
          eyebrow="Pillar A"
          title="KYC & Onboarding"
          subtitle="Customer due diligence built for real estate transaction structures — individuals, corporates, trusts, and the ownership chains behind them."
        />

        <div className="flex flex-col gap-10 text-neutral-700 dark:text-neutral-300">
          <section>
            <h3 className="text-xl font-semibold text-charcoal">Digital intake for every party type</h3>
            <p className="mt-3">
              Onboarding starts with a digital intake flow that adapts to who is on the
              other side of the transaction: individual buyers and sellers, corporate
              entities, trusts, and parties connected to a politically exposed person
              (PEP). Each intake path collects the identity, ownership, and source-of-funds
              information a DNFBP is required to hold on file before a transaction
              proceeds — structured from the outset so it stands up to later regulator
              review rather than being reconstructed after the fact.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Document collection checklist</h3>
            <p className="mt-3">
              The exact document set depends on the client type and transaction, but a
              typical onboarding file includes:
            </p>
            <ul className="mt-4 flex flex-col gap-2">
              {DOCUMENT_CHECKLIST.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-start" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Risk-based CDD vs. EDD routing</h3>
            <p className="mt-3">
              Not every client warrants the same level of scrutiny, and treating every
              file identically wastes effort on low-risk relationships while under-serving
              genuinely high-risk ones. Every onboarding is scored against a risk
              methodology covering client type, geography, transaction structure, and
              screening results, and routed accordingly: standard Customer Due Diligence
              (CDD) for lower-risk profiles, and Enhanced Due Diligence (EDD) — additional
              documentation, senior sign-off, and closer source-of-funds scrutiny — for
              higher-risk ones.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">UBO and ownership-chain mapping</h3>
            <p className="mt-3">
              For corporate buyers and sellers, we map the ultimate beneficial ownership
              (UBO) chain back to the natural persons who ultimately control or benefit
              from the entity — a requirement that becomes materially harder, and more
              important, as corporate structures add layers of holding companies or
              nominee arrangements. That ownership record is what a Compliance Officer
              produces when a regulator asks who actually stands behind a transaction.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-charcoal">Illustrative risk-rating output</h3>
            <p className="mt-3">
              Once intake and screening are complete, each client file is assigned a risk
              tier. This is an illustrative example of how the three tiers are presented —
              not a live scoring tool:
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {RISK_TIERS.map((tier) => (
                <div key={tier.label} className={`rounded-lg border p-4 ${tier.color}`}>
                  <p className="text-sm font-semibold uppercase tracking-wide">{tier.label}</p>
                  <p className="mt-2 text-sm">{tier.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-lg border border-neutral-200 dark:border-neutral-700 bg-offwhite p-6">
            <h3 className="text-lg font-semibold text-charcoal">Set up KYC for your firm</h3>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
              We'll walk through your typical client mix and transaction structures on a
              scoping call and recommend the intake and risk-rating approach that fits.
            </p>
            <Link
              href="/contact?intent=scoping-call"
              className="mt-4 inline-block rounded-md bg-brand-gradient px-5 py-3 text-sm font-medium text-white hover:opacity-90"
            >
              Book a Free AML Scoping Call
            </Link>
          </section>
        </div>
      </div>
    </main>
  );
}
