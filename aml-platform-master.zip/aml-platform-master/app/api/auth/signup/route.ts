import { NextResponse } from "next/server";
import { signupInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";
import { hashPassword, signToken } from "@/lib/auth";

function toSessionUser(user: { id: string; name: string; email: string; role: string; companyName: string | null }) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, companyName: user.companyName };
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = signupInputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { name, email, password, companyName } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });

  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({
    data: { name, email, passwordHash, companyName, role: "CLIENT" },
  });

  const token = signToken({ userId: user.id, role: "CLIENT" });
  return NextResponse.json({ token, user: toSessionUser(user) }, { status: 201 });
}
