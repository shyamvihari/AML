import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { computeHealthCheckScore } from "@/lib/healthCheckLogic";
import { leadInputSchema } from "@/lib/schemas";
import { prisma } from "@/lib/prisma";

const requestSchema = z.object({
  answers: z.record(z.string(), z.boolean()),
  lead: leadInputSchema.omit({ source: true, payload: true }),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { answers, lead } = parsed.data;
  const result = computeHealthCheckScore(answers);

  await prisma.lead.create({
    data: {
      ...lead,
      source: "HEALTH_CHECK",
      payload: { answers, result } as unknown as Prisma.InputJsonValue,
    },
  });

  return NextResponse.json(result);
}
