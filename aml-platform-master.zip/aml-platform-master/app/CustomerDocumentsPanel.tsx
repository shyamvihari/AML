"use client";

import { useState } from "react";
import { CUSTOMER_DOCUMENT_TYPES, CUSTOMER_DOCUMENT_TYPE_LABELS } from "@/lib/customerSchemas";

type DocumentLike = { id: string; type: string; fileName: string };

export function CustomerDocumentsPanel({
  documents,
  onUpload,
  onDelete,
  downloadHrefFor,
  readOnly,
}: {
  documents: DocumentLike[];
  onUpload: (file: File, type: string) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  downloadHrefFor: (id: string) => string;
  readOnly?: boolean;
}) {
  const [uploadType, setUploadType] = useState<(typeof CUSTOMER_DOCUMENT_TYPES)[number]>("EMIRATES_ID");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  async function upload() {
    if (!uploadFile) return;
    setBusy(true);
    await onUpload(uploadFile, uploadType);
    setUploadFile(null);
    setBusy(false);
  }

  return (
    <div className="flex flex-col gap-3">
      {documents.length ? (
        <ul className="flex flex-col gap-2">
          {documents.map((d) => (
            <li key={d.id} className="flex items-center justify-between rounded-md border border-neutral-200 dark:border-neutral-700 px-3 py-2 text-sm">
              <a href={downloadHrefFor(d.id)} className="text-brand-start hover:underline">
                {d.fileName} ({CUSTOMER_DOCUMENT_TYPE_LABELS[d.type as keyof typeof CUSTOMER_DOCUMENT_TYPE_LABELS] ?? d.type})
              </a>
              {!readOnly && onDelete && (
                <button type="button" onClick={() => onDelete(d.id)} className="text-red-600 dark:text-red-400">
                  Delete
                </button>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-neutral-500 dark:text-neutral-400">Nothing uploaded yet.</p>
      )}
      {!readOnly && (
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={uploadType}
            onChange={(e) => setUploadType(e.target.value as (typeof CUSTOMER_DOCUMENT_TYPES)[number])}
            className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-2 text-sm"
          >
            {CUSTOMER_DOCUMENT_TYPES.map((t) => (
              <option key={t} value={t}>{CUSTOMER_DOCUMENT_TYPE_LABELS[t]}</option>
            ))}
          </select>
          <input type="file" onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)} className="text-sm" />
          <button
            type="button"
            onClick={upload}
            disabled={!uploadFile || busy}
            className="rounded-md border border-neutral-300 dark:border-neutral-600 px-3 py-1.5 text-sm hover:bg-offwhite disabled:opacity-50"
          >
            Upload
          </button>
        </div>
      )}
    </div>
  );
}
