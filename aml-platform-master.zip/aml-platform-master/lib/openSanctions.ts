const OPENSANCTIONS_API_BASE = "https://api.opensanctions.org";
const MATCH_SCORE_THRESHOLD = 0.7;

export type OpenSanctionsMatch = {
  source: string;
  matchName: string;
  matchType: string;
  nationality: string | null;
  matchScore: number;
  sourceEntityId: string;
};

export class OpenSanctionsError extends Error {}

type RawMatchResult = {
  id: string;
  caption: string;
  score?: number;
  datasets?: string[];
  properties?: { topics?: string[]; nationality?: string[] };
};

type RawMatchResponse = {
  responses?: {
    subject?: { results?: RawMatchResult[] };
  };
};

export async function matchSubject(input: {
  name: string;
  birthDate?: string;
  nationality?: string;
}): Promise<OpenSanctionsMatch[]> {
  const apiKey = process.env.OPENSANCTIONS_API_KEY;
  if (!apiKey) throw new OpenSanctionsError("OpenSanctions is not configured");

  const properties: Record<string, string[]> = { name: [input.name] };
  if (input.birthDate) properties.birthDate = [input.birthDate];
  if (input.nationality) properties.nationality = [input.nationality];

  const res = await fetch(`${OPENSANCTIONS_API_BASE}/match/default`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `ApiKey ${apiKey}` },
    body: JSON.stringify({ queries: { subject: { schema: "Person", properties } } }),
  });
  if (!res.ok) throw new OpenSanctionsError(`OpenSanctions request failed (${res.status})`);

  const body: RawMatchResponse = await res.json();
  const results = body.responses?.subject?.results ?? [];

  return results
    .filter((r) => (r.score ?? 0) >= MATCH_SCORE_THRESHOLD)
    .map((r) => ({
      source: r.datasets?.[0] ?? "OpenSanctions",
      matchName: r.caption,
      matchType: (r.properties?.topics ?? []).join(", "),
      nationality: r.properties?.nationality?.[0] ?? null,
      matchScore: r.score ?? 0,
      sourceEntityId: r.id,
    }));
}

const HIGH_RISK_TOPIC_FAMILIES = ["sanction", "wanted", "debarment", "export.control", "crime"];
const MEDIUM_RISK_TOPIC_FAMILIES = ["role.pep", "poi", "role.rca"];

// OpenSanctions topics are a dotted hierarchy (e.g. "sanction.linked", "crime.terror").
// A topic belongs to a family if it equals the family or is nested under it.
function isInTopicFamily(topic: string, family: string): boolean {
  return topic === family || topic.startsWith(`${family}.`);
}

export function suggestRiskRating(matches: OpenSanctionsMatch[]): "HIGH" | "MEDIUM" | "LOW" {
  const allTopics = matches.flatMap((m) => m.matchType.split(", ").filter(Boolean));
  if (allTopics.some((t) => HIGH_RISK_TOPIC_FAMILIES.some((f) => isInTopicFamily(t, f)))) return "HIGH";
  if (allTopics.some((t) => MEDIUM_RISK_TOPIC_FAMILIES.some((f) => isInTopicFamily(t, f)))) return "MEDIUM";
  return "LOW";
}
