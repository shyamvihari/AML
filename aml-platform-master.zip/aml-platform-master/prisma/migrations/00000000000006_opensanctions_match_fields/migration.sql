-- AlterTable
ALTER TABLE "CustomerScreeningMatch" ADD COLUMN     "matchScore" DOUBLE PRECISION,
ADD COLUMN     "sourceEntityId" TEXT;

-- AlterTable
ALTER TABLE "ScreeningMatch" ADD COLUMN     "matchScore" DOUBLE PRECISION,
ADD COLUMN     "sourceEntityId" TEXT;

