import { prisma } from "./prisma";
import type { Customer, CustomerInvite } from "@prisma/client";

export class InviteInvalidError extends Error {}

export async function requireInvite(token: string): Promise<CustomerInvite & { customer: Customer }> {
  const invite = await prisma.customerInvite.findUnique({
    where: { token },
    include: { customer: true },
  });
  if (!invite || invite.consumedAt) {
    throw new InviteInvalidError("This link is no longer valid");
  }
  return invite;
}
