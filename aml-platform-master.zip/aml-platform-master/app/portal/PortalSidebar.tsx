"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const SERVICE_LINKS = [
  { href: "/portal/kyc", label: "KYC" },
  { href: "/services/policy-registration", label: "Policy Registration" },
  { href: "/services/reporting", label: "Reporting" },
  { href: "/portal/customers", label: "Screening" },
  { href: "/portal/customer-summary", label: "Customer" },
  { href: "/portal/plan", label: "Plan" },
];

export function PortalSidebar() {
  const pathname = usePathname();
  return (
    <nav className="flex w-full shrink-0 flex-row flex-wrap gap-2 md:w-48 md:flex-col md:gap-3">
      {SERVICE_LINKS.map((link) => {
        const active = pathname === link.href || pathname?.startsWith(`${link.href}/`);
        return (
          <Link
            key={link.href}
            href={link.href}
            className={`rounded-lg border px-4 py-3 text-sm font-medium ${
              active
                ? "border-brand-start bg-offwhite text-charcoal"
                : "border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-charcoal hover:border-brand-start hover:bg-offwhite"
            }`}
          >
            {link.label}
          </Link>
        );
      })}
    </nav>
  );
}
